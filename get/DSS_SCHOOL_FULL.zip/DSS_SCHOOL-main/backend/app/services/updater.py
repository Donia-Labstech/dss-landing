# -*- coding: utf-8 -*-
"""التحديث الآمن عند توفر الإنترنت: يجلب version.json من موقع DONIA، يتحقق من التوقيع (Ed25519) و SHA-256،
ينسخ قاعدة البيانات احتياطياً، ثم يستبدل ملفات البرنامج فقط (لا يمسّ data / uploads / licenses / .env)."""
import os, sys, io, json, time, base64, hashlib, shutil, sqlite3, zipfile, threading, subprocess
from pathlib import Path
from app.core.config import BASE_DIR

BACKEND = Path(BASE_DIR)
DATA = BACKEND / "data"
MANIFEST_URL = os.getenv("DSS_UPDATE_URL", "https://donia-labstech.github.io/dss-landing/get/version.json")
PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAF0b7pGqLvXE7e2AUx5n7WWZJvARYu9mjdHiwHrd+t14=
-----END PUBLIC KEY-----"""
ALLOWED_TOP = {"app", "assets"}
ALLOWED_FILES = {"index.html", "main.py", "requirements.txt", "import_data.py", "VERSION"}
CFG = DATA / "update.json"
_st = {"last_check": 0, "latest": None, "error": "", "busy": False, "applied": ""}

def local():
    try:
        return json.loads((BACKEND / "VERSION").read_text(encoding="utf-8"))
    except Exception:
        return {"version": "0", "runtime": 1}

def _vt(v):
    return tuple(int(x) if x.isdigit() else 0 for x in str(v).split("."))

def settings():
    try: return json.loads(CFG.read_text(encoding="utf-8"))
    except Exception: return {"auto": True}

def set_auto(v):
    DATA.mkdir(parents=True, exist_ok=True)
    CFG.write_text(json.dumps({"auto": bool(v)}), encoding="utf-8")

def _get(url, timeout=15):
    import httpx
    r = httpx.get(url, timeout=timeout, follow_redirects=True)
    r.raise_for_status()
    return r.content

def _verify(blob, sha, sig_b64):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519
    if hashlib.sha256(blob).hexdigest() != sha:
        raise ValueError("بصمة الملف غير مطابقة")
    pub = serialization.load_pem_public_key(PUBLIC_KEY_PEM)
    pub.verify(base64.b64decode(sig_b64), sha.encode("ascii"))   # يرفع استثناء إن كان التوقيع غير صحيح

def check():
    """يجلب البيان ويحدّد وجود تحديث. لا يغيّر شيئاً."""
    _st["last_check"] = time.time(); _st["error"] = ""
    try:
        m = json.loads(_get(MANIFEST_URL, 8).decode("utf-8"))
        _st["latest"] = m
    except Exception as e:
        _st["error"] = "تعذّر الاتصال بخادم التحديثات"; _st["latest"] = None
    return info()

def info():
    cur = local(); m = _st["latest"]
    avail = bool(m) and _vt(m.get("version", "0")) > _vt(cur["version"])
    needs_installer = bool(m) and int(m.get("min_runtime", 1)) > int(cur.get("runtime", 1))
    return {"current": cur["version"], "latest": (m or {}).get("version"), "available": avail,
            "needs_installer": avail and needs_installer, "notes": (m or {}).get("notes", ""),
            "last_check": int(_st["last_check"]), "error": _st["error"], "auto": settings().get("auto", True),
            "applied": _st["applied"], "installer_url": (m or {}).get("installer_url", "")}

def _backup():
    DATA.mkdir(parents=True, exist_ok=True)
    db = DATA / "dss_school.db"
    if not db.exists(): return ""
    bdir = DATA / "backups"; bdir.mkdir(exist_ok=True)
    dst = bdir / ("pre-update-%s-%s.db" % (local()["version"], time.strftime("%Y%m%d-%H%M%S")))
    src = sqlite3.connect(str(db)); out = sqlite3.connect(str(dst))
    try: src.backup(out)
    finally: out.close(); src.close()
    olds = sorted(bdir.glob("pre-update-*.db"))[:-5]      # يُبقي آخر 5 نسخ
    for o in olds:
        try: o.unlink()
        except Exception: pass
    return str(dst)

def _safe(name):
    n = name.replace("\\", "/")
    if n.startswith("/") or ".." in n.split("/") or ":" in n: return False
    top = n.split("/")[0]
    return n in ALLOWED_FILES or top in ALLOWED_TOP

def apply():
    """ينزّل التحديث ويطبّقه ثم يعيد تشغيل الخادم. يرجع (ok, رسالة)."""
    if _st["busy"]: return False, "جارٍ التحديث"
    _st["busy"] = True
    try:
        if not _st["latest"]: check()
        i = info()
        if not i["available"]: return False, "لا يوجد تحديث"
        if i["needs_installer"]: return False, "هذا التحديث يتطلب تنزيل ملف التثبيت الجديد"
        m = _st["latest"]
        url = m["url"] if m["url"].startswith("http") else MANIFEST_URL.rsplit("/", 1)[0] + "/" + m["url"]
        blob = _get(url, 120)
        _verify(blob, m["sha256"], m["sig"])
        z = zipfile.ZipFile(io.BytesIO(blob))
        names = [n for n in z.namelist() if not n.endswith("/")]
        if not names or not all(_safe(n) for n in names):
            return False, "حزمة التحديث غير صالحة"
        if "main.py" not in names or "VERSION" not in names:
            return False, "حزمة التحديث ناقصة"
        bk = _backup()
        stage = DATA / "update_stage"
        shutil.rmtree(stage, ignore_errors=True); stage.mkdir(parents=True)
        z.extractall(stage)
        for top in ALLOWED_TOP:
            if (stage / top).exists():
                shutil.rmtree(BACKEND / top, ignore_errors=True)
                shutil.copytree(stage / top, BACKEND / top)
        for f in ALLOWED_FILES:
            if (stage / f).exists():
                shutil.copy2(stage / f, BACKEND / f)
        shutil.rmtree(stage, ignore_errors=True)
        _st["applied"] = m["version"]
        _schedule_restart()
        return True, "تم التحديث إلى %s وسيُعاد تشغيل النظام خلال ثوانٍ" % m["version"]
    except Exception as e:
        return False, "فشل التحديث (لم يتغيّر شيء مهم): %s" % str(e)[:120]
    finally:
        _st["busy"] = False

def _schedule_restart():
    port = os.getenv("PORT", "8000")
    code = ("import time,subprocess,os;time.sleep(3);"
            "f=open(%r,'ab');"
            "p=subprocess.Popen([%r,'main.py'],cwd=%r,stdout=f,stderr=f,creationflags=%d);"
            "open(%r,'w').write(str(p.pid))") % (
        str(DATA / "server.log"), sys.executable, str(BACKEND), 0x08000000 if os.name == "nt" else 0,
        str(DATA / "server.pid"))
    subprocess.Popen([sys.executable, "-c", code], cwd=str(BACKEND),
                     creationflags=0x08000000 if os.name == "nt" else 0)
    threading.Timer(1.0, lambda: os._exit(0)).start()

def loop():
    """خيط خلفي: يفحص بعد 20 ثانية من التشغيل ثم كل 6 ساعات. يطبّق صامتاً عند التفعيل
    (في أول 10 دقائق من التشغيل أو بين 00:00 و05:00) وإلا يُظهر إشعاراً للمدير."""
    def run():
        time.sleep(20); started = time.time() - 20
        while True:
            try:
                i = check()
                if i["available"] and not i["needs_installer"] and settings().get("auto", True):
                    h = time.localtime().tm_hour
                    if (time.time() - started) < 600 or h < 5:
                        apply()
            except Exception:
                pass
            time.sleep(6 * 3600)
    threading.Thread(target=run, daemon=True).start()
