# -*- coding: utf-8 -*-
"""الوصول عبر الإنترنت بنفق Cloudflare (cloudflared) — البيانات تبقى على حاسوب المؤسسة.
نمطان: quick (عنوان trycloudflare مؤقت بلا حساب) / token (نفق مُسمّى بعنوان ثابت من حساب Cloudflare مجاني)."""
import os, re, json, threading, subprocess, atexit, time
from pathlib import Path
from app.core.config import BASE_DIR

DATA = Path(BASE_DIR) / "data"
CFG = DATA / "remote.json"
IS_WIN = os.name == "nt"
BIN = DATA / ("cloudflared.exe" if IS_WIN else "cloudflared")
URL_BIN = ("https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
           if IS_WIN else "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64")
_RX = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
_st = {"proc": None, "url": "", "log": [], "connected": False, "started": 0, "dl": ""}
_lock = threading.Lock()

def load():
    try:
        return json.loads(CFG.read_text(encoding="utf-8"))
    except Exception:
        return {"enabled": False, "mode": "quick", "token": "", "hostname": ""}

def save(c):
    DATA.mkdir(parents=True, exist_ok=True)
    CFG.write_text(json.dumps(c, ensure_ascii=False), encoding="utf-8")
    try: os.chmod(CFG, 0o600)
    except Exception: pass

def has_binary():
    return BIN.exists() and BIN.stat().st_size > 5_000_000

def download():
    """تنزيل cloudflared الرسمي من GitHub (يحتاج إنترنت مرة واحدة)."""
    import httpx
    DATA.mkdir(parents=True, exist_ok=True)
    tmp = BIN.with_suffix(".part")
    _st["dl"] = "downloading"
    try:
        with httpx.stream("GET", URL_BIN, follow_redirects=True, timeout=60) as r:
            r.raise_for_status()
            with open(tmp, "wb") as f:
                for ch in r.iter_bytes(1 << 16):
                    f.write(ch)
        head = open(tmp, "rb").read(4)
        ok_sig = head[:2] == b"MZ" if IS_WIN else head == b"\x7fELF"
        if not ok_sig or tmp.stat().st_size < 5_000_000:
            raise RuntimeError("الملف المنزَّل غير صالح")
        os.replace(tmp, BIN)
        if not IS_WIN: os.chmod(BIN, 0o755)
        _st["dl"] = "done"
        return True
    except Exception as e:
        _st["dl"] = "error: %s" % str(e)[:120]
        try: tmp.unlink()
        except Exception: pass
        return False

def _reader(p):
    for raw in iter(p.stderr.readline, b""):
        line = raw.decode("utf-8", "ignore").strip()
        if not line: continue
        _st["log"] = (_st["log"] + [line])[-30:]
        m = _RX.search(line)
        if m and "api.trycloudflare" not in m.group(0):
            _st["url"] = m.group(0); _st["connected"] = True
        if "Registered tunnel connection" in line:
            _st["connected"] = True
    _st["connected"] = False

def running():
    p = _st["proc"]
    return p is not None and p.poll() is None

def start(port):
    with _lock:
        if running(): return True
        c = load()
        if not has_binary(): return False
        args = [str(BIN), "tunnel", "--no-autoupdate"]
        env = dict(os.environ)
        if c.get("mode") == "token" and c.get("token"):
            args += ["run"]; env["TUNNEL_TOKEN"] = c["token"]
        else:
            args += ["--url", "http://127.0.0.1:%s" % port]
        _st.update(url=(("https://" + c["hostname"]) if c.get("mode") == "token" and c.get("hostname") else ""),
                   log=[], connected=False, started=time.time())
        _st["proc"] = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, env=env,
                                       creationflags=0x08000000 if IS_WIN else 0)
        threading.Thread(target=_reader, args=(_st["proc"],), daemon=True).start()
        return True

def stop():
    with _lock:
        p = _st["proc"]
        if p and p.poll() is None:
            try: p.terminate(); p.wait(5)
            except Exception:
                try: p.kill()
                except Exception: pass
        _st.update(proc=None, url="", connected=False)

atexit.register(stop)

def status():
    c = load()
    return {"enabled": bool(c.get("enabled")), "mode": c.get("mode", "quick"), "hostname": c.get("hostname", ""),
            "has_token": bool(c.get("token")), "binary": has_binary(), "running": running(),
            "connected": bool(_st["connected"]), "url": _st["url"], "download": _st["dl"],
            "log": _st["log"][-6:] if not running() or not _st["connected"] else []}

def autostart(port):
    """يُستدعى عند تشغيل الخادم: يعيد تشغيل النفق إن كان مفعّلاً."""
    def go():
        time.sleep(3)
        if load().get("enabled") and has_binary():
            start(port)
    threading.Thread(target=go, daemon=True).start()
