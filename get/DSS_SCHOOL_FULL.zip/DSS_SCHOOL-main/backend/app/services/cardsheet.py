# -*- coding: utf-8 -*-
"""تصاميم بطاقات الطباعة (CR80، 8 في A4): تلميذ / مطعم (ملعقة وشوكة) / مكتبة / نادٍ. بلا شعار DONIA."""
import io, os, base64, html as _h
import qrcode
from app.services import cards as CARDS

_SVG = {
 # ملعقة وشوكة
 "canteen": '<svg viewBox="0 0 48 48" width="9mm" height="9mm"><g fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M13 5v13a4 4 0 0 0 4 4v21M9 5v10M17 5v10M21 5v13a4 4 0 0 1-4 4"/><path d="M35 43V24c-4 0-7-5-7-11 0-5 3-8 7-8s7 3 7 8c0 6-3 11-7 11"/></g></svg>',
 # كتاب
 "library": '<svg viewBox="0 0 48 48" width="9mm" height="9mm"><g fill="none" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"><path d="M24 11c-4-3-10-4-17-4v29c7 0 13 1 17 4 4-3 10-4 17-4V7c-7 0-13 1-17 4zM24 11v29"/></g></svg>',
 # كرة (رياضي)
 "رياضي": '<svg viewBox="0 0 48 48" width="9mm" height="9mm"><g fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"><circle cx="24" cy="24" r="18"/><path d="M24 14l9 6-3 11H18l-3-11zM24 14V6M33 20l9-3M30 31l5 8M18 31l-5 8M15 20l-9-3"/></g></svg>',
 # كتاب+قلم (ثقافي)
 "ثقافي": '<svg viewBox="0 0 48 48" width="9mm" height="9mm"><g fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"><path d="M8 8h20a4 4 0 0 1 4 4v28H12a4 4 0 0 1-4-4zM32 14l8 2-6 24"/><path d="M14 16h12M14 22h12M14 28h8"/></g></svg>',
 # ذرة (علمي)
 "علمي": '<svg viewBox="0 0 48 48" width="9mm" height="9mm"><g fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="24" cy="24" r="3" fill="currentColor"/><ellipse cx="24" cy="24" rx="19" ry="7.5"/><ellipse cx="24" cy="24" rx="19" ry="7.5" transform="rotate(60 24 24)"/><ellipse cx="24" cy="24" rx="19" ry="7.5" transform="rotate(120 24 24)"/></g></svg>',
 # لوحة ألوان (فني)
 "فني": '<svg viewBox="0 0 48 48" width="9mm" height="9mm"><g fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"><path d="M24 5C13 5 5 13 5 23s8 19 18 19c3 0 4-2 4-4s-1-3 0-5 3-2 6-2h4c4 0 6-3 6-6C43 14 35 5 24 5z"/><circle cx="14" cy="22" r="2" fill="currentColor"/><circle cx="20" cy="14" r="2" fill="currentColor"/><circle cx="29" cy="14" r="2" fill="currentColor"/></g></svg>',
 # نجمة (أخرى)
 "أخرى": '<svg viewBox="0 0 48 48" width="9mm" height="9mm"><path d="M24 5l5.6 12 13 1.5-9.7 8.9 2.7 12.9L24 33l-11.6 7.3 2.7-12.9L5.4 18.5l13-1.5z" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"/></svg>',
}
_COL = {"student": "#0b4a3f", "canteen": "#b4560a", "library": "#1e4fa0", "رياضي": "#b42318", "ثقافي": "#6b3fa0",
        "علمي": "#0e7490", "فني": "#a21caf", "أخرى": "#555555"}
TITLES = {"student": "بطاقة التلميذ", "canteen": "بطاقة المطعم المدرسي", "library": "بطاقة المكتبة المدرسية"}

CSS = """<style>@page{size:A4;margin:8mm}body{margin:0;font-family:Tahoma,Arial,sans-serif;direction:rtl;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.pg{display:grid;grid-template-columns:repeat(2,85.6mm);grid-auto-rows:54mm;gap:4mm 6mm;justify-content:center;page-break-after:always}
.cd{width:85.6mm;height:54mm;border:.3mm solid var(--c);border-radius:3mm;box-sizing:border-box;display:flex;flex-direction:column;overflow:hidden;background:#fff}
.hd{display:flex;align-items:center;gap:2mm;background:var(--c);color:#fff;padding:1.2mm 2.5mm;line-height:1.2}
.hd .ic{flex:none;display:flex;color:#fff}.hd .tt{flex:1;text-align:center;font-size:9pt;font-weight:700}.hd .tt small{display:block;font-weight:400;font-size:6.5pt;opacity:.92}
.bd{display:flex;gap:2mm;align-items:center;flex:1;padding:1mm 2.5mm}.ph{width:17mm;height:21mm;object-fit:cover;border:.2mm solid #888}.ph.e{background:#eee}
.nm{flex:1;display:flex;flex-direction:column;gap:1mm;font-size:9pt}.nm span{font-size:8pt;color:#333}.qr{width:20mm;height:20mm}
.bc{height:9mm;text-align:center;padding-bottom:1mm}.bc svg{width:62mm;height:8.5mm}</style>"""

def _color(kind, club):
    return _COL.get(club.category if club else kind, "#444")

def _icon(kind, club):
    return _SVG.get(club.category if club and club.category in _SVG else ("أخرى" if club else kind), _SVG["أخرى"])

def build(studs, kind, si, divs, origin, club=None):
    cards = []
    for s in studs:
        code = s.registration_num or s.card_uid
        buf = io.BytesIO(); qrcode.make(code, box_size=4, border=1).save(buf, format="PNG")
        qr = base64.b64encode(buf.getvalue()).decode()
        ph = (f'<img class="ph" src="{origin}/uploads/photos/{_h.escape(os.path.basename(s.photo_path))}">'
              if s.photo_path else '<div class="ph e"></div>')
        title = _h.escape(club.name) if club else TITLES[kind]
        sub = _h.escape(si.name_ar or "") + (" — " + _h.escape(club.category) if club else "") + " · " + _h.escape(si.academic_year or "")
        extra = f'<span>{_h.escape(s.status or "")}</span>' if kind == "canteen" else ""
        cards.append(f'''<div class="cd" style="--c:{_color(kind, club)}"><div class="hd"><span class="ic">{_icon(kind, club)}</span><div class="tt">{title}<small>{sub}</small></div></div>
<div class="bd">{ph}<div class="nm"><b>{_h.escape(s.full_name)}</b><span>{_h.escape(divs.get(s.division_id, ""))}</span>{extra}<span>رقم: {_h.escape(code)}</span></div>
<img class="qr" src="data:image/png;base64,{qr}"></div><div class="bc">{CARDS.code128_svg(code)}</div></div>''')
    pages = ["".join(cards[i:i + 8]) for i in range(0, len(cards), 8)] or ["<p>لا يوجد تلاميذ مؤهَّلون لهذه البطاقة</p>"]
    body = "".join(f'<div class="pg">{p}</div>' for p in pages)
    ttl = club.name if club else TITLES[kind]
    return f'<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8"><title>{_h.escape(ttl)}</title>{CSS}</head><body>{body}</body></html>'
