@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
set "PYTHONUTF8=1"
title DONIA SMART SCHOOL
cd /d "%~dp0"
set "LOG=%~dp0setup.log"
> "%LOG%" echo DSS setup log %date% %time%
echo ============================================
echo   DONIA SMART SCHOOL - starting...
echo ============================================
echo.

echo %~dp0| findstr /i /c:".zip" /c:"\AppData\Local\Temp" >nul
if not errorlevel 1 goto notextracted

set "PY="
set "PIPX="
call :trypy "py -3"
if not defined PY call :trypy "python"
if not defined PY goto nopython
echo Python found:
%PY% --version
>> "%LOG%" echo PY=%PY%
%PY% --version >> "%LOG%" 2>&1

set "VPY="
set "RUNPY="
if not exist "venv\Scripts\python.exe" goto makevenv
"venv\Scripts\python.exe" -c "import sys" >nul 2>nul
if errorlevel 1 goto brokenvenv
set "VPY=venv\Scripts\python.exe"
set "RUNPY=..\venv\Scripts\python.exe"
goto venvok

:brokenvenv
echo The existing "venv" folder is broken - recreating it...
rmdir /s /q venv >nul 2>nul

:makevenv
echo [1/4] Creating virtual environment (first run only)...
%PY% -m venv venv >> "%LOG%" 2>&1
if not exist "venv\Scripts\python.exe" goto novenv
"venv\Scripts\python.exe" -c "import sys" >nul 2>nul
if errorlevel 1 goto novenv
set "VPY=venv\Scripts\python.exe"
set "RUNPY=..\venv\Scripts\python.exe"
goto venvok

:novenv
echo.
echo [!] Could not create a virtual environment. Details:
echo ----------------------------------------
type "%LOG%"
echo ----------------------------------------
echo Continuing with the system Python instead (installing for the current user)...
rmdir /s /q venv >nul 2>nul
set "VPY=%PY%"
set "RUNPY=%PY%"
set "PIPX=--user"

:venvok
%VPY% -c "import flask,flask_cors,sqlalchemy,jwt,bcrypt,httpx,bs4,openpyxl,dotenv,qrcode,PIL,cryptography" >nul 2>nul
if not errorlevel 1 goto libsok
echo [2/4] Installing required libraries (needs internet, first run only)...
%VPY% -m pip install --upgrade pip %PIPX% >nul 2>nul
%VPY% -m pip install --only-binary=:all: %PIPX% -r backend\requirements.txt
if errorlevel 1 goto pipfail
%VPY% -c "import flask,flask_cors,sqlalchemy,jwt,bcrypt,httpx,bs4,openpyxl,dotenv,qrcode,PIL,cryptography"
if errorlevel 1 goto pipfail
:libsok

if exist "backend\.env" goto envok
echo [3/4] Creating settings file .env ...
%VPY% -c "import secrets; open('backend/.env','w',encoding='utf-8').write('SECRET_KEY='+secrets.token_hex(32)+'\nHMAC_SECRET='+secrets.token_hex(32)+'\nDEBUG=false\n')"
:envok

if not exist "backend\data" mkdir "backend\data"
if not exist "backend\uploads" mkdir "backend\uploads"
if not exist "backend\uploads\photos" mkdir "backend\uploads\photos"
if not exist "backend\licenses" mkdir "backend\licenses"

echo [4/4] Stopping any old copy still running on port 8000...
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":8000" ^| findstr "LISTENING"') do taskkill /F /PID %%P >nul 2>nul

echo.
echo Login (first run):  admin  /  Donia@2026
echo The app window will open in a few seconds: http://127.0.0.1:8000
echo DO NOT CLOSE THIS WINDOW while using the program.
echo.
start "" /min cmd /c "open_app.bat"
cd backend
%RUNPY% main.py
echo.
echo *** The server stopped. Read the message above. ***
pause
exit /b 0

:trypy
%~1 -c "import sys; sys.exit(0 if sys.version_info[:2] >= (3, 9) else 1)" >nul 2>nul
if not errorlevel 1 set "PY=%~1"
exit /b 0

:notextracted
echo [ERROR] This folder looks like it is still inside the ZIP file or a temporary folder.
echo   1) Close this window.
echo   2) Right-click the downloaded ZIP file, choose "Extract All...", and extract it to a normal folder
echo      such as C:\DSS_SCHOOL
echo   3) Open the extracted folder and double-click start.bat again.
pause
exit /b 1

:nopython
echo [ERROR] A working Python (3.9 or newer) was not found on this computer.
echo   1) Download Python 3.12 from https://www.python.org/downloads/ (the installer from python.org, not the Microsoft Store).
echo   2) In the installer, TICK "Add python.exe to PATH", then click Install Now.
echo   3) Close this window and double-click start.bat again.
echo.
echo   (If Python is already installed, Windows may be opening the Microsoft Store instead:
echo    Settings - Apps - Advanced app settings - App execution aliases - turn OFF the python.exe entries.)
pause
exit /b 1

:pipfail
echo.
echo [ERROR] Could not install the required libraries.
echo   - Check the internet connection (needed only for this first run), then run start.bat again.
echo   - If your Python is very new, install Python 3.12 from python.org and run again.
echo   - If it still fails, send us the file setup.log that is next to start.bat.
pause
exit /b 1
