# -*- coding: utf-8 -*-
"""توليد حسابات الدخول تلقائياً: اسم مستخدم مقروء حسب الفئة + كلمة مرور عشوائية سهلة الكتابة.
كلمات المرور لا تُخزَّن إلا مُجزّأة (bcrypt)؛ تُعاد مرة واحدة فقط في الاستجابة لتُطبع في ورقة الدخول."""
import re
import secrets
import html as _h

PREFIX = {"teacher": "ens", "supervisor": "sup", "supervisor_general": "sg", "counselor": "cnr", "nazir": "nzr",
          "admin": "adm", "accountant": "acc", "worker": "wrk", "director": "dir", "parent": "p", "student": "elv"}
ROLE_AR = {"teacher": "أستاذ(ة)", "supervisor": "مشرف(ة)", "supervisor_general": "مشرف(ة) عام(ة)", "counselor": "مستشار(ة) التربية",
           "nazir": "ناظر(ة)", "admin": "إداري(ة)", "accountant": "محاسب(ة)", "worker": "عامل(ة)", "director": "مدير(ة)",
           "parent": "ولي أمر", "student": "تلميذ(ة)"}

_AR = {"ا": "a", "أ": "a", "إ": "i", "آ": "a", "ب": "b", "ت": "t", "ث": "th", "ج": "j", "ح": "h", "خ": "kh", "د": "d", "ذ": "dh",
       "ر": "r", "ز": "z", "س": "s", "ش": "ch", "ص": "s", "ض": "d", "ط": "t", "ظ": "z", "ع": "a", "غ": "gh", "ف": "f", "ق": "k",
       "ك": "k", "ل": "l", "م": "m", "ن": "n", "ه": "h", "ة": "a", "و": "ou", "ي": "i", "ى": "a", "ئ": "i", "ؤ": "ou", "ء": ""}
_ALPHA = "abcdefghjkmnpqrstuvwxyz23456789"   # بلا حروف مُلتبسة (0/o، 1/l/i)


def translit(txt):
    out = []
    for ch in str(txt or ""):
        if ch in _AR:
            out.append(_AR[ch])
        elif ch.isascii() and ch.isalnum():
            out.append(ch.lower())
    return "".join(out)


def gen_password(n=8):
    return "".join(secrets.choice(_ALPHA) for _ in range(n))


def unique_username(db, User, role, last="", first="", seed=None, taken=None):
    taken = taken if taken is not None else set()
    pre = PREFIX.get(role, "usr")
    if seed:
        base = f"{pre}{re.sub(r'[^a-zA-Z0-9]', '', str(seed))}"
    else:
        l, f = translit(last)[:10], translit(first)[:8]
        base = f"{pre}.{l}" + (f".{f}" if f else "") if (l or f) else f"{pre}.{secrets.token_hex(2)}"
    cand, i = base, 1
    while cand in taken or db.query(User).filter(User.username == cand).first():
        i += 1
        cand = f"{base}{i}"
    taken.add(cand)
    return cand


def sheet_html(rows, si, url, origin_note=""):
    """ورقة بيانات الدخول: بطاقات قابلة للقص (10 في كل صفحة A4). تُطبع مرة واحدة ثم تُسلَّم لأصحابها."""
    e = _h.escape
    wil = ("مديرية التربية لولاية " + (si.wilaya or "")) if si and si.wilaya else "مديرية التربية"
    slips = []
    for r in rows:
        slips.append(f'''<div class="sl"><div class="t">بطاقة الدخول إلى النظام</div>
<div class="n">{e(str(r.get("full_name", "")))}</div><div class="m">{e(str(r.get("role_label", "")))}{(" — " + e(str(r["extra"]))) if r.get("extra") else ""}</div>
<table><tr><td class="k">اسم المستخدم</td><td class="v">{e(str(r.get("username", "")))}</td></tr>
<tr><td class="k">كلمة المرور</td><td class="v">{e(str(r.get("password", "")))}</td></tr></table>
<div class="u">{e(url)}</div><div class="w">غيّر كلمة المرور عند أول دخول ولا تُعطها لأحد.</div></div>''')
    pages = ["".join(slips[i:i + 10]) for i in range(0, len(slips), 10)] or ["<p>لا توجد حسابات</p>"]
    head = (f'<div class="hd">الجمهورية الجزائرية الديمقراطية الشعبية<div class="r2"><span>وزارة التربية الوطنية</span><span>{e(wil)}</span></div>'
            f'<div>{e(si.name_ar if si else "")}</div></div>')
    body = "".join(f'<div class="pg">{head}<div class="gr">{p}</div></div>' for p in pages)
    css = """<style>@page{size:A4;margin:8mm}body{margin:0;font-family:Tahoma,Arial,sans-serif;direction:rtl;color:#000}
.pg{page-break-after:always}.hd{text-align:center;font-weight:700;font-size:9pt;line-height:1.5;margin-bottom:3mm}.hd .r2{display:flex;justify-content:space-between;font-weight:400}
.gr{display:grid;grid-template-columns:1fr 1fr;gap:3mm 4mm}.sl{border:.35mm dashed #444;padding:2.5mm 3mm;height:46mm;box-sizing:border-box;overflow:hidden}
.sl .t{font-size:8pt;font-weight:700;text-align:center;border-bottom:.3mm solid #000;padding-bottom:1mm}.sl .n{font-weight:700;font-size:10pt;margin-top:1.5mm}
.sl .m{font-size:8pt;color:#333;margin-bottom:1mm}.sl table{width:100%;border-collapse:collapse;margin:1mm 0}.sl td{border:.25mm solid #000;padding:.8mm 1.5mm;font-size:9pt}
.sl td.k{width:32%;background:#eee;font-size:8pt}.sl td.v{font-family:"Courier New",monospace;font-weight:700;font-size:11pt;direction:ltr;text-align:left;letter-spacing:.3mm}
.sl .u{font-size:7pt;direction:ltr;text-align:center;color:#222}.sl .w{font-size:6.8pt;text-align:center;color:#444;margin-top:.6mm}
.bar{text-align:center;margin:6px}@media print{.bar{display:none}}</style>"""
    return (f'<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8"><title>بطاقات الدخول</title>{css}</head><body>'
            f'<div class="bar"><button onclick="window.print()">🖨️ طباعة</button></div>{body}</body></html>')
