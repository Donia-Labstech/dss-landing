@echo off
title DONIA SMART SCHOOL
cd /d "%~dp0"
echo ============================================
echo   DONIA SMART SCHOOL - starting...
echo ============================================
echo.

set "PY="
where python >nul 2>nul && set "PY=python"
if not defined PY where py >nul 2>nul && set "PY=py -3"
if not defined PY goto nopython

if exist "venv\Scripts\python.exe" goto venvok
echo [1/4] Creating virtual environment (first run only)...
%PY% -m venv venv
if errorlevel 1 goto fail
:venvok
"venv\Scripts\python.exe" -c "import flask,flask_cors,sqlalchemy,jwt,bcrypt,httpx,bs4,openpyxl,dotenv,qrcode,PIL,cryptography" >nul 2>nul
if not errorlevel 1 goto libsok
echo [2/4] Installing required libraries (needs internet)...
"venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>nul
"venv\Scripts\python.exe" -m pip install --only-binary=:all: -r backend\requirements.txt
if errorlevel 1 goto fail
"venv\Scripts\python.exe" -c "import flask,flask_cors,sqlalchemy,jwt,bcrypt,httpx,bs4,openpyxl,dotenv,qrcode,PIL,cryptography"
if errorlevel 1 goto fail
:libsok

if exist "backend\.env" goto envok
echo [3/4] Creating settings file .env ...
copy "backend\.env.example" "backend\.env" >nul
"venv\Scripts\python.exe" -c "import secrets; p='backend/.env'; c=open(p,encoding='utf-8').read(); c=c.replace('CHANGE_ME_RANDOM_SECRET_KEY', secrets.token_hex(32)).replace('CHANGE_ME_RANDOM_HMAC_SECRET', secrets.token_hex(32)); open(p,'w',encoding='utf-8').write(c)"
:envok

if not exist "backend\data" mkdir "backend\data"
if not exist "backend\uploads" mkdir "backend\uploads"
if not exist "backend\uploads\photos" mkdir "backend\uploads\photos"
if not exist "backend\licenses" mkdir "backend\licenses"

echo [4/4] Stopping any old copy still running on port 8000...
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":8000" ^| findstr "LISTENING"') do taskkill /F /PID %%P >nul 2>nul

echo.
echo Login (first run):  admin  /  Donia@2026
echo Browser will open in a few seconds: http://127.0.0.1:8000
echo DO NOT CLOSE THIS WINDOW while using the program.
echo.
start "" cmd /c "timeout /t 5 /nobreak >nul & start http://127.0.0.1:8000"
cd backend
"..\venv\Scripts\python.exe" main.py
echo.
echo *** The server stopped. Read the message above. ***
pause
exit /b 0

:nopython
echo [ERROR] Python was not found on this computer.
echo Install Python 3.10 or newer from https://python.org
echo and tick "Add python.exe to PATH" during installation. Then run this file again.
pause
exit /b 1

:fail
echo.
echo [ERROR] Setup failed. Check your internet connection, delete the "venv" folder, and run again.
pause
exit /b 1
