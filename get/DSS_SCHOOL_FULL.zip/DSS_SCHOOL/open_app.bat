@echo off
rem Opens DONIA SMART SCHOOL in its own app window (Edge/Chrome --app), else in the default browser.
set "URL=http://127.0.0.1:8000"
timeout /t 5 /nobreak >nul
set "E=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%E%" goto run
set "E=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%E%" goto run
set "E=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%E%" goto run
set "E=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%E%" goto run
set "E=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if exist "%E%" goto run
start "" "%URL%"
exit /b 0
:run
start "" "%E%" --app=%URL% --window-size=1280,860
exit /b 0
