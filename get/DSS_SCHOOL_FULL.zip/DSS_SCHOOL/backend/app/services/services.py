"""
DONIA SMART SCHOOL v3 — Services
Grade calc, Absence Decree 833
DONIA LABS TECH © 2026
"""
from datetime import date, timedelta
from typing import Optional
from app.core.config import COMMENTS, DECREE_833


class GradeService:

    @staticmethod
    def calc(fard1=None, fard2=None, activity=None, exam_raw=None,
             has_fard2=True, has_exam=True, is_exempt=False) -> dict:
        if is_exempt:
            return {"exam_20": None, "continuous": None,
                    "term_average": None, "comment": "معفى", "is_exempt": True}
        exam_20 = round(exam_raw / 2, 2) if exam_raw is not None and has_exam else None
        parts, weights = [], []
        if fard1 is not None:
            parts.append(fard1); weights.append(1)
        if has_fard2 and fard2 is not None:
            parts.append(fard2); weights.append(1)
        if activity is not None:
            parts.append(activity); weights.append(1)
        continuous = round(sum(p*w for p,w in zip(parts,weights))/sum(weights),2) if parts else None
        if continuous is not None and exam_20 is not None:
            avg = round((continuous + exam_20 * 2) / 3, 2)
        elif continuous is not None and not has_exam:
            avg = continuous
        elif exam_20 is not None and continuous is None:
            avg = exam_20
        else:
            avg = None
        return {"exam_20": exam_20, "continuous": continuous,
                "term_average": avg, "comment": GradeService.comment(avg), "is_exempt": False}

    @staticmethod
    def comment(avg: Optional[float]) -> str:
        if avg is None:
            return ""
        for lo, hi, c in COMMENTS:
            if lo <= avg <= hi:
                return c
        return ""

    @staticmethod
    def calc_general(subject_grades: list) -> dict:
        pts, coef = 0.0, 0
        for sg in subject_grades:
            if sg.get("is_exempt") or sg.get("term_average") is None:
                continue
            c = sg.get("coefficient", 1)
            pts += sg["term_average"] * c; coef += c
        if coef == 0:
            return {"average": None, "total_points": 0, "total_coeff": 0, "comment": ""}
        avg = round(pts / coef, 2)
        return {"average": avg, "total_points": round(pts, 2),
                "total_coeff": coef, "comment": GradeService.comment(avg)}

    @staticmethod
    def rank(results: list) -> list:
        ranked = sorted(results, key=lambda x: x.get("average") or 0, reverse=True)
        for i, r in enumerate(ranked):
            r["rank"] = i + 1
        return ranked

    @staticmethod
    def council_decision(avg: Optional[float]) -> str:
        if avg is None: return "قيد الدراسة"
        if avg >= 10.0: return "ينتقل"
        if avg >= 8.0: return "قيد الدراسة"
        return "يعيد السنة"


class AbsenceService:

    @staticmethod
    def consecutive(dates: list) -> int:
        if not dates: return 0
        sorted_d = sorted(set(dates))
        mx = cur = 1
        for i in range(1, len(sorted_d)):
            if (sorted_d[i] - sorted_d[i-1]).days <= 3:
                cur += 1; mx = max(mx, cur)
            else:
                cur = 1
        return mx

    @staticmethod
    def check_milestone(consec: int, issued: list) -> Optional[str]:
        if consec >= DECREE_833["warning"] and "إعذار" not in issued:
            return "إعذار"
        if consec >= DECREE_833["second_notice"] and "إشعار_ثاني" not in issued:
            return "إشعار_ثاني"
        if consec >= DECREE_833["first_notice"] and "إشعار_أول" not in issued:
            return "إشعار_أول"
        return None

    @staticmethod
    def should_expel(warning_date: date, today: date = None) -> bool:
        return (today or date.today()) >= warning_date + timedelta(days=DECREE_833["eviction_days"])

    @staticmethod
    def build_notice(notice_type, student, school, days, issued_date,
                     ref1=None, ref2=None, ref3=None) -> dict:
        name = f"{student.get('last_name_ar','')} {student.get('first_name_ar','')}"
        div  = student.get("division", "")
        fmt  = lambda d: d.strftime("%Y-%m-%d") if d else ""
        legal = "بناء على القرار الوزاري رقم : 833 المؤرخ في :1991/11/13 والمتعلق بمواظبة التلاميذ في المؤسسات التعليمية ولا سيما المادة 21 منه"
        base = {
            "school_name": school.get("name_ar",""),
            "wilaya": school.get("wilaya",""),
            "academic_year": school.get("academic_year",""),
            "issued_date": fmt(issued_date),
            "student_name": name, "division": div,
            "absence_days": days, "notice_type": notice_type,
            "legal_ref": legal,
        }
        if notice_type == "إشعار_أول":
            base["subject"] = "الموضوع: الإشعار الأول بالغياب"
            base["body"] = (f"يؤسفني أن أُنهي إلى علمكم بأن ابنكم/ابنتكم : {name}\n"
                           f"المتمدرس(ة) بقسم : {div}\n"
                           f"قد تغيّب عن الدراسة منذ : {fmt(issued_date)} إلى غاية اليوم\n\n"
                           "لذا نطلب منكم الحضور إلى المؤسسة لتبرير الغياب فور إستلامكم هذا الإشعار")
        elif notice_type == "إشعار_ثاني":
            base["subject"] = "الموضوع: الإشعار الثاني بالغياب"
            base["ref1"] = fmt(ref1)
            base["body"] = (f"المرجع: الإشعار الأول بتاريخ: {fmt(ref1)}\n\n"
                           f"يؤسفني أن أُنهي إلى علمكم بأن ابنكم/ابنتكم : {name}\n"
                           f"المتمدرس(ة) بقسم : {div}\n"
                           f"قد تغيّب عن الدراسة منذ : {fmt(issued_date)} إلى غاية اليوم\n\n"
                           "لذا نطلب منكم الحضور إلى المؤسسة لتبرير الغياب فور إستلامكم هذا الإشعار")
        elif notice_type == "إعذار":
            deadline = issued_date + timedelta(days=15)
            base["subject"] = "الموضوع: إعـــذار"
            base["ref1"] = fmt(ref1); base["ref2"] = fmt(ref2)
            base["deadline"] = fmt(deadline)
            base["body"] = (f"المرجع: - الإشعار الأول بتاريخ: {fmt(ref1)}\n"
                           f"        - الإشعار الثاني بتاريخ: {fmt(ref2)}\n\n"
                           f"نطلب الحضور لتبرير غياب : {name} — القسم : {div}\n"
                           "نحيطكم علماً أن عدم الرد سيعرض ابنكم إلى الشطب النهائي "
                           f"بعد 15 يوماً من تاريخ هذا الإعذار ({fmt(deadline)})")
        elif notice_type == "شطب":
            base["subject"] = "الموضوع: الشطب من القائمة الإسمية"
            base["ref1"] = fmt(ref1); base["ref2"] = fmt(ref2); base["ref3"] = fmt(ref3)
            base["body"] = (f"بناء على القرار الوزاري رقم : 833 المؤرخ في :1991/11/13 والمتعلق بمواظبة "
                           f"التلاميذ في المؤسسات التعليمية ولا سيما المادة 21 منه و بعد المراسلات التالية:\n"
                           f"1- الإشعار الأول بتاريخ: {fmt(ref1)}\n"
                           f"2- الإشعار الثاني بتاريخ: {fmt(ref2)}\n"
                           f"3- الإعذار بتاريخ: {fmt(ref3)}\n\n"
                           f"و نظرا لانقطاع ابنكم/ابنتكم: {name} — القسم: {div} عن الدراسة و لعدم "
                           f"استجابتكم لهذه المراسلات، فإنه تم شطب ابنكم/ابنتكم من قوائم المؤسسة "
                           f"ابتداء من تاريخ هذه المراسلة.")
        return base


class DocNumberService:
    PREFIXES = {
        "school_cert": "SCH", "info_form": "INF",
        "first_notice": "ABS1", "second_notice": "ABS2",
        "warning": "WARN", "eviction": "EXP",
        "council": "CNL", "parent_invite": "INV",
        "discipline": "DIS", "id_card": "IDC",
        "leave_request": "LVR", "inquiry": "INQ", "salary_deduction": "SAL",
        "work_certificate": "WRK", "staff_id_card": "SIDC", "parent_letter": "PLT",
        "entry_permit": "ENT",
    }

    @staticmethod
    def gen(doc_type, school_code, seq, year=None) -> str:
        p = DocNumberService.PREFIXES.get(doc_type) or f"X{abs(hash(doc_type)) % 1000:03d}"
        y = (year or "20252026").replace("/", "")
        return f"{p}-{school_code}-{y}-{str(seq).zfill(5)}"


class StaffDocService:
    """توليد وثائق الموارد البشرية للموظفين: طلب رخصة غياب، استفسار، خصم من الراتب."""

    LEGAL_REFS = (
        "بمقتضى الأمر رقم 06/03 المؤرخ في 19 جمادى الثانية عام 1423 الموافق ل 15 يوليو 2006 "
        "المتضمن القانون الأساسي العام للوظيفة العمومية.\n"
        "بمقتضى المرسوم رقم 82/302 المؤرخ في 11/09/1982 المتضمن كيفية تطبيق الأحكام التشريعية "
        "الخاصة بعلاقات العمل الفردية.\n"
        "بمقتضى المرسوم التنفيذي رقم 25-54 المؤرخ في 21 رجب عام 1446 الموافق 21 جانفي سنة 2025 "
        "المتضمن القانون الأساسي الخاص بالموظفين المنتمين للأسلاك الخاصة بالتربية الوطنية."
    )

    @staticmethod
    def build_leave_request(staff_name, school, start_date, end_date, reason) -> dict:
        return {
            "school_name": school.get("name_ar",""), "wilaya": school.get("wilaya",""),
            "academic_year": school.get("academic_year",""),
            "subject": "الموضوع: طلب رخصة غياب",
            "staff_name": staff_name, "start_date": start_date, "end_date": end_date, "reason": reason,
            "body": (f"يشرفني أن أتقدم لسيادتكم المحترمة بطلبي هذا المتضمن طلب تغيّب لمدة:\n"
                     f"ابتداءً من يوم: {start_date}   إلى غاية: {end_date}\n"
                     f"بسبب: {reason}")
        }

    @staticmethod
    def build_inquiry(staff_name, school, reason) -> dict:
        return {
            "school_name": school.get("name_ar",""), "wilaya": school.get("wilaya",""),
            "academic_year": school.get("academic_year",""),
            "subject": "استفسار", "staff_name": staff_name,
            "legal_ref": StaffDocService.LEGAL_REFS,
            "body": (f"{StaffDocService.LEGAL_REFS}\n\n"
                     f"المطلوب منكم تبرير سبب: {reason}\n(الجواب يكون خلال 24 ساعة)")
        }

    @staticmethod
    def build_work_certificate(staff_name, role_label, school, hire_date) -> dict:
        return {
            "school_name": school.get("name_ar",""), "wilaya": school.get("wilaya",""),
            "academic_year": school.get("academic_year",""),
            "subject": "شهادة عمل", "staff_name": staff_name,
            "body": (f"يشهد السيد(ة) مدير(ة) {school.get('name_ar','')} أن السيد(ة): {staff_name}\n"
                     f"يعمل(تعمل) بهذه المؤسسة بصفة: {role_label}\n"
                     f"{('تاريخ الالتحاق بالعمل: ' + str(hire_date)) if hire_date else ''}\n"
                     f"وقد سُلّمت له(ا) هذه الشهادة لتُستعمل عند الحاجة.")
        }

    @staticmethod
    def build_salary_deduction(staff_name, school, days, reason) -> dict:
        return {
            "school_name": school.get("name_ar",""), "wilaya": school.get("wilaya",""),
            "academic_year": school.get("academic_year",""),
            "subject": "الموضوع: الخصم من الراتب", "staff_name": staff_name,
            "legal_ref": ("بمقتضى القانون رقم 82/06 المؤرخ في 12/02/1982 المتعلق بالعلاقات الفردية للعمل.\n"
                         + StaffDocService.LEGAL_REFS),
            "days": days, "reason": reason,
            "body": (f"يُقرر: يُخصم من مرتبكم الشهري ما يعادل {days} يوماً\n"
                     f"وذلك للأسباب التالية: {reason}")
        }


class DisciplineService:
    """توليد وثائق مسار التأديب: استدعاء الولي + إشعار توجيه عقوبة"""

    @staticmethod
    def build_summon(student, school, issued_date, reason, meeting_time="") -> dict:
        name = f"{student.get('last_name_ar','')} {student.get('first_name_ar','')}"
        div = student.get("division", "")
        return {
            "school_name": school.get("name_ar", ""),
            "wilaya": school.get("wilaya", ""),
            "academic_year": school.get("academic_year", ""),
            "issued_date": issued_date.strftime("%Y-%m-%d"),
            "student_name": name, "division": div,
            "subject": "الموضوع: إستدعاء الولي",
            "meeting_time": meeting_time, "reason": reason,
            "body": (f"ندعو السيد(ة) ولي(ة) التلميذ(ة): {name}\n"
                     f"المتمدرس(ة) بقسم: {div}\n"
                     f"للحضور إلى المؤسسة{(' يوم: ' + meeting_time) if meeting_time else ''}\n"
                     f"وذلك بخصوص: {reason}")
        }

    @staticmethod
    def build_sanction_notice(student, school, issued_date, violation, sanction) -> dict:
        name = f"{student.get('last_name_ar','')} {student.get('first_name_ar','')}"
        div = student.get("division", "")
        legal = ("استنادا إلى نظام الجماعة التربوية المطبق في المؤسسات التعليمية الفصل الثالث "
                 "أحكام خاصة بالتلاميذ المؤرخ في 12/07/2018 تحت رقم 65، وبناء على المادة 19 من "
                 "القرار رقم 73 المؤرخ في 12/07/2018 المتضمن إنشاء مجلس التأديب وتنظيمه، وبناء على "
                 "القرار الوزاري رقم 833 المتعلق بمواظبة التلاميذ في المؤسسات التعليمية ولا سيما "
                 "المادة 17 من نفس القرار.")
        return {
            "school_name": school.get("name_ar", ""),
            "wilaya": school.get("wilaya", ""),
            "academic_year": school.get("academic_year", ""),
            "issued_date": issued_date.strftime("%Y-%m-%d"),
            "student_name": name, "division": div,
            "subject": "إشعار بتوجيه عقوبة من الدرجة",
            "legal_ref": legal,
            "violation": violation, "sanction": sanction,
            "body": f"نظراً لارتكابكم المخالفة الآتية:\n{violation}\n\nيُقرر ما يلي: توجيه {sanction} لها."
        }
