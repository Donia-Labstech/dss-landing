"""
التقرير اليومي لمستشار التربية — محرّك التركيب والحفظ.

يطابق نموذج «التقرير اليومي لمستشار التربية» المعتمد في المؤسسات الجزائرية:
  1- الدراسة:   1.1 دروس لم تقدَّم (غياب الأساتذة بالحصص)   2.1 الإجراءات المتخذة
  2- المواظبة:  مواظبة التلاميذ بالأفواج والمستويات
  3- حركة التلاميذ: تغيّرات التعداد (داخلي / نصف داخلي / خارجي × ذكور/إناث)
  4- الإطعام
  5- الحوصلة:   التلاميذ / الأساتذة / المشرفون / المساعدون التربويون الغائبون
  6- التلاميذ الغائبون إلى نهاية اليوم مع الإشعار الأول والثاني والإعذار
  + ملاحظات واقتراحات مستشار التربية وتوجيهات المدير

كل الأرقام تُحسب من البيانات الحيّة (التلاميذ، الغيابات، استعمال الزمن، الإشعارات)؛
ما لا يمكن اشتقاقه (الإجراءات، الوجبة، المساعدون الغائبون...) يدخله المستشار يدوياً
ويُحفظ في DailyReport.extra_json. لا شيء هنا بأرقام تجريبية.
"""
import json
from datetime import date, timedelta

from app.core.config import DECREE_833
from app.core.database import (
    Student, Division, Absence, AbsenceNotice, DailyReport, DailyAbsenceLog,
    ScheduleEntry, Teacher, Subject, User, TeacherAbsence, SchoolHoliday,
)

CATS = ("داخلي", "نصف داخلي", "خارجي")
WEEKDAY_AR = ["الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"]  # date.weekday()
ORD = {1: "الأولى", 2: "الثانية", 3: "الثالثة", 4: "الرابعة"}
SUFFIX = {"متوسطة": "متوسط", "ثانوية": "ثانوي", "ابتدائية": "ابتدائي"}
EXTRA_KEYS = ("actions", "movement", "meal", "supervisors_registered", "supervisors_absent",
              "assistants_absent")


def to_date(v):
    if isinstance(v, date):
        return v
    return date.fromisoformat(str(v)[:10])


def day_idx(d):
    """فهرس يوم الجدول الزمني: 0=السبت … 5=الخميس، و6=الجمعة (لا دراسة في الجدول)."""
    return (d.weekday() + 2) % 7


def period_labels(si):
    labels = [f"ص{i}" for i in range(1, (si.periods_morning or 4) + 1)]
    labels += [f"م{i}" for i in range(1, (si.periods_evening or 4) + 1)]
    return labels


def _cat(student):
    return student.status if student.status in ("داخلي", "نصف داخلي") else "خارجي"


def _gkey(student):
    return "m" if (student.gender or "").strip() in ("ذكر", "ذكور", "m", "M") else "f"


class _Cal:
    """تقويم المدرسة: أيام الراحة الأسبوعية المستنتجة من استعمال الزمن + العطل."""

    def __init__(self, db, si):
        q = db.query(ScheduleEntry.day_of_week)
        yr = si.academic_year
        rows = q.filter(ScheduleEntry.academic_year == yr).distinct().all() or q.distinct().all()
        self.study_idx = {r[0] for r in rows if r[0] is not None and 0 <= r[0] <= 5} or {1, 2, 3, 4, 5}
        self.holidays = [(h.date_from, h.date_to, h.label) for h in db.query(SchoolHoliday).all()]

    def holiday(self, d):
        for a, b, lab in self.holidays:
            if a <= d <= b:
                return lab or "عطلة"
        return ""

    def is_school_day(self, d):
        return day_idx(d) in self.study_idx and not self.holiday(d)

    def prev_school_day(self, d, limit=60):
        c = d
        for _ in range(limit):
            c -= timedelta(days=1)
            if self.is_school_day(c):
                return c
        return c

    def report_number(self, d):
        y = d.year if d.month >= 9 else d.year - 1
        c, n = date(y, 9, 1), 0
        while c <= d:
            if self.is_school_day(c):
                n += 1
            c += timedelta(days=1)
        return n


def _enrolled_students(db, d):
    out = []
    for s in db.query(Student).filter(Student.division_id.isnot(None)).all():
        if s.entry_date and s.entry_date > d:
            continue
        if s.is_expelled and (s.expelled_date is None or s.expelled_date <= d):
            continue
        if not s.is_active and not s.is_expelled:
            continue
        out.append(s)
    return out


def _schedule_for(db, si, d):
    q = db.query(ScheduleEntry).filter(ScheduleEntry.day_of_week == day_idx(d))
    rows = q.filter(ScheduleEntry.academic_year == si.academic_year).all() or q.all()
    return rows


def compose(db, si, d):
    d = to_date(d)
    cal = _Cal(db, si)
    labels = period_labels(si)
    pm = si.periods_morning or 4

    divs = {x.id: x for x in db.query(Division).all()}
    entries = _schedule_for(db, si, d)
    teachers = {t.id: t for t in db.query(Teacher).all()}
    subjects = {x.id: x.name_ar for x in db.query(Subject).all()}

    # ── الأساتذة المبرمجون اليوم + شبكة حصصهم (لتسهيل إدخال الغياب) ──
    sched = {}
    for e in entries:
        for tid in (e.teacher_id, e.co_teacher_id):
            if not tid or tid not in teachers:
                continue
            t = teachers[tid]
            row = sched.setdefault(tid, {"id": tid, "name": f"{t.last_name} {t.first_name}".strip(),
                                         "subject": t.specialty or "", "slots": {}})
            dv = divs.get(e.division_id)
            row["slots"][e.period] = e.label or (dv.name if dv else "")
            if e.subject_id in subjects and not row["subject"]:
                row["subject"] = subjects[e.subject_id]
    scheduled = sorted(sched.values(), key=lambda r: r["name"])

    # ── 1.1 الدروس التي لم تقدّم ──
    t_abs = []
    for a in db.query(TeacherAbsence).filter(TeacherAbsence.date == d).order_by(TeacherAbsence.id).all():
        periods = [p for p in (a.periods or "").split(",") if p]
        try:
            slots = json.loads(a.slots or "{}")
        except Exception:
            slots = {}
        auto = sched.get(a.teacher_id, {}).get("slots", {})
        for p in periods:
            slots.setdefault(p, auto.get(p, ""))
        t_abs.append({"id": a.id, "teacher_id": a.teacher_id, "teacher_name": a.teacher_name,
                      "subject": a.subject, "periods": periods, "slots": slots,
                      "hours": len(periods), "reason": a.reason or "", "notes": a.notes or ""})
    absent_hours = sum(x["hours"] for x in t_abs)
    volume = len(entries)

    # ── 2 المواظبة ──
    students = _enrolled_students(db, d)
    abs_rows = db.query(Absence).filter(Absence.date == d).all()
    absent_ids = {a.student_id for a in abs_rows}
    by_div = {}
    for s in students:
        r = by_div.setdefault(s.division_id, {"enrolled": 0, "absent": 0})
        r["enrolled"] += 1
        if s.id in absent_ids:
            r["absent"] += 1
    levels = {}
    for did, r in by_div.items():
        dv = divs.get(did)
        if not dv:
            continue
        lv = levels.setdefault(dv.level, {"level": dv.level, "divisions": []})
        lv["divisions"].append({"id": did, "name": dv.name, "section": dv.section,
                                "enrolled": r["enrolled"], "absent": r["absent"],
                                "pct": round(r["absent"] / r["enrolled"] * 100, 2) if r["enrolled"] else 0})
    suffix = SUFFIX.get((si.level_type or "متوسطة").strip(), "متوسط")
    lvl_out = []
    for k in sorted(levels):
        lv = levels[k]
        lv["divisions"].sort(key=lambda x: (str(x["section"]).zfill(3), x["name"]))
        en = sum(x["enrolled"] for x in lv["divisions"])
        ab = sum(x["absent"] for x in lv["divisions"])
        lv.update({"label": f"{ORD.get(k, str(k))} {suffix}", "enrolled": en, "absent": ab,
                   "pct": round(ab / en * 100, 2) if en else 0})
        lvl_out.append(lv)
    tot_en = sum(l["enrolled"] for l in lvl_out)
    tot_ab = sum(l["absent"] for l in lvl_out)

    rep = db.query(DailyReport).filter(DailyReport.report_date == d).first()
    try:
        extra = json.loads((rep.extra_json if rep else "") or "{}")
    except Exception:
        extra = {}

    # ── 3 حركة التلاميذ ──
    mv_extra = extra.get("movement") or {}
    movement = {}
    for c in CATS:
        movement[c] = {}
        for g in ("m", "f"):
            now = sum(1 for s in students if _cat(s) == c and _gkey(s) == g)
            auto_in = sum(1 for s in students if s.entry_date == d and _cat(s) == c and _gkey(s) == g)
            movement[c][g] = {"now": now, "in": auto_in, "out": 0}
    # الخروج التلقائي (يُحسب مرة واحدة لتفادي استعلامات متكررة)
    for s in db.query(Student).filter(Student.expelled_date == d, Student.is_expelled == True).all():  # noqa: E712
        movement[_cat(s)][_gkey(s)]["out"] += 1
    for c in CATS:
        for g in ("m", "f"):
            ov = ((mv_extra.get(c) or {}).get(g)) or {}
            cell = movement[c][g]
            cell["in_manual"] = ov.get("in") not in (None, "")
            cell["out_manual"] = ov.get("out") not in (None, "")
            if cell["in_manual"]:
                cell["in"] = int(ov["in"])
            if cell["out_manual"]:
                cell["out"] = int(ov["out"])
            cell["yesterday"] = cell["now"] - cell["in"] + cell["out"]

    # ── 4 الإطعام ──
    can = [s for s in students if _cat(s) in ("داخلي", "نصف داخلي")]
    canteen = {}
    for g in ("m", "f"):
        reg = sum(1 for s in can if _gkey(s) == g)
        ab = sum(1 for s in can if _gkey(s) == g and s.id in absent_ids)
        canteen[g] = {"registered": reg, "absent": ab, "present": reg - ab}
    meal = extra.get("meal") or {}
    meal = {"label": meal.get("label") or "وجبة الغداء", "items": (meal.get("items") or [])[:6]}

    # ── 5 الحوصلة ──
    t_registered = len(scheduled) or db.query(Teacher).filter(Teacher.is_active == True).count()  # noqa: E712
    t_absent_names = {(x["teacher_id"] or 0, x["teacher_name"]) for x in t_abs}
    sup_default = db.query(User).filter(User.role == "supervisor", User.is_active == True).count()  # noqa: E712
    sup_reg = extra.get("supervisors_registered")
    sup_reg = sup_default if sup_reg in (None, "") else int(sup_reg)
    sup_abs = int(extra.get("supervisors_absent") or 0)
    summary = {
        "students": {"registered": tot_en, "absent": tot_ab, "present": tot_en - tot_ab},
        "teachers": {"registered": t_registered, "absent": len(t_absent_names),
                     "present": max(t_registered - len(t_absent_names), 0)},
        "supervisors": {"registered": sup_reg, "absent": sup_abs, "present": max(sup_reg - sup_abs, 0)},
        "assistants_absent": list(extra.get("assistants_absent") or []),
    }

    # ── 6 التلاميذ الغائبون إلى نهاية اليوم ──
    by_id = {s.id: s for s in students}
    ab_students = [by_id[i] for i in absent_ids if i in by_id]
    win_start = d - timedelta(days=120)
    hist = {}
    if ab_students:
        ids = [s.id for s in ab_students]
        for a in db.query(Absence).filter(Absence.student_id.in_(ids), Absence.date >= win_start,
                                          Absence.date <= d).all():
            hist.setdefault(a.student_id, set()).add(a.date)
    notices = {}
    if ab_students:
        for n in db.query(AbsenceNotice).filter(AbsenceNotice.student_id.in_([s.id for s in ab_students])).all():
            notices.setdefault(n.student_id, {})[n.notice_type] = n.issued_date
    today_status = {}
    for a in abs_rows:
        today_status.setdefault(a.student_id, []).append(a.status or "")
    absentees = []
    for s in ab_students:
        dates = hist.get(s.id, set())
        since, n, cur = d, 1, d
        for _ in range(90):
            cur = cal.prev_school_day(cur)
            if cur in dates:
                since, n = cur, n + 1
            else:
                break
        nt = notices.get(s.id, {})

        def cell(key, thr):
            if nt.get(key):
                return {"date": str(nt[key]), "issued": True}
            return {"date": "", "issued": False, "due": n >= thr}

        sts = today_status.get(s.id, [])
        just = "مبرر" if sts and all(x == "مبرر" for x in sts) else ""
        dv = divs.get(s.division_id)
        absentees.append({
            "student_id": s.id, "name": f"{s.last_name_ar} {s.first_name_ar}",
            "reg": s.registration_num or "", "division": dv.name if dv else "",
            "since": str(since), "days": n,
            "n1": cell("إشعار_أول", DECREE_833["first_notice"]),
            "n2": cell("إشعار_ثاني", DECREE_833["second_notice"]),
            "n3": cell("إعذار", DECREE_833["warning"]),
            "note": (just or ("جديد" if n == 1 else f"{n} أيام متتالية")),
        })
    absentees.sort(key=lambda r: (r["division"], r["name"]))

    holiday = cal.holiday(d)
    return {
        "date": str(d), "weekday": WEEKDAY_AR[d.weekday()],
        "number": (rep.report_number if rep and rep.report_number else cal.report_number(d)),
        "is_school_day": cal.is_school_day(d), "holiday": holiday,
        "header": {"school": si.name_ar, "wilaya": si.wilaya, "commune": si.commune,
                   "year": si.academic_year, "counselor": si.counselor_name,
                   "director": si.director_name, "level_type": si.level_type},
        "periods": {"labels": labels, "morning": pm},
        "scheduled_teachers": scheduled,
        "teacher_absences": t_abs,
        "daily_volume": volume, "teacher_absent_hours": absent_hours,
        "teacher_absent_pct": round(absent_hours / volume * 100, 2) if volume else 0,
        "actions": extra.get("actions", ""),
        "levels": lvl_out,
        "totals": {"enrolled": tot_en, "absent": tot_ab, "present": tot_en - tot_ab,
                   "pct": round(tot_ab / tot_en * 100, 2) if tot_en else 0},
        "movement": movement, "canteen": canteen, "meal": meal,
        "summary": summary, "absentees": absentees,
        "notes": {"counselor": rep.counselor_notes if rep else "", "director": rep.director_notes if rep else ""},
        "extra": {k: extra.get(k) for k in EXTRA_KEYS},
        "saved": bool(rep),
    }


def save(db, si, d, payload, role, user_id=None):
    """يحفظ مدخلات المستشار اليدوية + غياب الأساتذة + الملاحظات، ثم يخزّن حوصلة اليوم
    في DailyReport/DailyAbsenceLog (لقائمة التقارير). ملاحظات المدير لا يعدّلها إلا
    المدير أو الناظر."""
    d = to_date(d)
    cal = _Cal(db, si)
    rep = db.query(DailyReport).filter(DailyReport.report_date == d).first()
    if not rep:
        rep = DailyReport(report_date=d)
        db.add(rep)
        db.flush()
    try:
        extra = json.loads(rep.extra_json or "{}")
    except Exception:
        extra = {}
    for k in EXTRA_KEYS:
        if k in payload:
            extra[k] = payload[k]
    rep.extra_json = json.dumps(extra, ensure_ascii=False)
    if "counselor_notes" in payload:
        rep.counselor_notes = str(payload["counselor_notes"] or "")[:4000]
    if "director_notes" in payload and role in ("director", "nazir"):
        rep.director_notes = str(payload["director_notes"] or "")[:4000]
    rep.counselor_name = si.counselor_name or rep.counselor_name or ""
    rep.report_number = cal.report_number(d)

    if "teacher_absences" in payload:
        valid = set(period_labels(si))
        db.query(TeacherAbsence).filter(TeacherAbsence.date == d).delete()
        for x in payload["teacher_absences"] or []:
            periods = [p for p in (x.get("periods") or []) if p in valid]
            name = str(x.get("teacher_name") or "").strip()[:150]
            if not name or not periods:
                continue
            db.add(TeacherAbsence(
                date=d, teacher_id=x.get("teacher_id") or None, teacher_name=name,
                subject=str(x.get("subject") or "")[:100], periods=",".join(periods),
                slots=json.dumps({p: str((x.get("slots") or {}).get(p, ""))[:30] for p in periods},
                                 ensure_ascii=False),
                reason=str(x.get("reason") or "")[:100], notes=str(x.get("notes") or "")[:1000]))
    db.flush()

    c = compose(db, si, d)
    rep.total_registered = c["totals"]["enrolled"]
    rep.total_absent = c["totals"]["absent"]
    rep.total_present = c["totals"]["present"]
    rep.absence_percentage = c["totals"]["pct"]
    rep.total_absence_hours = c["teacher_absent_hours"]
    rep.canteen_reg_m = c["canteen"]["m"]["registered"]
    rep.canteen_reg_f = c["canteen"]["f"]["registered"]
    rep.canteen_pres_m = c["canteen"]["m"]["present"]
    rep.canteen_pres_f = c["canteen"]["f"]["present"]
    db.query(DailyAbsenceLog).filter(DailyAbsenceLog.report_id == rep.id).delete()
    for lv in c["levels"]:
        for dv in lv["divisions"]:
            db.add(DailyAbsenceLog(report_id=rep.id, division_id=dv["id"],
                                   registered=dv["enrolled"], absent=dv["absent"]))
    db.commit()
    return compose(db, si, d)


# ═════════════════════ الطباعة: نفس شكل نموذج التقرير اليومي ═════════════════════
def _esc(x):
    return (str(x if x is not None else "").replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;"))


def _fd(s):
    return str(s).replace("-", "/") if s else ""


_CSS = """
@page { size: A4 portrait; margin: 6mm 8mm; }
* { box-sizing: border-box; }
body { font-family: 'Traditional Arabic','Arial',sans-serif; font-size: 10px; color:#000; direction: rtl; margin:0; }
.btnbar { text-align:center; margin: 6px 0; } @media print { .btnbar { display:none; } }
.pg { page-break-after: always; } .pg:last-child { page-break-after: auto; }
.c { text-align:center; } .b { font-weight:bold; }
.top { text-align:center; font-weight:bold; font-size:13px; line-height:1.5; }
.row2 { display:flex; justify-content:space-between; font-weight:bold; margin-top:4px; font-size:12px; }
.title { text-align:center; font-weight:bold; font-size:15px; margin: 6px 0; }
h4 { margin: 4px 0 1px; font-size:11.5px; }
table { width:100%; border-collapse:collapse; margin: 1px 0 3px; table-layout: fixed; }
th, td { border:1px solid #000; padding: 0 2px; text-align:center; font-size:10px; height: 14.5px; line-height:1.15; overflow:hidden; }
th { background:#f2f2f2; }
td.l { text-align:right; }
.two { display:flex; gap:8px; align-items:flex-start; } .two > div { flex:1; }
.sig { display:flex; justify-content:space-between; margin-top:4px; font-weight:bold; font-size:11px; }
.box { border:1px solid #000; height: 70px; padding: 4px; white-space: pre-wrap; font-size:11px; }
.nt { display:flex; width:100%; border:1px solid #000; margin-top:8px; } .nt .h { flex:0 0 22%; border-left:1px solid #000; padding:4px; text-align:center; font-weight:bold; display:flex; align-items:center; justify-content:center; }
.nt .t { flex:1; min-width:0; min-height:70px; padding:4px; white-space:pre-wrap; } .nt .s { flex:0 0 12%; border-right:1px solid #000; padding:4px; text-align:center; }
.due { font-size:9px; color:#000; }
"""


def _pad(rows, n):
    return rows + [None] * max(n - len(rows), 0)


def render_html(c, si):
    labels = c["periods"]["labels"]
    pm = c["periods"]["morning"]
    ncol = len(labels)
    H = c["header"]
    num = str(c["number"]).zfill(3)
    d = c["date"]

    # ── 1.1 دروس لم تقدّم ──
    hdr1 = "".join(f"<th>{i + 1}</th>" for i in range(ncol))
    rows = _pad(c["teacher_absences"], 10)
    body1 = ""
    for i, a in enumerate(rows, 1):
        if a is None:
            body1 += f"<tr><td class='b'>{i}</td><td></td><td></td><td>0</td>" + "<td></td>" * ncol + "<td></td><td></td></tr>"
            continue
        cells = "".join(f"<td>{_esc(a['slots'].get(p, '')) if p in a['periods'] else ''}</td>" for p in labels)
        body1 += (f"<tr><td class='b'>{i}</td><td class='l'>{_esc(a['teacher_name'])}</td><td>{_esc(a['subject'])}</td>"
                  f"<td>{a['hours']}</td>{cells}<td>{_esc(a['reason'])}</td><td>{_esc(a['notes'])}</td></tr>")
    sec1 = f"""
<h4>1- الدراسة :</h4><h4>1.1- دروس لم تقدّم :</h4>
<table><colgroup><col style="width:4%"><col style="width:20%"><col style="width:11%"><col style="width:6%">{'<col>' * ncol}<col style="width:11%"><col style="width:13%"></colgroup>
<thead><tr><th rowspan="2">الرقم</th><th rowspan="2">لقب واسم الأستاذ (ة)</th><th rowspan="2">المادة</th><th rowspan="2">ساعات الغياب</th>
<th colspan="{pm}">صباحا</th><th colspan="{ncol - pm}">مساء</th><th rowspan="2">سبب الغياب</th><th rowspan="2">ملاحظات</th></tr>
<tr>{hdr1}</tr></thead><tbody>{body1}
<tr><td colspan="3" class="b">الحجم الساعي اليومي : {c['daily_volume']}</td><td colspan="{ncol // 2 + 1}" class="b">مجموع ساعات الغياب : {c['teacher_absent_hours']}</td>
<td colspan="{ncol - ncol // 2 + 2}" class="b">النسبة المئوية لغيابات اليوم : {c['teacher_absent_pct']:.2f}%</td></tr></tbody></table>
<h4>2.1- الإجراءات المتخذة : (الاستعجالية و الميدانية)</h4>
<div class="box" style="height:34px">{_esc(c['actions'])}</div>"""

    # ── 2 المواظبة ──
    sec2 = "<h4>2- المواظبة :</h4><h4>1.2 - مواظبة التلاميذ :</h4>"
    if not c["levels"]:
        sec2 += "<p class='c'>لا توجد أقسام مسجلة.</p>"
    for lv in c["levels"]:
        divs = lv["divisions"]
        for off in range(0, len(divs), 12):
            chunk = divs[off:off + 12]
            pad = 12 - len(chunk)
            first = off == 0
            hd = "".join(f"<td class='b'>{_esc(x['name'])}</td>" for x in chunk) + "<td></td>" * pad
            en = "".join(f"<td>{x['enrolled']}</td>" for x in chunk) + "<td></td>" * pad
            ab = "".join(f"<td>{x['absent']}</td>" for x in chunk) + "<td></td>" * pad
            pc = "".join(f"<td>{x['pct']:.2f}%</td>" for x in chunk) + "<td></td>" * pad
            sm = (("الحوصلة", "", "تعداد المستوى", lv["enrolled"], "عدد غياب المستوى", lv["absent"],
                   "نسبة غياب المستوى", f"{lv['pct']:.2f}%") if first else ("",) * 8)
            sec2 += f"""<table style="margin:1px 0"><colgroup><col style="width:10%">{'<col style="width:5.2%">' * 12}<col style="width:17%"><col style="width:10.6%"></colgroup>
<tr><td class="b">{_esc(lv['label']) if first else ''}</td>{hd}<td colspan="2" class="b">{sm[0]}</td></tr>
<tr><td>تعداد الفوج</td>{en}<td>{sm[2]}</td><td>{sm[3]}</td></tr>
<tr><td>عدد غياب الفوج</td>{ab}<td>{sm[4]}</td><td>{sm[5]}</td></tr>
<tr><td>نسبة الغياب</td>{pc}<td>{sm[6]}</td><td>{sm[7]}</td></tr></table>"""
    t = c["totals"]
    sec2 += f"""<table><tr><td class="b">عدد التلاميذ الحاضرين لنهاية اليوم : {t['present']}</td>
<td class="b">عدد التلاميذ الغائبين اليوم : {t['absent']}</td><td class="b">النسبة المئوية لغيابات اليوم : {t['pct']:.2f}%</td></tr></table>"""

    # ── 3 حركة التلاميذ + 4 الإطعام ──
    mv = c["movement"]

    def line(key):
        out, tm, tf = "", 0, 0
        for cat in CATS:
            m, f = mv[cat]["m"][key], mv[cat]["f"][key]
            out += f"<td>{m}</td><td>{f}</td>"
            tm += m
            tf += f
        return out + f"<td>{tm}</td><td>{tf}</td><td>{tm + tf}</td>"

    sec3 = f"""<h4>3- حركـــــــــة التلاميذ :</h4><h4>3.1 - تغيرات التعداد :</h4>
<table><colgroup><col style="width:11%"><col style="width:8%">{'<col>' * 8}<col style="width:10%"></colgroup>
<tr><th colspan="2" rowspan="2">عدد التلاميذ</th><th colspan="2">داخلي</th><th colspan="2">نصف داخلي</th><th colspan="2">خارجي</th><th colspan="2">المجموع</th><th rowspan="2">المجموع العام</th></tr>
<tr><th>ذكور</th><th>إناث</th><th>ذكور</th><th>إناث</th><th>ذكور</th><th>إناث</th><th>ذكور</th><th>إناث</th></tr>
<tr><td class="b" colspan="2">تعداد الأمس</td>{line('yesterday')}</tr>
<tr><td class="b" rowspan="2">حركة التلاميذ</td><td>دخول</td>{line('in')}</tr>
<tr><td>خروج</td>{line('out')}</tr>
<tr><td class="b" colspan="2">تعداد اليوم الكلي</td>{line('now')}</tr></table>"""
    cn = c["canteen"]
    items = (c["meal"]["items"] + ["", "", "", ""])[:4]
    sec4 = f"""<h4>4- الاطعام:</h4>
<table><tr><th colspan="3">المطعم</th><th colspan="4">{_esc(c['meal']['label'])}</th></tr>
<tr><th rowspan="2" style="width:16%">التلاميذ</th><th>ذكور</th><th>إناث</th><td rowspan="4" colspan="4" style="vertical-align:middle">{'<br>'.join(_esc(x) for x in items if x)}</td></tr>
<tr><th></th><th></th></tr>
<tr><td class="b">الحاضرون</td><td>{cn['m']['present']}</td><td>{cn['f']['present']}</td></tr>
<tr><td class="b">الغائبون</td><td>{cn['m']['absent']}</td><td>{cn['f']['absent']}</td></tr>
<tr><td class="b">المجموع</td><td>{cn['m']['registered']}</td><td>{cn['f']['registered']}</td><td colspan="4"></td></tr></table>"""

    # ── 5 الحوصلة ──
    sm = c["summary"]
    ass = "<br>".join(_esc(x) for x in sm["assistants_absent"])
    sec5 = f"""<h4>5- الحوصلة :</h4>
<div class="two"><div style="flex:3"><table><tr><th style="width:14%"></th><th>التلاميذ</th><th>الأساتذة العاملون اليوم</th><th>مشرفوا التربية العاملون اليوم</th></tr>
<tr><td class="b">المسجلون</td><td>{sm['students']['registered']}</td><td>{sm['teachers']['registered']}</td><td>{sm['supervisors']['registered']}</td></tr>
<tr><td class="b">الغائبون</td><td>{sm['students']['absent']}</td><td>{sm['teachers']['absent']}</td><td>{sm['supervisors']['absent']}</td></tr>
<tr><td class="b">الحاضرون</td><td>{sm['students']['present']}</td><td>{sm['teachers']['present']}</td><td>{sm['supervisors']['present']}</td></tr></table></div>
<div style="flex:1.3"><table><tr><th>المساعدون التربويون الغائبين</th></tr><tr><td style="height:42px;vertical-align:top">{ass}</td></tr></table></div></div>"""
    place = _esc(H["commune"] or H["wilaya"])
    sig = f"""<div class="sig"><div>ع/ مستشار التربية<br>{_esc(H['counselor'])}</div>
<div>إطلع عليه المدير<br>{place} في : {_fd(d)}</div></div>"""

    head = f"""<div class="top">الجمهورية الجزائرية الديمقراطية الشعبية<br>وزارة التربية الوطنية</div>
<div class="row2"><div>مديرية التربية لولاية {_esc(H['wilaya'])}</div><div>{_esc(H['school'])}</div></div>
<div class="title">التقرير اليومي لمستشار التربية رقم : {num}</div>
<div class="row2"><div>{c['weekday']}<br>{_fd(d)}</div><div></div></div>"""

    page1 = f"<div class='pg'>{head}{sec1}{sec2}<div class='two'><div style='flex:1.7'>{sec3}</div><div style='flex:1'>{sec4}</div></div>{sec5}{sig}</div>"

    # ── 6 الغائبون ──
    ab = c["absentees"]
    per_page = 42
    allrows = _pad(ab, max(per_page, len(ab)))
    rows6 = ""
    for i, a in enumerate(allrows, 1):
        if a is None:
            rows6 += f"<tr><td class='b'>{i:02d}</td>" + "<td></td>" * 7 + "</tr>"
            continue

        def nc(x):
            return _fd(x["date"]) if x["issued"] else ("<span class='due'>يستحق</span>" if x.get("due") else "")
        rows6 += (f"<tr><td class='b'>{i:02d}</td><td class='l'>{_esc(a['name'])}</td><td>{_esc(a['division'])}</td>"
                  f"<td>{_fd(a['since'])}</td><td>{nc(a['n1'])}</td><td>{nc(a['n2'])}</td><td>{nc(a['n3'])}</td>"
                  f"<td>{_esc(a['note'])}</td></tr>")
    page2 = f"""<div class="pg"><h4>6- التلاميذ الغائبون إلى نهاية اليوم :</h4>
<table><colgroup><col style="width:5%"><col style="width:28%"><col style="width:9%"><col style="width:14%"><col style="width:13%"><col style="width:13%"><col style="width:10%"><col style="width:12%"></colgroup>
<thead><tr><th>الرقم</th><th>اللقب و الاسم</th><th>القسم</th><th>غائب منذ</th><th>إشعار 1</th><th>إشعار 2</th><th>إعذار</th><th>ملاحظات</th></tr></thead>
<tbody>{rows6}<tr><td colspan="2" class="b">المجموع</td><td class="b">{len(ab)}</td><td colspan="5"></td></tr></tbody></table>
<div class="nt"><div class="h">ملاحظات اقتراحات مستشار التربية</div><div class="t">{_esc(c['notes']['counselor'])}</div><div class="s">الإمضاء</div></div>
<div class="nt"><div class="h">ملاحظات و توجيهات مدير المؤسسة</div><div class="t">{_esc(c['notes']['director'])}</div><div class="s">الإمضاء</div></div></div>"""
    return (f"<!DOCTYPE html><html dir='rtl' lang='ar'><head><meta charset='UTF-8'>"
            f"<title>التقرير اليومي لمستشار التربية {num}</title><style>{_CSS}</style></head><body>"
            f"<div class='btnbar'><button onclick='window.print()'>🖨️ طباعة</button></div>{page1}{page2}</body></html>")
