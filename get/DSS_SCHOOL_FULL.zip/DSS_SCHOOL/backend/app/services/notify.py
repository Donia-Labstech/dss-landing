"""
DONIA SMART SCHOOL v3 — Notification Service
إشعارات تلقائية (بريد إلكتروني / واتساب) عند غياب التلميذ.
يتبع نفس نمط تعدّد المزوّدين المعتمد في app/agents/agents.py (AI_PROVIDER):
كل قناة اختيارية تماماً — إن لم تُضبط بيانات اعتمادها في .env يُسجَّل
المحاولة كـ "skipped" بدل رمي استثناء، فلا يتوقف أي إجراء آخر في النظام
بسببها (تسجيل الغياب ينجح دائماً بصرف النظر عن نجاح الإشعار).
DONIA LABS TECH © 2026
"""
import smtplib
import ssl
from email.mime.text import MIMEText
from email.header import Header
import httpx
from app.core.config import cfg
from app.core.database import Session, NotificationLog, SchoolInfo


def _log(db, student_id, event_type, channel, recipient, message, status, error=""):
    try:
        db.add(NotificationLog(student_id=student_id, event_type=event_type, channel=channel,
                                recipient=recipient, message=message[:2000], status=status,
                                error=str(error)[:500]))
        db.commit()
    except Exception:
        db.rollback()


def _send_email(to_addr: str, subject: str, body: str):
    if not (cfg.SMTP_HOST and cfg.SMTP_USER and cfg.SMTP_PASSWORD and to_addr):
        return False, "SMTP غير مُعدّ (تحقق من ملف .env)"
    try:
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = Header(subject, "utf-8")
        msg["From"] = cfg.SMTP_FROM or cfg.SMTP_USER
        msg["To"] = to_addr
        if cfg.SMTP_USE_TLS:
            ctx = ssl.create_default_context()
            with smtplib.SMTP(cfg.SMTP_HOST, cfg.SMTP_PORT, timeout=15) as s:
                s.starttls(context=ctx)
                s.login(cfg.SMTP_USER, cfg.SMTP_PASSWORD)
                s.sendmail(cfg.SMTP_FROM or cfg.SMTP_USER, [to_addr], msg.as_string())
        else:
            with smtplib.SMTP_SSL(cfg.SMTP_HOST, cfg.SMTP_PORT, timeout=15) as s:
                s.login(cfg.SMTP_USER, cfg.SMTP_PASSWORD)
                s.sendmail(cfg.SMTP_FROM or cfg.SMTP_USER, [to_addr], msg.as_string())
        return True, ""
    except Exception as ex:
        return False, str(ex)


def _send_whatsapp(to_phone: str, body: str):
    if not to_phone:
        return False, "لا يوجد رقم هاتف للولي"
    phone = "".join(ch for ch in to_phone if ch.isdigit() or ch == "+")
    try:
        if cfg.WHATSAPP_PROVIDER == "twilio":
            if not (cfg.TWILIO_SID and cfg.TWILIO_AUTH_TOKEN and cfg.TWILIO_WHATSAPP_FROM):
                return False, "Twilio غير مُعدّ (تحقق من ملف .env)"
            to_wa = phone if phone.startswith("whatsapp:") else f"whatsapp:{phone}"
            with httpx.Client(timeout=15) as c:
                r = c.post(
                    f"https://api.twilio.com/2010-04-01/Accounts/{cfg.TWILIO_SID}/Messages.json",
                    auth=(cfg.TWILIO_SID, cfg.TWILIO_AUTH_TOKEN),
                    data={"From": cfg.TWILIO_WHATSAPP_FROM, "To": to_wa, "Body": body},
                )
                if r.status_code not in (200, 201):
                    return False, f"Twilio: {r.status_code} {r.text[:200]}"
                return True, ""
        else:
            # WhatsApp Cloud API (Meta) — المزوّد الرسمي المجاني للحدود الأولى
            if not (cfg.WHATSAPP_TOKEN and cfg.WHATSAPP_PHONE_ID):
                return False, "WhatsApp Cloud API غير مُعدّ (تحقق من ملف .env)"
            with httpx.Client(timeout=15) as c:
                r = c.post(
                    f"https://graph.facebook.com/v20.0/{cfg.WHATSAPP_PHONE_ID}/messages",
                    headers={"Authorization": f"Bearer {cfg.WHATSAPP_TOKEN}"},
                    json={"messaging_product": "whatsapp", "to": phone.lstrip("+"),
                          "type": "text", "text": {"body": body}},
                )
                if r.status_code not in (200, 201):
                    return False, f"WhatsApp: {r.status_code} {r.text[:200]}"
                return True, ""
    except Exception as ex:
        return False, str(ex)


def notify_absence(student, si: SchoolInfo, date_str: str, period: str = "", db=None):
    """يُرسل إشعار غياب لولي أمر التلميذ عبر البريد و/أو واتساب حسب الإعدادات
    والقنوات المتاحة فعلياً — لا يرمي أي استثناء أبداً كي لا يُفشل تسجيل
    الغياب نفسه؛ كل محاولة (نجحت أو فشلت أو تُخطِّيت) تُسجَّل في NotificationLog."""
    own_session = db is None
    db = db or Session()
    try:
        if not si or not si.notify_absence_enabled:
            return
        period_txt = f" (الحصة: {period})" if period else ""
        subject = f"إشعار غياب — {student.full_name}"
        body = (
            f"السلام عليكم،\n\n"
            f"نُعلمكم بأن التلميذ(ة) {student.full_name} "
            f"(القسم: {getattr(student.division, 'name', '') if student.division else ''}) "
            f"سُجِّل غائباً بتاريخ {date_str}{period_txt}.\n\n"
            f"يُرجى تبرير الغياب لدى إدارة المؤسسة في أقرب وقت.\n\n"
            f"{si.name_ar or ''}\nالإدارة"
        )
        if si.notify_channel_email and student.guardian_email:
            ok_, err = _send_email(student.guardian_email, subject, body)
            _log(db, student.id, "absence", "email", student.guardian_email, body,
                 "sent" if ok_ else "failed", err)
        elif si.notify_channel_email:
            _log(db, student.id, "absence", "email", "", body, "skipped", "لا يوجد بريد إلكتروني لولي الأمر")

        if si.notify_channel_whatsapp and student.guardian_phone:
            ok_, err = _send_whatsapp(student.guardian_phone, body)
            _log(db, student.id, "absence", "whatsapp", student.guardian_phone, body,
                 "sent" if ok_ else "failed", err)
        elif si.notify_channel_whatsapp:
            _log(db, student.id, "absence", "whatsapp", "", body, "skipped", "لا يوجد رقم هاتف لولي الأمر")
    except Exception:
        # لا نسمح لأي خطأ في الإشعارات بإفشال العملية الأساسية (تسجيل الغياب)
        pass
    finally:
        if own_session:
            db.close()
