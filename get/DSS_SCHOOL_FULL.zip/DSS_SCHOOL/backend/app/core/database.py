"""
DONIA SMART SCHOOL v3 — Database + Models
SQLAlchemy — Pure Python — Python 3.14 ✓
DONIA LABS TECH © 2026
"""
from sqlalchemy import (
    create_engine, event,
    Column, Integer, String, Float, Boolean,
    Date, DateTime, Text, ForeignKey, UniqueConstraint, Index
)
from sqlalchemy.orm import relationship, declarative_base, sessionmaker
from sqlalchemy.sql import func
from pathlib import Path
from app.core.config import cfg

# ── Engine setup ─────────────────────────────────────────────
Path(cfg.DB_PATH).parent.mkdir(parents=True, exist_ok=True)

engine = create_engine(
    cfg.DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=cfg.DEBUG,
)

@event.listens_for(engine, "connect")
def set_pragmas(conn, _):
    cur = conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL")
    cur.execute("PRAGMA foreign_keys=ON")
    cur.execute("PRAGMA synchronous=NORMAL")
    cur.execute("PRAGMA cache_size=-32000")
    cur.close()

Session = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()


def get_session():
    db = Session()
    try:
        yield db
    finally:
        db.close()


# ══════════════════════════════════════
# MODELS
# ══════════════════════════════════════

class SchoolInfo(Base):
    __tablename__ = "school_info"
    id                       = Column(Integer, primary_key=True)
    name_ar                  = Column(String(200), default="")
    name_fr                  = Column(String(200), default="")
    school_code               = Column(String(30), default="")
    wilaya                    = Column(String(50), default="")
    commune                   = Column(String(50), default="")
    address                   = Column(Text, default="")
    phone                     = Column(String(20), default="")
    director_name             = Column(String(100), default="")
    counselor_name            = Column(String(100), default="")     # مستشار التربية
    nazir_name                = Column(String(100), default="")     # الناظر
    guidance_counselor_name   = Column(String(100), default="")     # مستشار التوجيه
    general_supervisor_name   = Column(String(100), default="")     # المشرف العام
    bursar_name                = Column(String(100), default="")     # المقتصد / المسير المالي
    academic_year             = Column(String(20), default="2025/2026")
    level_type                = Column(String(20), default="متوسطة")
    stamp_path                = Column(String(255), default="")
    signature_path            = Column(String(255), default="")
    is_configured              = Column(Boolean, default=False)  # هل أكملت المؤسسة معالج الإعداد الأول؟
    periods_morning            = Column(Integer, default=4)   # عدد الحصص في الفترة الصباحية
    periods_evening            = Column(Integer, default=4)   # عدد الحصص في الفترة المسائية
    tt_morning_start           = Column(String(5), default="08:00")   # بداية أول حصة صباحية (مواقيت الطباعة)
    tt_evening_start           = Column(String(5), default="13:30")   # بداية أول حصة مسائية
    tt_period_minutes          = Column(Integer, default=60)          # مدة الحصة بالدقائق
    late_grace_minutes         = Column(Integer, default=10)  # دقائق السماح قبل اعتبار التلميذ متأخراً عند المسح
    notify_absence_enabled     = Column(Boolean, default=True)   # تفعيل إشعارات الغياب التلقائية (بريد/واتساب)
    notify_channel_email       = Column(Boolean, default=True)   # إرسال عبر البريد الإلكتروني
    notify_channel_whatsapp    = Column(Boolean, default=True)   # إرسال عبر واتساب
    # ── هوية المؤسسة في صفحة الهبوط والواجهة (كل مؤسسة ترفع شعارها وتملأ بياناتها) ──
    logo_path                  = Column(String(255), default="")   # شعار المؤسسة (يُرفع من الإعدادات)
    motto                      = Column(String(200), default="")   # شعار نصي/حكمة المؤسسة
    brand_color                = Column(String(9), default="#1B7F4B")  # لون هوية المؤسسة
    email                      = Column(String(100), default="")
    updated_at                = Column(DateTime, onupdate=func.now())


class User(Base):
    __tablename__ = "users"
    id             = Column(Integer, primary_key=True, index=True)
    username       = Column(String(50), unique=True, nullable=False, index=True)
    full_name      = Column(String(150), nullable=False)
    password_hash  = Column(String(255), nullable=False)
    role           = Column(String(20), nullable=False, default="teacher")
    gates          = Column(Text, default="[]")   # JSON list
    is_active      = Column(Boolean, default=True)
    last_login     = Column(DateTime, nullable=True)
    login_attempts = Column(Integer, default=0)
    locked_until   = Column(DateTime, nullable=True)
    phone          = Column(String(20), default="")
    email          = Column(String(100), default="")
    created_at     = Column(DateTime, server_default=func.now())
    created_by     = Column(Integer, nullable=True)
    photo_path     = Column(String(255), default="")   # صورة الموظف (بطاقة التعريف)
    # ── حقول الكشف المفصل للعمال الإداريين والمهنيين (التقرير العام للتسيير) ──
    birth_date            = Column(Date, nullable=True)
    degree                = Column(String(100), default="")   # أقصى درجة جامعية
    employment_status     = Column(String(20), default="مرسم")  # مرسم/متربص/متعاقد/مسخر/شاغر
    first_appointment_date= Column(Date, nullable=True)   # تاريخ أول تعيين بهذه الصفة
    hire_date             = Column(Date, nullable=True)   # تاريخ التعيين بالمؤسسة
    position_title        = Column(String(100), default="")   # المنصب (إن اختلف عن الدور)
    hr_notes              = Column(Text, default="")
    financial_position    = Column(String(100), default="")   # مناصب مالية (تقرير RGF)

    def get_gates(self):
        import json
        try:
            g = self.gates
            return json.loads(g) if isinstance(g, str) else (g or [])
        except Exception:
            return []

    audit_logs = relationship("AuditLog", back_populates="user",
                               foreign_keys="AuditLog.user_id")


class Division(Base):
    __tablename__ = "divisions"
    id            = Column(Integer, primary_key=True)
    name          = Column(String(50), nullable=False)
    level         = Column(Integer, nullable=False)
    section       = Column(String(5), nullable=False)
    academic_year = Column(String(20), default="2025/2026")
    room          = Column(String(20), default="")
    is_active     = Column(Boolean, default=True)

    students  = relationship("Student", back_populates="division",
                              foreign_keys="Student.division_id")
    __table_args__ = (UniqueConstraint("level", "section", "academic_year"),)


class Student(Base):
    __tablename__ = "students"
    id               = Column(Integer, primary_key=True, index=True)
    national_id      = Column(String(20), unique=True, index=True, nullable=True)
    registration_num = Column(String(20), unique=True, index=True, nullable=True)
    first_name_ar    = Column(String(80), nullable=False)
    last_name_ar     = Column(String(80), nullable=False)
    first_name_fr    = Column(String(80), default="")
    last_name_fr     = Column(String(80), default="")
    birth_date       = Column(Date, nullable=True)
    birth_place      = Column(String(100), default="")
    gender           = Column(String(10), default="ذكر")
    division_id      = Column(Integer, ForeignKey("divisions.id"), nullable=True)
    status           = Column(String(20), default="خارجي")
    is_repeating     = Column(Boolean, default=False)
    academic_year    = Column(String(20), default="2025/2026")
    father_name      = Column(String(100), default="")
    mother_name      = Column(String(100), default="")
    guardian_name    = Column(String(100), default="")
    guardian_relation= Column(String(50), default="")
    guardian_phone   = Column(String(20), default="")
    guardian_phone2  = Column(String(20), default="")
    guardian_email   = Column(String(100), default="")
    guardian_address = Column(Text, default="")
    siblings_count   = Column(Integer, default=0)
    siblings_female  = Column(Integer, default=0)
    is_orphan        = Column(Boolean, default=False)
    has_disability   = Column(Boolean, default=False)
    disability_type  = Column(String(100), default="")
    is_scholarship   = Column(Boolean, default=False)     # ممنوح (منحة دراسية)
    pe_exempt        = Column(Boolean, default=False)     # معفى من التربية البدنية
    health_status    = Column(Text, default="")           # الحالة الصحية (اختياري)
    orientation_wish = Column(String(100), default="")    # الرغبة / التوجيه أو الشعبة
    father_in_education = Column(Boolean, default=False)  # الأب من موظفي قطاع التربية
    mother_in_education = Column(Boolean, default=False)  # الأم من موظفي قطاع التربية
    parents_separated   = Column(Boolean, default=False)  # حالة انفصال الوالدين
    photo_path       = Column(String(255), default="")    # صورة التلميذ (بطاقة التعريف)
    is_active        = Column(Boolean, default=True)
    is_expelled      = Column(Boolean, default=False)
    expelled_date    = Column(Date, nullable=True)
    entry_date       = Column(Date, nullable=True)          # تاريخ الدخول إلى المؤسسة (وافد) — لحركة التلاميذ
    origin_school    = Column(String(150), default="")      # المؤسسة الأصلية (للوافدين)
    exit_note        = Column(String(200), default="")      # وجهة/سبب الخروج (للمغادرين)
    created_at       = Column(DateTime, server_default=func.now())
    updated_at       = Column(DateTime, onupdate=func.now())

    division           = relationship("Division", back_populates="students",
                                       foreign_keys=[division_id])
    absences           = relationship("Absence", back_populates="student")
    absence_notices    = relationship("AbsenceNotice", back_populates="student")
    grades             = relationship("Grade", back_populates="student")
    discipline_records = relationship("DisciplineRecord", back_populates="student")

    __table_args__ = (Index("ix_stu_name", "last_name_ar", "first_name_ar"),)

    @property
    def full_name(self):
        return f"{self.last_name_ar} {self.first_name_ar}"


class Subject(Base):
    __tablename__ = "subjects"
    id          = Column(Integer, primary_key=True)
    name_ar     = Column(String(100), nullable=False)
    name_fr     = Column(String(100), default="")
    coefficient = Column(Integer, nullable=False, default=1)
    has_fard2   = Column(Boolean, default=True)
    has_exam    = Column(Boolean, default=True)
    is_exempt   = Column(Boolean, default=False)
    sort_order  = Column(Integer, default=0)
    grades      = relationship("Grade", back_populates="subject")


class Teacher(Base):
    __tablename__ = "teachers"
    id           = Column(Integer, primary_key=True)
    user_id      = Column(Integer, ForeignKey("users.id"), nullable=True)
    national_id  = Column(String(20), nullable=True)
    first_name   = Column(String(80), nullable=False, default="")
    last_name    = Column(String(80), nullable=False, default="")
    specialty    = Column(String(100), default="")
    grade_rank   = Column(String(100), default="")
    weekly_hours = Column(Integer, default=18)
    phone        = Column(String(20), default="")
    email        = Column(String(100), default="")
    is_active    = Column(Boolean, default=True)
    start_date   = Column(Date, nullable=True)
    photo_path   = Column(String(255), default="")   # صورة الموظف (بطاقة التعريف)



class Grade(Base):
    __tablename__ = "grades"
    id            = Column(Integer, primary_key=True)
    student_id    = Column(Integer, ForeignKey("students.id"), nullable=False)
    subject_id    = Column(Integer, ForeignKey("subjects.id"), nullable=False)
    division_id   = Column(Integer, ForeignKey("divisions.id"), nullable=False)
    term          = Column(String(20), nullable=False)
    academic_year = Column(String(20), default="2025/2026")
    fard1         = Column(Float, nullable=True)
    fard2         = Column(Float, nullable=True)
    activity      = Column(Float, nullable=True)
    exam_raw      = Column(Float, nullable=True)
    exam_20       = Column(Float, nullable=True)
    term_average  = Column(Float, nullable=True)
    comment       = Column(String(255), default="")
    entered_by    = Column(Integer, nullable=True)
    entered_at    = Column(DateTime, server_default=func.now())

    student  = relationship("Student", back_populates="grades")
    subject  = relationship("Subject", back_populates="grades")
    division = relationship("Division")
    __table_args__ = (UniqueConstraint("student_id","subject_id","term","academic_year"),)


class TermResult(Base):
    __tablename__ = "term_results"
    id               = Column(Integer, primary_key=True)
    student_id       = Column(Integer, ForeignKey("students.id"), nullable=False)
    division_id      = Column(Integer, ForeignKey("divisions.id"), nullable=False)
    term             = Column(String(20), nullable=False)
    academic_year    = Column(String(20), default="2025/2026")
    term_average     = Column(Float, nullable=True)
    annual_average   = Column(Float, nullable=True)
    total_coeff      = Column(Integer, default=0)
    total_points     = Column(Float, default=0.0)
    rank             = Column(Integer, nullable=True)
    council_decision = Column(String(30), default="قيد الدراسة")
    absence_hours    = Column(Integer, default=0)
    __table_args__ = (UniqueConstraint("student_id","term","academic_year"),)


class SessionCheck(Base):
    """تأشيرة «سُجِّلت الحصة»: يضعها الأستاذ عند إرسال غيابات حصة (حتى لو لم يغب أحد)،
    ليعرف المدير أي الحصص سُجِّلت وأيها لم تُسجَّل بعد."""
    __tablename__ = "session_checks"
    id            = Column(Integer, primary_key=True)
    division_id   = Column(Integer, ForeignKey("divisions.id"), nullable=False, index=True)
    date          = Column(Date, nullable=False, index=True)
    period        = Column(String(5), nullable=False)
    teacher_id    = Column(Integer, nullable=True)
    user_id       = Column(Integer, nullable=True)
    absent_count  = Column(Integer, default=0)
    submitted_at  = Column(DateTime, server_default=func.now())
    __table_args__ = (UniqueConstraint("division_id", "date", "period"),)


class ParentSummons(Base):
    """طلب/استدعاء ولي تلميذ: يرفعه الأستاذ أو المشرف، ويعتمده المدير (أو من ينوب عنه)
    ثم يُطبع ويُتابَع إلى الإغلاق. حالات: pending → approved → done، أو rejected."""
    __tablename__ = "parent_summons"
    id            = Column(Integer, primary_key=True)
    student_id    = Column(Integer, ForeignKey("students.id"), nullable=False, index=True)
    division_id   = Column(Integer, nullable=True)
    requested_by  = Column(Integer, nullable=True)
    requested_role= Column(String(20), default="")
    category      = Column(String(30), default="غياب")     # غياب/سلوك/نتائج/أخرى
    reason        = Column(Text, default="")
    for_date      = Column(Date, nullable=True)            # الموعد المقترح للحضور
    status        = Column(String(20), default="pending", index=True)
    decided_by    = Column(Integer, nullable=True)
    decided_at    = Column(DateTime, nullable=True)
    director_note = Column(Text, default="")
    closed_note   = Column(Text, default="")
    doc_number    = Column(String(30), default="")
    created_at    = Column(DateTime, server_default=func.now())


class Absence(Base):
    __tablename__ = "absences"
    id            = Column(Integer, primary_key=True, index=True)
    student_id    = Column(Integer, ForeignKey("students.id"), nullable=False)
    division_id   = Column(Integer, nullable=True)
    date          = Column(Date, nullable=False)
    period        = Column(String(5), default="")
    hours         = Column(Float, default=1.0)
    status        = Column(String(20), default="غير مبرر")
    justification = Column(Text, default="")
    entered_by    = Column(Integer, nullable=True)
    created_at    = Column(DateTime, server_default=func.now())
    student       = relationship("Student", back_populates="absences")
    __table_args__ = (Index("ix_abs_stu_date","student_id","date"),)


class AbsenceNotice(Base):
    __tablename__ = "absence_notices"
    id               = Column(Integer, primary_key=True)
    student_id       = Column(Integer, ForeignKey("students.id"), nullable=False)
    notice_type      = Column(String(20), nullable=False)
    issued_date      = Column(Date, nullable=False)
    absence_days     = Column(Integer, default=0)
    ref_notice1_date = Column(Date, nullable=True)
    ref_notice2_date = Column(Date, nullable=True)
    deadline_date    = Column(Date, nullable=True)
    doc_number       = Column(String(30), default="")
    created_by       = Column(Integer, nullable=True)
    created_at       = Column(DateTime, server_default=func.now())
    student          = relationship("Student", back_populates="absence_notices")


class DailyReport(Base):
    __tablename__ = "daily_reports"
    id                  = Column(Integer, primary_key=True)
    report_date         = Column(Date, nullable=False, unique=True, index=True)
    report_number       = Column(Integer, default=0)
    total_registered    = Column(Integer, default=0)
    total_present       = Column(Integer, default=0)
    total_absent        = Column(Integer, default=0)
    absence_percentage  = Column(Float, default=0.0)
    total_absence_hours = Column(Float, default=0.0)
    canteen_reg_m       = Column(Integer, default=0)
    canteen_reg_f       = Column(Integer, default=0)
    canteen_pres_m      = Column(Integer, default=0)
    canteen_pres_f      = Column(Integer, default=0)
    counselor_notes     = Column(Text, default="")
    director_notes      = Column(Text, default="")
    special_events      = Column(Text, default="")
    counselor_name      = Column(String(100), default="")
    extra_json          = Column(Text, default="{}")   # مدخلات المستشار اليدوية (إجراءات، حركة، إطعام، حوصلة...)
    created_at          = Column(DateTime, server_default=func.now())
    daily_logs          = relationship("DailyAbsenceLog", back_populates="report")


class TeacherAbsence(Base):
    """غياب أستاذ في يوم معيّن (الدروس التي لم تقدّم) — يغذّي القسم 1.1 من التقرير
    اليومي لمستشار التربية. periods = رموز الحصص الغائب عنها (ص1..صN، م1..مN)،
    slots = JSON {رمز الحصة: القسم الذي فاته الدرس}."""
    __tablename__ = "teacher_absences"
    id           = Column(Integer, primary_key=True)
    date         = Column(Date, nullable=False, index=True)
    teacher_id   = Column(Integer, nullable=True, index=True)
    teacher_name = Column(String(150), default="")
    subject      = Column(String(100), default="")
    periods      = Column(String(80), default="")      # "ص1,ص2,م3"
    slots        = Column(Text, default="{}")
    reason       = Column(String(100), default="")
    notes        = Column(Text, default="")
    created_at   = Column(DateTime, server_default=func.now())


class SchoolHoliday(Base):
    """أيام العطل (لا دراسة) — تُستثنى من ترقيم التقارير اليومية."""
    __tablename__ = "school_holidays"
    id        = Column(Integer, primary_key=True)
    date_from = Column(Date, nullable=False, index=True)
    date_to   = Column(Date, nullable=False)
    label     = Column(String(100), default="عطلة")


class DailyAbsenceLog(Base):
    __tablename__ = "daily_absence_logs"
    id               = Column(Integer, primary_key=True)
    report_id        = Column(Integer, ForeignKey("daily_reports.id"), nullable=False)
    division_id      = Column(Integer, nullable=False)
    registered       = Column(Integer, default=0)
    absent           = Column(Integer, default=0)
    consecutive_days = Column(Integer, default=0)
    report           = relationship("DailyReport", back_populates="daily_logs")


class OfficialDocument(Base):
    __tablename__ = "official_documents"
    id            = Column(Integer, primary_key=True)
    doc_type      = Column(String(50), nullable=False)
    doc_number    = Column(String(30), unique=True, nullable=False)
    student_id    = Column(Integer, nullable=True)
    staff_user_id = Column(Integer, nullable=True)   # لوثائق الموظفين (رخصة غياب/استفسار/خصم)
    issued_date   = Column(Date, nullable=False)
    academic_year = Column(String(20), default="2025/2026")
    content_json  = Column(Text, default="{}")
    issued_by     = Column(Integer, nullable=True)
    created_at    = Column(DateTime, server_default=func.now())


class DocTemplateSample(Base):
    """قوالب وثائق يرفعها المستخدم كأمثلة حقيقية (نظام تعلّم من النماذج / RAG-lite).
    عندما لا يجد النظام مولّداً جاهزاً لنوع وثيقة معيّن، يستعمل أقرب قالب مخزّن هنا
    كمرجع صياغة وتنسيق عبر مساعد الذكاء الاصطناعي بدل رفض توليد الوثيقة."""
    __tablename__ = "doc_template_samples"
    id              = Column(Integer, primary_key=True)
    doc_type        = Column(String(80), nullable=False, index=True)   # مفتاح نوع الوثيقة (حر)
    title           = Column(String(200), default="")                  # اسم عرضي (مثال: "شهادة مدرسية")
    source_filename = Column(String(255), default="")
    extracted_text  = Column(Text, nullable=False)                     # نص القالب/المحتوى المرجعي
    uploaded_by     = Column(Integer, nullable=True)
    uploaded_at     = Column(DateTime, server_default=func.now())


class DisciplineRecord(Base):
    __tablename__ = "discipline_records"
    id              = Column(Integer, primary_key=True)
    student_id      = Column(Integer, ForeignKey("students.id"), nullable=False)
    date            = Column(Date, nullable=False)
    violation_type  = Column(String(100), default="")
    description     = Column(Text, default="")
    sanction_type   = Column(String(50), default="")
    reported_by     = Column(Integer, nullable=True)
    parent_notified = Column(Boolean, default=False)
    created_at      = Column(DateTime, server_default=func.now())
    student         = relationship("Student", back_populates="discipline_records")


class ParentLink(Base):
    """ربط حساب ولي أمر (User بدور parent) بتلميذ أو أكثر — يسمح لولي
    الأمر بالاطلاع على نتائج وغياب وموقع ابنه فقط عبر بوابة الأولياء."""
    __tablename__ = "parent_links"
    id          = Column(Integer, primary_key=True)
    parent_id   = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    student_id  = Column(Integer, ForeignKey("students.id"), nullable=False, index=True)
    relation    = Column(String(20), default="ولي")   # أب/أم/ولي
    created_at  = Column(DateTime, server_default=func.now())
    __table_args__ = (UniqueConstraint("parent_id", "student_id", name="uq_parent_student"),)


class Message(Base):
    """رسائل بين ولي الأمر والإدارة (مراسلة داخل بوابة الأولياء)."""
    __tablename__ = "messages"
    id            = Column(Integer, primary_key=True, index=True)
    student_id    = Column(Integer, ForeignKey("students.id"), nullable=False, index=True)
    sender_id     = Column(Integer, ForeignKey("users.id"), nullable=False)
    sender_role   = Column(String(20), default="parent")   # parent / staff
    body          = Column(Text, nullable=False)
    is_read       = Column(Boolean, default=False)
    created_at    = Column(DateTime, server_default=func.now(), index=True)


class CheckPoint(Base):
    """
    نقطة تتبع فيزيائية داخل المؤسسة أو النقل المدرسي
    (بوابة، حافلة، مطعم، مكتبة...) — تُستعمل مثل نقاط تفتيش الحجاج بمكة.
    كل نقطة لها إحداثيات جغرافية ثابتة تُعرض على الخريطة.
    """
    __tablename__ = "checkpoints"
    id           = Column(Integer, primary_key=True)
    name         = Column(String(100), nullable=False)
    code         = Column(String(20), unique=True, nullable=False, index=True)
    point_type   = Column(String(20), default="بوابة")   # بوابة/حافلة/قاعة/مطعم/مكتبة/ملعب
    latitude     = Column(Float, nullable=True)
    longitude    = Column(Float, nullable=True)
    is_active    = Column(Boolean, default=True)
    created_at   = Column(DateTime, server_default=func.now())

    scans = relationship("LocationScan", back_populates="checkpoint")


class LocationScan(Base):
    """
    سجل مسح بطاقة التلميذ (عبر رقم التسجيل) عند نقطة تتبع معينة.
    نفس مبدأ تتبع الحجاج: مسح البطاقة/السوار عند كل نقطة تفتيش
    يسجل آخر موقع معروف للتلميذ + الوقت + الجهة الماسحة.
    ملاحظة: هذا تتبع عبر نقاط مسح ثابتة (Checkpoints) وليس تتبعاً
    مستمراً عبر GPS الهاتف — وهو الأسلوب المعتمد فعلياً في تتبع الحجاج.
    """
    __tablename__ = "location_scans"
    id            = Column(Integer, primary_key=True, index=True)
    student_id    = Column(Integer, ForeignKey("students.id"), nullable=False)
    checkpoint_id = Column(Integer, ForeignKey("checkpoints.id"), nullable=False)
    direction     = Column(String(10), default="دخول")   # دخول / خروج
    scanned_at    = Column(DateTime, server_default=func.now(), index=True)
    scanned_by    = Column(Integer, nullable=True)
    note          = Column(String(200), default="")

    student    = relationship("Student")
    checkpoint = relationship("CheckPoint", back_populates="scans")
    __table_args__ = (Index("ix_scan_stu_time", "student_id", "scanned_at"),)


class Room(Base):
    """محل (قاعة عادية أو متخصصة: مخبر، ورشة إعلام آلي، قاعة رياضة...) —
    تُستعمل في جدولة الحصص (استعمال الزمن) ووثائق مواقيت المحلات
    الرسمية ضمن التقرير العام للتسيير."""
    __tablename__ = "rooms"
    id         = Column(Integer, primary_key=True)
    name       = Column(String(50), nullable=False)
    room_type  = Column(String(20), default="عادي")   # عادي / متخصص
    capacity   = Column(Integer, default=0)
    is_active  = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())


class TeacherActivity(Base):
    """نشاط للأستاذ في استعمال الزمن لا يرتبط بقسم (استقبال الأولياء، تنسيق،
    صيانة الوسائل، استدراك...) — يظهر في مواقيت الأستاذ الرسمية فقط."""
    __tablename__ = "teacher_activities"
    id            = Column(Integer, primary_key=True)
    teacher_id    = Column(Integer, ForeignKey("teachers.id"), nullable=False, index=True)
    day_of_week   = Column(Integer, nullable=False)
    period        = Column(String(5), nullable=False)
    label         = Column(String(100), default="")
    academic_year = Column(String(20), default="2025/2026")
    __table_args__ = (UniqueConstraint("teacher_id", "day_of_week", "period", "academic_year"),)


class ScheduleEntry(Base):
    """خانة واحدة في استعمال الزمن: قسم + حصة (يوم/رقم الحصة) مربوطة
    بأستاذ ومادة ومحل. الأساس الحقيقي لكل وثائق التقرير العام للتسيير
    الاثنتي عشرة (مواقيت الأقسام/الأساتذة/المحلات، خدمات الأساتذة،
    حوصلة الساعات الإضافية والفائضة...). day_of_week: 0=السبت..5=الخميس
    (الأسبوع الدراسي الجزائري)."""
    __tablename__ = "schedule_entries"
    id            = Column(Integer, primary_key=True, index=True)
    division_id   = Column(Integer, ForeignKey("divisions.id"), nullable=False, index=True)
    teacher_id    = Column(Integer, ForeignKey("teachers.id"), nullable=True, index=True)
    subject_id    = Column(Integer, ForeignKey("subjects.id"), nullable=True)
    room_id       = Column(Integer, ForeignKey("rooms.id"), nullable=True, index=True)
    day_of_week   = Column(Integer, nullable=False)     # 0..5
    period        = Column(String(5), nullable=False)   # ص1..صN / م1..مN (نفس تسمية نظام الحضور)
    academic_year = Column(String(20), default="2025/2026")
    # حصة مشتركة بين أستاذين (أعمال موجهة TD: مثلاً عربية/رياضيات) — الأستاذ الثاني هنا
    co_teacher_id = Column(Integer, ForeignKey("teachers.id"), nullable=True, index=True)
    # نص العرض الأصلي للحصة إن كان مركّباً (مثال «عربية/رياضيات») — يُعرض بدل اسم المادة
    label         = Column(String(100), default="")
    created_at    = Column(DateTime, server_default=func.now())
    __table_args__ = (UniqueConstraint("division_id", "day_of_week", "period", "academic_year",
                                        name="uq_sched_division_slot"),)


class OfficialHoursNorm(Base):
    """الحجم الساعي الرسمي المقرَّر وزارياً لكل مادة × كل مستوى (تعليم متوسط:
    1-4)، يُستعمل في وثيقة «تطبيق المواقيت الرسمية» ضمن التقرير العام RGF
    لمقارنة الحجم المُطبَّق فعلياً (المحسوب من استعمال الزمن) بالمقرر رسمياً.
    قابل للتعديل من واجهة الإدارة لأن المنهاج الرسمي يتغير من وزارة لأخرى
    ولا يوجد مصدر بيانات آلي له داخل النظام."""
    __tablename__ = "official_hours_norms"
    id            = Column(Integer, primary_key=True)
    subject_name  = Column(String(100), nullable=False)
    level         = Column(Integer, nullable=False)   # 1..4 (تعليم متوسط)
    weekly_hours  = Column(Float, default=0)
    academic_year = Column(String(20), default="2025/2026")
    __table_args__ = (UniqueConstraint("subject_name", "level", "academic_year",
                                        name="uq_hours_norm_subject_level_year"),)


class NotificationLog(Base):
    """سجل كل محاولة إرسال إشعار تلقائي (غياب حالياً، وقابل للتوسعة لاحقاً)
    عبر البريد الإلكتروني أو واتساب — يُستعمل للتدقيق ولعرضه في التقرير
    العام للتسيير (معدّل نجاح الإشعارات)."""
    __tablename__ = "notification_logs"
    id            = Column(Integer, primary_key=True, index=True)
    student_id    = Column(Integer, nullable=True, index=True)
    event_type    = Column(String(30), default="absence")   # absence / notice / discipline ...
    channel       = Column(String(20), nullable=False)       # email / whatsapp
    recipient     = Column(String(150), default="")
    message       = Column(Text, default="")
    status        = Column(String(20), default="pending")    # sent / failed / skipped
    error         = Column(Text, default="")
    created_at    = Column(DateTime, server_default=func.now(), index=True)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id         = Column(Integer, primary_key=True, index=True)
    user_id    = Column(Integer, ForeignKey("users.id"), nullable=True)
    action     = Column(String(100), nullable=False)
    entity     = Column(String(50), default="")
    entity_id  = Column(Integer, nullable=True)
    old_value  = Column(Text, nullable=True)
    new_value  = Column(Text, nullable=True)
    ip_address = Column(String(45), default="")
    timestamp  = Column(DateTime, server_default=func.now(), index=True)
    user       = relationship("User", back_populates="audit_logs",
                               foreign_keys=[user_id])


# ══════════════════════════════════════
# INIT
# ══════════════════════════════════════

def init_db():
    Base.metadata.create_all(bind=engine)
    _auto_migrate()
    _seed_subjects()
    _seed_admin()
    _seed_school_info()
    _grant_new_gates()
    print("✓ قاعدة البيانات جاهزة")


_NEW_GATES = ("G25", "G26", "G27")

def _grant_new_gates():
    """يمنح الحسابات القائمة بوابات الجولة 18 الافتراضية لدورها (إضافة فقط، لا نزع)."""
    import json
    from app.core.config import ROLE_GATES
    db = Session()
    try:
        for u in db.query(User).all():
            cur = u.get_gates()
            add = [x for x in _NEW_GATES if x in ROLE_GATES.get(u.role, []) and x not in cur]
            if add:
                u.gates = json.dumps(cur + add)
        db.commit()
    finally:
        db.close()


def _auto_migrate():
    """ترحيل تلقائي خفيف: يضيف أي عمود جديد عُرِّف في النماذج ولم يكن
    موجوداً بعد في قاعدة بيانات قديمة (SQLite لا يدعم إضافة أعمدة عبر
    create_all وحدها)، بدون حذف أو فقدان أي بيانات موجودة."""
    from sqlalchemy import inspect, text
    insp = inspect(engine)
    existing_tables = set(insp.get_table_names())
    with engine.begin() as conn:
        for table in Base.metadata.sorted_tables:
            if table.name not in existing_tables:
                continue
            existing_cols = {c["name"] for c in insp.get_columns(table.name)}
            for col in table.columns:
                if col.name in existing_cols:
                    continue
                try:
                    coltype = col.type.compile(engine.dialect)
                    default_sql = ""
                    if col.default is not None and getattr(col.default, "arg", None) is not None \
                       and not callable(col.default.arg):
                        v = col.default.arg
                        if isinstance(v, bool):
                            default_sql = f" DEFAULT {1 if v else 0}"
                        elif isinstance(v, (int, float)):
                            default_sql = f" DEFAULT {v}"
                        elif isinstance(v, str):
                            default_sql = f" DEFAULT '{v}'"
                    conn.execute(text(f'ALTER TABLE "{table.name}" ADD COLUMN "{col.name}" {coltype}{default_sql}'))
                    print(f"✓ ترحيل: أُضيف عمود {col.name} إلى جدول {table.name}")
                    if table.name == "school_info" and col.name == "is_configured":
                        # مؤسسة موجودة سابقاً وأدخلت اسم مدير فعلي تُعتبر مُهيَّأة أصلاً
                        # (لا نريد إظهار معالج الإعداد الأول لمن أعدّ نظامه من قبل)
                        conn.execute(text(
                            'UPDATE school_info SET is_configured = 1 '
                            "WHERE TRIM(COALESCE(director_name, '')) != '' "
                            "OR TRIM(COALESCE(name_ar, '')) != ''"
                        ))
                except Exception as ex:
                    print(f"⚠ تعذّر إضافة عمود {col.name} إلى {table.name}: {ex}")


def _seed_school_info():
    """يهيئ سطراً واحداً افتراضياً لمعلومات المؤسسة (من متغيرات البيئة كنقطة انطلاق)
    إن لم يكن موجوداً بعد — يُعدَّل لاحقاً من صفحة الإعدادات."""
    from app.core.config import cfg
    db = Session()
    try:
        if db.query(SchoolInfo).count() > 0:
            return
        db.add(SchoolInfo(
            name_ar=cfg.SCHOOL_NAME, school_code=cfg.SCHOOL_CODE,
            wilaya=cfg.WILAYA, academic_year=cfg.ACADEMIC_YEAR,
            level_type="متوسطة",
        ))
        db.commit()
        print("✓ معلومات المؤسسة: مُهيَّأة (عدّلها من صفحة الإعدادات)")
    finally:
        db.close()


def _seed_subjects():
    db = Session()
    try:
        if db.query(Subject).count() > 0:
            return
        subjects = [
            ("اللغة العربية",           "Arabe",         3, True,  True,  False),
            ("اللغة الأمازيغية",         "Amazighe",      2, False, True,  False),
            ("اللغة الفرنسية",           "Français",      3, True,  True,  False),
            ("اللغة الإنجليزية",         "Anglais",       2, True,  True,  False),
            ("التربية الإسلامية",         "Ed. Islamique", 2, True,  True,  False),
            ("التربية المدنية",           "Ed. Civique",   1, True,  True,  False),
            ("التاريخ والجغرافيا",        "Histoire-Géo",  2, True,  True,  False),
            ("الرياضيات",                "Mathématiques", 4, True,  True,  False),
            ("العلوم الطبيعية",           "Sciences Nat.", 2, True,  True,  False),
            ("الفيزياء والكيمياء",        "Physique-Chimie",2,True,  True,  False),
            ("الإعلام الآلي",             "Informatique",  1, False, False, False),
            ("التربية التشكيلية",         "Ed. Artistique",1, False, False, True),
            ("التربية الموسيقية",         "Ed. Musicale",  1, False, False, True),
            ("التربية البدنية والرياضية", "EPS",           2, False, False, False),
        ]
        for i, (ar, fr, coef, f2, exam, exempt) in enumerate(subjects):
            db.add(Subject(name_ar=ar, name_fr=fr, coefficient=coef,
                           has_fard2=f2, has_exam=exam, is_exempt=exempt, sort_order=i))
        db.commit()
        print("✓ المواد الدراسية: مُهيَّأة")
    finally:
        db.close()


def _seed_admin():
    import json
    from app.core.auth import hash_pw
    from app.core.config import ROLE_GATES
    db = Session()
    try:
        if db.query(User).filter(User.username == "admin").first():
            return
        db.add(User(
            username="admin",
            full_name="مدير المؤسسة",
            password_hash=hash_pw("Donia@2026"),
            role="director",
            gates=json.dumps(ROLE_GATES["director"]),
            is_active=True,
        ))
        db.commit()
        print("✓ حساب المدير: admin / Donia@2026")
        print("  ⚠  غيّر كلمة المرور فور الدخول!")
    finally:
        db.close()
