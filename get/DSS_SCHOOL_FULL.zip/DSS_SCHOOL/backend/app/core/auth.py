"""
DONIA SMART SCHOOL v3 — Auth
PyJWT + bcrypt — Pure Python — Python 3.14 ✓
DONIA LABS TECH © 2026
"""
import json
from datetime import datetime, timedelta, timezone
from functools import wraps
from typing import Optional
import jwt
import bcrypt
from flask import request, jsonify, g
from app.core.config import cfg
from app.core.database import Session, User


# ── Password ─────────────────────────────────────────────────

def hash_pw(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt(12)).decode()

def check_pw(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode(), hashed.encode())
    except Exception:
        return False


# ── JWT ──────────────────────────────────────────────────────

def make_token(user_id: int, role: str, name: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(hours=cfg.TOKEN_HOURS)
    return jwt.encode(
        {"sub": str(user_id), "role": role, "name": name,
         "exp": exp, "iat": datetime.now(timezone.utc)},
        cfg.SECRET_KEY, algorithm="HS256"
    )

def decode_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, cfg.SECRET_KEY, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


# ── Flask decorators ─────────────────────────────────────────

def login_required(f):
    """Require valid JWT token."""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth[7:]

        if not token:
            return jsonify({"error": "مطلوب تسجيل الدخول"}), 401

        payload = decode_token(token)
        if not payload:
            return jsonify({"error": "انتهت الجلسة، سجّل الدخول مجدداً"}), 401

        db = Session()
        try:
            user = db.query(User).filter(
                User.id == int(payload["sub"]),
                User.is_active == True
            ).first()
            if not user:
                return jsonify({"error": "المستخدم غير موجود"}), 401

            # Lockout check
            if user.locked_until:
                lu = user.locked_until
                if lu.tzinfo is None:
                    lu = lu.replace(tzinfo=timezone.utc)
                if datetime.now(timezone.utc) < lu:
                    mins = int((lu - datetime.now(timezone.utc)).seconds / 60)
                    return jsonify({"error": f"الحساب مقفل — انتظر {mins} دقيقة"}), 403

            g.user = user
            g.user_id = user.id
            g.role = user.role
            g.gates = user.get_gates()
        finally:
            db.close()

        return f(*args, **kwargs)
    return decorated


def gate_required(gate_code: str):
    """Require specific gate permission."""
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated(*args, **kwargs):
            if gate_code not in g.gates:
                return jsonify({
                    "error": f"ليس لديك صلاحية هذه البوابة ({gate_code})"
                }), 403
            return f(*args, **kwargs)
        return decorated
    return decorator


# ── Auth logic ───────────────────────────────────────────────

def authenticate(username: str, password: str) -> Optional[User]:
    db = Session()
    try:
        user = db.query(User).filter(User.username == username).first()
        if not user:
            return None

        if user.locked_until:
            lu = user.locked_until
            if lu.tzinfo is None:
                lu = lu.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) < lu:
                return None

        if not check_pw(password, user.password_hash):
            user.login_attempts = (user.login_attempts or 0) + 1
            if user.login_attempts >= cfg.MAX_ATTEMPTS:
                user.locked_until = datetime.now(timezone.utc) + timedelta(minutes=cfg.LOCKOUT_MINS)
            db.commit()
            return None

        user.login_attempts = 0
        user.locked_until = None
        user.last_login = datetime.now(timezone.utc)
        db.commit()
        db.refresh(user)
        return user
    finally:
        db.close()


def write_audit(user_id, action, entity="", entity_id=None, old=None, new=None):
    from app.core.database import AuditLog
    db = Session()
    try:
        db.add(AuditLog(
            user_id=user_id, action=action, entity=entity,
            entity_id=entity_id,
            old_value=str(old)[:500] if old else None,
            new_value=str(new)[:500] if new else None,
            ip_address=request.remote_addr if request else "",
        ))
        db.commit()
    except Exception:
        db.rollback()
    finally:
        db.close()
