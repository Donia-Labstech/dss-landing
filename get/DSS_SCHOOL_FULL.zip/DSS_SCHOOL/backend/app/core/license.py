"""
DONIA SMART SCHOOL v3 — License Engine (Offline verify + one-time online activation)
DONIA LABS TECH © 2026

إعادة بناء كاملة لنظام الترخيص (كان الإصدار السابق يحتوي مفاتيح صالحة مكتوبة
مباشرة في الكود المصدري — غير آمن إطلاقاً لمنتج يُباع ومصدره متاح على
GitHub، إذ يمكن لأي شخص قراءتها واستعمالها مجاناً). النظام الجديد:

  • التفعيل الأول يتطلب اتصالاً بخادم التراخيص (مرة واحدة فقط، عبر
    LICENSE_SERVER في .env) الذي يوقّع بيانات الترخيص رقمياً (Ed25519)
    ويربطها بجهاز هذه المؤسسة تحديداً (hardware fingerprint).
  • بعد التفعيل، التحقق من صحة الترخيص يتم بالكامل محلياً وبلا إنترنت:
    التحقق من التوقيع الرقمي بالمفتاح العام المرفق (license_public_key.pem)
    + مطابقة بصمة الجهاز الحالية — لا يمكن نسخ ملف dss.lic إلى جهاز آخر
    وتشغيله، ولا يمكن تعديل بياناته يدوياً (أي تعديل يُبطل التوقيع فوراً).
  • هذا هو بالضبط ما يجعل تزوير ترخيص مستحيلاً حتى مع اطّلاع كامل على
    الكود المصدري: المفتاح الخاص للتوقيع لا يغادر خادم DONIA LABS TECH أبداً.
"""
import hashlib, json, platform, uuid, urllib.request, urllib.error
from datetime import datetime
from pathlib import Path
from app.core.config import cfg

_PUBLIC_KEY_PATH = Path(__file__).resolve().parent / "license_public_key.pem"


def get_fp() -> str:
    """بصمة جهاز شبه ثابتة (MAC address + اسم الجهاز + معمارية المعالج) —
    نفس المنطق المعتمد سابقاً، محفوظة للتوافق مع أي ترخيص فُعِّل من قبل."""
    parts = [hex(uuid.getnode()).upper(), platform.node(), platform.machine()]
    return hashlib.sha256("|".join(parts).encode()).hexdigest()


def _load_public_key():
    from cryptography.hazmat.primitives import serialization
    if not _PUBLIC_KEY_PATH.exists():
        return None
    with open(_PUBLIC_KEY_PATH, "rb") as f:
        return serialization.load_pem_public_key(f.read())


def _verify_signature(payload: dict, signature_hex: str) -> bool:
    from cryptography.exceptions import InvalidSignature
    pub = _load_public_key()
    if pub is None:
        return False
    try:
        canonical = json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
        pub.verify(bytes.fromhex(signature_hex), canonical)
        return True
    except (InvalidSignature, ValueError):
        return False


def verify_license(path: str) -> dict:
    """تحقق محلي بالكامل (بلا إنترنت): يقرأ dss.lic، يتحقق من التوقيع الرقمي
    بالمفتاح العام، ثم يتحقق من مطابقة بصمة هذا الجهاز لِما وُقِّع عليه."""
    try:
        if not Path(path).exists():
            return {"valid": False, "message": "لا يوجد ترخيص مُفعَّل — يرجى إدخال مفتاح الترخيص لتفعيله"}
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        payload = data.get("payload", {})
        signature = data.get("signature", "")
        if not payload or not signature:
            return {"valid": False, "message": "ملف الترخيص تالف أو غير مكتمل", "payload": payload}

        if not _verify_signature(payload, signature):
            return {"valid": False, "message": "توقيع الترخيص غير صالح — الملف قد يكون مُعدَّلاً أو منسوخاً من جهاز آخر",
                    "payload": payload}

        if payload.get("hardware_fingerprint") != get_fp():
            return {"valid": False, "message": "هذا الترخيص مُفعَّل لجهاز آخر — تواصل مع DONIA LABS TECH لإعادة الربط",
                    "payload": payload}

        expires = payload.get("expires_at")
        if expires:
            try:
                exp = datetime.fromisoformat(expires)
                if datetime.now() > exp:
                    d = (datetime.now() - exp).days
                    return {"valid": False, "message": f"انتهت صلاحية الترخيص منذ {d} يوم", "payload": payload}
                rem = (exp - datetime.now()).days
                return {"valid": True, "message": f"الترخيص صالح — متبقي {rem} يوم",
                        "payload": payload, "days_remaining": rem}
            except Exception:
                pass

        return {"valid": True, "message": "الترخيص صالح (دائم)", "payload": payload}
    except Exception as e:
        return {"valid": False, "message": f"خطأ في قراءة الترخيص: {str(e)}"}


def activate_license(key: str) -> dict:
    """تفعيل عبر الإنترنت (مرة واحدة) — يتصل بخادم التراخيص، الذي يتحقق من
    وجود المفتاح وصلاحيته ويربطه ببصمة هذا الجهاز، ثم يُعيد بيانات موقَّعة
    رقمياً تُحفظ محلياً. من هذه اللحظة، كل تحقق لاحق يتم محلياً بلا إنترنت."""
    key = key.strip().upper()
    parts = key.split("-")
    if len(parts) != 5 or parts[0] != "DSS":
        return {"success": False, "message": "صيغة المفتاح غير صحيحة — يجب أن تكون DSS-XXXX-XXXX-XXXX-XXXX"}

    server = (cfg.LICENSE_SERVER or "").strip().rstrip("/")
    if not server:
        return {"success": False, "message": "لم يُضبط خادم التراخيص (LICENSE_SERVER) في ملف .env — تواصل مع DONIA LABS TECH"}

    fp = get_fp()
    try:
        body = json.dumps({"license_key": key, "hardware_fp": fp}).encode("utf-8")
        req = urllib.request.Request(
            f"{server}/api/activate", data=body,
            headers={"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            result = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            result = json.loads(e.read().decode("utf-8"))
            return {"success": False, "message": result.get("message", "فشل التفعيل")}
        except Exception:
            return {"success": False, "message": "تعذّر الاتصال بخادم التراخيص — تحقق من الإنترنت وحاول مرة أخرى"}
    except Exception:
        return {"success": False, "message": "تعذّر الاتصال بخادم التراخيص — تحقق من الإنترنت وحاول مرة أخرى"}

    if not result.get("success"):
        return {"success": False, "message": result.get("message", "فشل التفعيل")}

    payload = result.get("payload", {})
    signature = result.get("signature", "")
    if not _verify_signature(payload, signature):
        # حماية إضافية: نرفض حفظ أي رد لا يتحقق توقيعه محلياً حتى لو جاء
        # الرد بنجاح ظاهري — يمنع قبول خادم مزيّف انتحل عنوان الخادم الحقيقي.
        return {"success": False, "message": "تعذّر التحقق من صحة رد الخادم — تواصل مع DONIA LABS TECH"}

    _write_lic(payload, signature)
    return {
        "success": True,
        "message": f"✓ تم التفعيل بنجاح لمؤسسة {payload.get('school_name','')}",
        "school": payload.get("school_name"),
        "plan": payload.get("plan"),
        "expires": payload.get("expires_at") or "دائم",
    }


def _write_lic(payload: dict, signature: str):
    data = {"payload": payload, "signature": signature, "saved_at": datetime.now().isoformat()}
    Path(cfg.LICENSE_FILE).parent.mkdir(parents=True, exist_ok=True)
    with open(cfg.LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def install_license_file(raw: bytes) -> dict:
    """تثبيت ملف ترخيص (dss.lic) صادر من DONIA LABS TECH بلا إنترنت: يتحقق من
    التوقيع الرقمي وبصمة هذا الجهاز قبل الحفظ، فلا يُقبل ملف مزوَّر أو لجهاز آخر."""
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception:
        return {"success": False, "message": "الملف ليس ملف ترخيص صالحاً"}
    payload, signature = data.get("payload") or {}, data.get("signature") or ""
    if not payload or not signature:
        return {"success": False, "message": "ملف الترخيص ناقص"}
    if not _verify_signature(payload, signature):
        return {"success": False, "message": "توقيع الترخيص غير صالح — الملف مُعدَّل أو مزوَّر"}
    if payload.get("hardware_fingerprint") != get_fp():
        return {"success": False, "message": "هذا الترخيص صادر لجهاز آخر — أرسل بصمة هذا الجهاز لإصدار ترخيص جديد"}
    _write_lic(payload, signature)
    res = verify_license(cfg.LICENSE_FILE)
    if not res.get("valid"):
        return {"success": False, "message": res.get("message", "ترخيص غير صالح")}
    return {"success": True, "message": f"✓ تم تثبيت الترخيص لمؤسسة {payload.get('school_name','')}",
            "school": payload.get("school_name"), "plan": payload.get("plan"),
            "expires": payload.get("expires_at") or "دائم"}
