# -*- coding: utf-8 -*-
"""
DONIA SMART SCHOOL v3 — XLS Parser
Handles all ministry file formats
DONIA LABS TECH © 2026
"""
from datetime import datetime
from typing import List

RANK_TO_ROLE = {
    "أستاذ": "teacher",
    "مشرف": "supervisor",
    "مدير": "director",
    "مستشار التربية": "counselor",
    "مستشار محلل": "admin",
    "مقتصد": "accountant",
    "عون إدارة": "admin",
    "عون حفظ": "admin",
    "عون مكتب": "admin",
    "عامل": "worker",
    "سائق": "worker",
    "ملحق": "worker",
    "عون": "admin",
    "ناظر": "nazir",
}

def rank_to_role(rank):
    rank = str(rank).strip()
    for key, role in RANK_TO_ROLE.items():
        if rank.startswith(key):
            return role
    return "worker"

def is_frameset(content: bytes) -> bool:
    try:
        text = content.decode('utf-8', errors='replace')[:500]
        return "Excel Workbook Frameset" in text or "shLink" in text
    except:
        return False

def parse_ministry_xls(content: bytes) -> List[dict]:
    """Parse student list from any format."""
    if is_frameset(content):
        return []
    decoded = content.decode('utf-8', errors='replace')
    if '<table' in decoded.lower():
        return _parse_students_html(decoded)
    return _parse_students_xlsx(content)


def parse_ministry_xls_debug(content: bytes) -> dict:
    """نسخة تشخيصية تُعيد أيضاً الأعمدة التي تم اكتشافها فعلياً وأول عيّنة من الأسطر،
    لتشخيص سبب استيراد 0 تلميذ بدل التخمين الأعمى."""
    info = {
        "is_frameset": is_frameset(content),
        "format": None,
        "tables_found": 0,
        "chosen_table_rows": 0,
        "header_row_index": None,
        "detected_columns": {},
        "sample_raw_headers": [],
        "sample_rows": [],
        "total_parsed": 0,
    }
    if info["is_frameset"]:
        return info
    decoded = content.decode('utf-8', errors='replace')
    if '<table' in decoded.lower():
        info["format"] = "html"
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(decoded, 'html.parser')
            tables = soup.find_all('table')
            info["tables_found"] = len(tables)
            if tables:
                table = max(tables, key=lambda t: len(t.find_all('tr')))
                rows = table.find_all('tr')
                info["chosen_table_rows"] = len(rows)
                header_idx = None
                hmap = {}
                for i, row in enumerate(rows):
                    texts = [c.get_text(strip=True) for c in row.find_all(['th', 'td'])]
                    joined = ' '.join(texts)
                    if any(k in joined for k in ['اللقب', 'الرقم الوطني', 'رقم التعريف', 'رتو']):
                        header_idx = i
                        hmap = _map_student_headers(texts)
                        info["sample_raw_headers"] = texts
                        break
                info["header_row_index"] = header_idx
                info["detected_columns"] = hmap
                if header_idx is not None:
                    for row in rows[header_idx + 1: header_idx + 4]:
                        cells = [c.get_text(strip=True) for c in row.find_all('td')]
                        if cells:
                            info["sample_rows"].append(cells)
        except Exception as e:
            info["error"] = str(e)
    else:
        info["format"] = "xlsx"
        try:
            import io, openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(content))
            ws = wb.active
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                cells = [str(c).strip() if c else '' for c in row]
                if not any(cells):
                    continue
                joined = ' '.join(cells)
                if i == 0 or any(k in joined for k in ['اللقب', 'الرقم الوطني']):
                    info["header_row_index"] = i
                    info["sample_raw_headers"] = cells
                    info["detected_columns"] = _map_student_headers(cells)
                    continue
                if len(info["sample_rows"]) < 3:
                    info["sample_rows"].append(cells)
        except Exception as e:
            info["error"] = str(e)
    try:
        info["total_parsed"] = len(parse_ministry_xls(content))
    except Exception:
        pass
    return info

def parse_staff_xls(content: bytes) -> List[dict]:
    """Parse staff list from any format."""
    decoded = content.decode('utf-8', errors='replace')
    if '<table' in decoded.lower():
        return _parse_staff_html(decoded)
    return _parse_staff_xlsx(content)

def generate_csv_template() -> str:
    headers = "الرقم الوطني,رقم التسجيل,اللقب,الاسم,تاريخ الميلاد,مكان الميلاد,الجنس,الصفة,معيد"
    sample  = "1101430000000000,0569,حيرش,بشرى,2014-12-09,المسيلة,أنثى,نصف داخلي,لا"
    return f"{headers}\n{sample}\n"

# ══════════════════════════════════════
# STUDENT PARSERS
# ══════════════════════════════════════

def _parse_students_html(html: str) -> List[dict]:
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, 'html.parser')
        tables = soup.find_all('table')
        if not tables:
            return []
        # Pick largest table
        table = max(tables, key=lambda t: len(t.find_all('tr')))
        rows = table.find_all('tr')
        if len(rows) < 2:
            return []

        # Find header row
        header_idx = None
        hmap = {}
        for i, row in enumerate(rows):
            texts = [c.get_text(strip=True) for c in row.find_all(['th','td'])]
            joined = ' '.join(texts)
            if any(k in joined for k in ['اللقب','الرقم الوطني','رقم التعريف','رتو']):
                header_idx = i
                hmap = _map_student_headers(texts)
                break

        if header_idx is None:
            return []

        result = []
        for row in rows[header_idx+1:]:
            cells = [c.get_text(strip=True) for c in row.find_all('td')]
            if len(cells) < 3:
                continue
            s = _map_student_row(cells, hmap)
            if s.get('last_name_ar'):
                result.append(s)
        return result
    except Exception as e:
        print(f"Student HTML parse error: {e}")
        return []

def _parse_students_xlsx(content: bytes) -> List[dict]:
    try:
        import io, openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(content))
        ws = wb.active
        hmap = {}
        result = []
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            cells = [str(c).strip() if c else '' for c in row]
            if not any(cells):
                continue
            joined = ' '.join(cells)
            if i == 0 or any(k in joined for k in ['اللقب','الرقم الوطني']):
                hmap = _map_student_headers(cells)
                continue
            s = _map_student_row(cells, hmap)
            if s.get('last_name_ar'):
                result.append(s)
        return result
    except Exception as e:
        print(f"Student XLSX parse error: {e}")
        return []

def _map_student_headers(headers: List[str]) -> dict:
    m = {}
    for i, h in enumerate(headers):
        h = h.strip()
        if any(k in h for k in ['الرقم الوطني','رتو','رقم التعريف','رقم وطني']):
            m['national_id'] = i
        elif 'رقم' in h and ('القيد' in h or 'التسجيل' in h):
            m['registration_num'] = i
        elif 'اللقب والاسم' in h or 'اللقب و الاسم' in h:
            m['full_name'] = i
        elif 'اللقب' in h and 'اسم' not in h:
            m['last_name_ar'] = i
        elif 'الاسم' in h and 'لقب' not in h and 'مكان' not in h and 'أب' not in h:
            m['first_name_ar'] = i
        elif 'الجنس' in h:
            m['gender'] = i
        elif 'تاريخ' in h and ('ميلاد' in h or 'ازدياد' in h):
            m['birth_date'] = i
        elif 'مكان' in h and ('ميلاد' in h or 'ازدياد' in h):
            m['birth_place'] = i
        elif h in ['الصفة','نظام التمدرس']:
            m['status'] = i
        elif 'الإعادة' in h or 'معيد' in h:
            m['is_repeating'] = i
        elif h in ['السنة','المستوى']:
            m['level'] = i
        elif h == 'القسم' or 'الفوج' in h:
            m['section'] = i
        elif 'الأب' in h and 'سم' in h:
            m['father_name'] = i
        elif 'العنوان' in h:
            m['address'] = i
    return m

def _map_student_row(cells: List[str], hmap: dict) -> dict:
    def g(field):
        i = hmap.get(field)
        return cells[i].strip() if i is not None and i < len(cells) else ''

    s = {}
    nid = g('national_id')
    if nid:
        s['national_id'] = nid

    reg = g('registration_num')
    s['registration_num'] = reg if reg and reg != '0' else None

    # Name
    full = g('full_name')
    if full:
        parts = full.split()
        s['last_name_ar']  = parts[0] if parts else ''
        s['first_name_ar'] = ' '.join(parts[1:]) if len(parts) > 1 else ''
    else:
        s['last_name_ar']  = g('last_name_ar')
        s['first_name_ar'] = g('first_name_ar')

    if not s.get('last_name_ar'):
        return {}

    gr = g('gender')
    s['gender'] = 'أنثى' if ('أنثى' in gr or gr == 'ف') else 'ذكر'

    bd = g('birth_date')
    if bd:
        s['birth_date'] = _parse_date(bd)

    s['birth_place'] = g('birth_place')

    st = g('status')
    if 'نصف' in st and 'داخلي' in st:
        s['status'] = 'نصف داخلي'
    elif 'داخلي' in st:
        s['status'] = 'داخلي'
    else:
        s['status'] = 'خارجي'

    s['is_repeating'] = g('is_repeating').lower() in ['نعم','yes','1','true','✓']

    father = g('father_name')
    if father:
        s['father_name'] = father
    addr = g('address')
    if addr:
        s['guardian_address'] = addr

    # Handle level/section from Eleve file
    level = g('level')
    section = g('section')
    if level and section:
        level_map = {'أولى':'1','ثانية':'2','ثالثة':'3','رابعة':'4'}
        lnum = level_map.get(level, level)
        s['_class'] = f"{lnum} متوسط {section}"

    return s

# ══════════════════════════════════════
# STAFF PARSERS
# ══════════════════════════════════════

def _parse_staff_html(html: str) -> List[dict]:
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, 'html.parser')
        tables = soup.find_all('table')
        if not tables:
            return []
        table = max(tables, key=lambda t: len(t.find_all('tr')))
        rows = table.find_all('tr')
        if len(rows) < 2:
            return []

        # Get headers from first row
        header_cells = [c.get_text(strip=True) for c in rows[0].find_all(['th','td'])]

        # Detect format by headers
        # Format A (staff_list.htm): رمز وظيفي, لقب, اسم, تاريخ, رتبة, مادة, وظيفة
        # Format B (original XLS):   صورة, رمز وظيفي, لقب, اسم, تاريخ, رتبة, مادة, درجة...
        hmap = {}
        for i, h in enumerate(header_cells):
            h = h.strip()
            if 'الرمز' in h or 'الوظيفي' in h:
                hmap['job_code'] = i
            elif h == 'اللقب':
                hmap['last'] = i
            elif h == 'الاسم':
                hmap['first'] = i
            elif 'تاريخ' in h:
                hmap['birth_date'] = i
            elif 'الرتبة' in h:
                hmap['rank'] = i
            elif 'المادة' in h:
                hmap['subject'] = i

        staff = []
        for row in rows[1:]:
            cells = [c.get_text(strip=True) for c in row.find_all('td')]
            if len(cells) < 3:
                continue

            def g(field):
                i = hmap.get(field)
                return cells[i].strip() if i is not None and i < len(cells) else ''

            last    = g('last')
            first   = g('first')
            job_code= g('job_code')
            rank    = g('rank')
            subject = g('subject')
            bdate   = g('birth_date')

            # If no header map found, use positional (original XLS format)
            if not hmap and len(cells) >= 7:
                # Format: photo(0), job_code(1), last(2), first(3), birth(4), rank(5), subject(6)
                job_code = cells[1] if len(cells) > 1 else ''
                last     = cells[2] if len(cells) > 2 else ''
                first    = cells[3] if len(cells) > 3 else ''
                bdate    = cells[4] if len(cells) > 4 else ''
                rank     = cells[5] if len(cells) > 5 else ''
                subject  = cells[6] if len(cells) > 6 else ''

            if not last or last in ['اللقب','الصورة','']:
                continue

            role     = rank_to_role(rank)
            username = _make_username(last, first, job_code)

            staff.append({
                'last_name':  last,
                'first_name': first,
                'full_name':  f'{last} {first}'.strip(),
                'birth_date': _parse_date(bdate),
                'rank':       rank,
                'subject':    subject,
                'job_code':   job_code,
                'role':       role,
                'username':   username,
            })
        return staff
    except Exception as e:
        print(f"Staff HTML parse error: {e}")
        return []

def _parse_staff_xlsx(content: bytes) -> List[dict]:
    try:
        import io, openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(content))
        ws = wb.active
        staff = []; header_found = False; hmap = {}
        for row in ws.iter_rows(values_only=True):
            cells = [str(c).strip() if c else '' for c in row]
            if not any(cells): continue
            if 'اللقب' in cells and not header_found:
                for i, c in enumerate(cells):
                    if c == 'اللقب': hmap['last'] = i
                    elif c == 'الاسم': hmap['first'] = i
                    elif 'الرتبة' in c: hmap['rank'] = i
                    elif 'المادة' in c: hmap['subject'] = i
                header_found = True; continue
            if header_found and hmap.get('last') is not None:
                def g(f): i=hmap.get(f,99); return cells[i] if i<len(cells) else ''
                last=g('last'); first=g('first'); rank=g('rank')
                if last:
                    staff.append({'last_name':last,'first_name':first,
                                  'full_name':f'{last} {first}'.strip(),'rank':rank,
                                  'subject':g('subject'),'role':rank_to_role(rank),
                                  'username':_make_username(last,first,'')})
        return staff
    except Exception as e:
        print(f"Staff XLSX parse error: {e}")
        return []

def parse_grades_xls(content: bytes) -> List[dict]:
    """يحلّل ملف نقاط (حجز أستاذ / رقمنة) بصيغة جدول HTML أو xlsx حقيقي.
    يبحث عن عمود تعريف التلميذ (رقم القيد/الرقم الوطني/اللقب والاسم) وأعمدة
    النقاط (فرض1، فرض2، نشاط، اختبار، معدل). ملاحظة: هذا محلل مرن بأفضل
    تخمين ممكن دون نموذج حقيقي من ملفاتكم — قد يحتاج ضبطاً دقيقاً بعد
    تجربته على ملف حقيقي."""
    is_frame = is_frameset(content)
    if is_frame:
        return []
    decoded = content.decode('utf-8', errors='replace')
    if '<table' in decoded.lower():
        return _parse_grades_html(decoded)
    return _parse_grades_xlsx(content)

def _map_grade_headers(headers: List[str]) -> dict:
    m = {}
    for i, h in enumerate(headers):
        h = (h or "").strip()
        if any(k in h for k in ['الرقم الوطني','رقم وطني']):
            m['national_id'] = i
        elif 'رقم' in h and ('القيد' in h or 'التسجيل' in h):
            m['registration_num'] = i
        elif 'اللقب والاسم' in h or 'اللقب و الاسم' in h:
            m['full_name'] = i
        elif h == 'اللقب':
            m['last_name_ar'] = i
        elif h == 'الاسم':
            m['first_name_ar'] = i
        elif 'فرض' in h and ('1' in h or 'أول' in h or 'الأول' in h):
            m['fard1'] = i
        elif 'فرض' in h and ('2' in h or 'ثاني' in h or 'الثاني' in h):
            m['fard2'] = i
        elif 'نشاط' in h:
            m['activity'] = i
        elif 'اختبار' in h or 'امتحان' in h:
            m['exam'] = i
        elif 'معدل' in h:
            m['average'] = i
    return m

def _num(v):
    try:
        v = str(v).strip().replace(',', '.')
        return float(v) if v else None
    except (ValueError, TypeError):
        return None

def _map_grade_row(cells: List[str], hmap: dict) -> dict:
    def g(field):
        i = hmap.get(field)
        return cells[i].strip() if i is not None and i < len(cells) else ''
    row = {
        'national_id': g('national_id') or None,
        'registration_num': g('registration_num') or None,
        'fard1': _num(g('fard1')), 'fard2': _num(g('fard2')),
        'activity': _num(g('activity')), 'exam_raw': _num(g('exam')),
        'term_average': _num(g('average')),
    }
    full = g('full_name')
    if full:
        parts = full.split()
        row['last_name_ar'] = parts[0] if parts else ''
        row['first_name_ar'] = ' '.join(parts[1:]) if len(parts) > 1 else ''
    else:
        row['last_name_ar'] = g('last_name_ar')
        row['first_name_ar'] = g('first_name_ar')
    return row

def _parse_grades_html(html: str) -> List[dict]:
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, 'html.parser')
        tables = soup.find_all('table')
        if not tables:
            return []
        table = max(tables, key=lambda t: len(t.find_all('tr')))
        rows = table.find_all('tr')
        header_idx = None; hmap = {}
        for i, row in enumerate(rows):
            texts = [c.get_text(strip=True) for c in row.find_all(['th','td'])]
            joined = ' '.join(texts)
            if any(k in joined for k in ['اللقب','فرض','معدل','الرقم الوطني']):
                header_idx = i; hmap = _map_grade_headers(texts)
                break
        if header_idx is None or not hmap:
            return []
        result = []
        for row in rows[header_idx+1:]:
            cells = [c.get_text(strip=True) for c in row.find_all('td')]
            if len(cells) < 2: continue
            r = _map_grade_row(cells, hmap)
            if r.get('last_name_ar'):
                result.append(r)
        return result
    except Exception as e:
        print(f"Grades HTML parse error: {e}")
        return []

def _parse_grades_xlsx(content: bytes) -> List[dict]:
    try:
        import io, openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(content))
        ws = wb.active
        hmap = {}
        result = []
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            cells = [str(c).strip() if c is not None else '' for c in row]
            if not any(cells): continue
            joined = ' '.join(cells)
            if not hmap and any(k in joined for k in ['اللقب','فرض','معدل']):
                hmap = _map_grade_headers(cells); continue
            if hmap:
                r = _map_grade_row(cells, hmap)
                if r.get('last_name_ar'):
                    result.append(r)
        return result
    except Exception as e:
        print(f"Grades XLSX parse error: {e}")
        return []


# ══════════════════════════════════════
# HELPERS
# ══════════════════════════════════════

def _make_username(last: str, first: str, code: str) -> str:
    import re
    ar = {'أ':'a','ب':'b','ت':'t','ث':'th','ج':'j','ح':'h','خ':'kh','د':'d','ذ':'z',
          'ر':'r','ز':'z','س':'s','ش':'sh','ص':'s','ض':'d','ط':'t','ظ':'z','ع':'a',
          'غ':'gh','ف':'f','ق':'q','ك':'k','ل':'l','م':'m','ن':'n','ه':'h','و':'w',
          'ي':'y','ة':'a','ى':'a','ا':'a','آ':'a','إ':'i','ء':'',' ':'_','/':'_','-':'_'}
    name = f'{last}{first}'.strip()
    result = ''.join(ar.get(c,'') for c in name[:12])
    result = re.sub(r'[^a-z0-9_]','',result.lower())
    return result[:20] if result else f'u{code[-4:] if code else "0001"}'

def _parse_date(ds: str):
    if not ds: return None
    ds = str(ds).strip()
    for fmt in ['%Y-%m-%d','%d/%m/%Y','%Y/%m/%d','%d-%m-%Y']:
        try: return datetime.strptime(ds, fmt).date()
        except ValueError: continue
    return None
