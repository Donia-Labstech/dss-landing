# -*- coding: utf-8 -*-
"""
DONIA SMART SCHOOL — استيراد استعمال الزمن من ملفات Excel (xlsx)
يدعم الصيغتين الشائعتين لبرامج جداول التوقيت (aSc Timetables وما يماثلها):
  1) صيغة «بطاقات»: جداول متجاورة (أساتذة/أقسام/مواد/قاعات/بطاقات) في ورقة واحدة
     — الأعمدة: classids, subjectid, teacherids, classroomids, day, period
  2) صيغة «شبكة الأستاذ»: سطر لكل (رمز الأستاذ، اليوم+الفترة ص/م، رقم الحصة،
     المادة، النوع، القسم، القاعة)
لا تحتوي هذه الوحدة أي بيانات؛ تقرأ البنية فقط وتُعيد حصصاً موحَّدة.
"""
import io
import re
from collections import Counter

# فهرس اليوم كما في إعدادات النظام: 0=السبت 1=الأحد ... 5=الخميس
_DAY_BY_NAME = {"السبت": 0, "الاحد": 1, "الاثنين": 2, "الثلاثاء": 3, "الاربعاء": 4, "الخميس": 5}

# كلمات تدل على نشاط ليس حصة تدريس لقسم (يُتجاوز إن لم يرتبط بقسم)
_NON_TEACHING = ("استقبال", "التنسيق", "صيانة", "استدراك", "مكتبه")

# (جزء من الاسم المُطبَّع) → اسم المادة في النظام. الترتيب مهم (الأخص أولاً)
_SUBJECT_RULES = [
    ("امازيغ", "اللغة الأمازيغية"),
    ("اعلام", "الإعلام الآلي"), ("info", "الإعلام الآلي"),
    ("موسيق", "التربية الموسيقية"),
    ("تشكيل", "التربية التشكيلية"),
    ("بدني", "التربية البدنية والرياضية"), ("رياضه", "التربية البدنية والرياضية"),
    ("اسلام", "التربية الإسلامية"),
    ("مدني", "التربية المدنية"),
    ("اجتماعيات", "التاريخ والجغرافيا"), ("تاريخ", "التاريخ والجغرافيا"), ("جغراف", "التاريخ والجغرافيا"),
    ("فيز", "الفيزياء والكيمياء"),
    ("علوم", "العلوم الطبيعية"),
    ("رياض", "الرياضيات"),
    ("انجليز", "اللغة الإنجليزية"), ("english", "اللغة الإنجليزية"),
    ("فرنس", "اللغة الفرنسية"), ("fr", "اللغة الفرنسية"),
    ("عربي", "اللغة العربية"),
]


def norm(s):
    """تطبيع نص عربي للمقارنة: بلا تشكيل/تطويل/أقواس، توحيد الهمزات والتاء المربوطة."""
    s = str(s or "").strip().lower()
    s = re.sub(r"[ً-ٰٟـ]", "", s)
    for a, b in (("أ", "ا"), ("إ", "ا"), ("آ", "ا"), ("ة", "ه"), ("ى", "ي"), ("ؤ", "و"), ("ئ", "ي")):
        s = s.replace(a, b)
    s = re.sub(r"[()\[\]_\-–.:,،]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def map_subject(raw):
    """يحوّل اسم مادة من ملف خارجي إلى اسم المادة المعتمد في النظام (أو None).
    إن كان مركّباً (عربية/رياضيات) يُؤخذ الجزء الأول، ويُعاد الاسم الأصلي كتسمية."""
    n = norm(raw)
    if not n:
        return None
    first = re.split(r"[/\\+]", n)[0].strip() or n
    for key, name in _SUBJECT_RULES:
        if key in first:
            return name
    return None


def clean_label(raw):
    """«عربية/رياضيات_TD» → «عربية/رياضيات»؛ يُعاد فارغاً لغير المركّب."""
    t = str(raw or "").strip()
    if "/" not in t:
        return ""
    t = re.sub(r"_?\s*(TD|TP)\s*$", "", t, flags=re.I).strip(" _-")
    return t[:100]


def parse_class(raw):
    """«4م2» أو «4 متوسط 2» → (4, '2')؛ وإلا None."""
    m = re.search(r"(\d)\s*(?:م|متوسط)\s*(\d+)", str(raw or ""))
    return (int(m.group(1)), m.group(2)) if m else None


def division_name(level, section):
    return f"{level} متوسط {section}"


def is_non_teaching(raw):
    n = norm(raw)
    return any(k in n for k in _NON_TEACHING)


def period_label(idx, morning_periods=4):
    """رقم حصة مطلق (1..) → رمز النظام: ص1..صN ثم م1..مN."""
    idx = int(idx)
    return f"ص{idx}" if idx <= morning_periods else f"م{idx - morning_periods}"


def _rows(content):
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True, read_only=True)
    ws = wb.worksheets[0]
    return [list(r) for r in ws.iter_rows(values_only=True)]


def detect_format(content):
    try:
        rows = _rows(content)
    except Exception:
        return None
    if not rows:
        return None
    head = [norm(c) for c in rows[0]]
    if "ascttversion" in head or "importtype" in head:
        return "cards"
    if len(rows[0]) >= 7 and head[:3] == ["name", "name2", "name3"]:
        return "grid"
    # تخمين: عمود ثانٍ يحوي «ص/م» في الأسطر
    for r in rows[1:6]:
        if len(r) >= 7 and r[1] and re.search(r"\s[صم]$", str(r[1]).strip()):
            return "grid"
    return None


def parse_timetable_xlsx(content, morning_periods=4):
    fmt = detect_format(content)
    if fmt == "cards":
        return _parse_cards(_rows(content), morning_periods)
    if fmt == "grid":
        return _parse_grid(_rows(content), morning_periods)
    raise ValueError("صيغة ملف المواقيت غير معروفة — المتوقع تصدير aSc Timetables أو شبكة الأساتذة")


def _parse_grid(rows, pm):
    teachers, entries, no_class = {}, [], 0
    hints, activities = {}, []
    for r in rows[1:]:
        r = list(r) + [None] * (8 - len(r))
        code, dayshift, num, _id, subj, typ, cls, room = [(str(c).strip() if c is not None else "") for c in r[:8]]
        if not code:
            continue
        teachers.setdefault(code, {"name": "", "short": code})
        if not subj:
            continue
        m = re.match(r"^(.*?)\s*([صم])$", dayshift)
        if not m or not num.isdigit():
            continue
        day = _DAY_BY_NAME.get(norm(m.group(1)))
        if day is None:
            continue
        n = int(num)
        per = f"{m.group(2)}{n}"
        hints.setdefault(code, Counter())[subj] += 1
        if not cls or not parse_class(cls):
            no_class += 1
            activities.append({"teacher": code, "label": subj, "day": day, "period": per})
            continue
        entries.append({"teachers": [code], "subject_raw": subj, "type": typ or None,
                        "class": cls, "room": room or None, "day": day, "period": per})
    for c, cnt in hints.items():
        teachers[c]["subject_hint"] = cnt.most_common(1)[0][0]
    # حصص مشتركة: نفس (قسم، يوم، حصة) لأستاذين → حصة واحدة بأستاذين
    merged, seen = [], {}
    for e in entries:
        k = (e["class"], e["day"], e["period"])
        if k in seen:
            o = seen[k]
            for t in e["teachers"]:
                if t not in o["teachers"]:
                    o["teachers"].append(t)
            continue
        seen[k] = e
        merged.append(e)
    return {"format": "grid", "teachers": teachers, "entries": merged, "skipped_no_class": no_class,
            "activities": activities}


def _parse_cards(rows, pm):
    head = [str(c or "").strip() for c in rows[0]]
    # الجداول مكدّسة عمودياً: خلية columns* في كل سطر تحوي حقول ذلك الجدول،
    # وبياناته في الأعمدة التالية لها مباشرة
    # أسماء الحقول تؤخذ من سطر العناوين (أعمدة بعد columns* حتى options*/columns* التالي)،
    # لأن نص خلية columns* قد لا يطابق ترتيب الأعمدة الفعلي
    blocks = []
    for j, h in enumerate(head):
        if h.lower().startswith("columns"):
            fields = []
            for k in range(j + 1, len(head)):
                hk = head[k].lower()
                if not hk or hk.startswith("options") or hk.startswith("columns"):
                    break
                fields.append(re.sub(r"\d+$", "", head[k]))
            blocks.append((j, fields))

    def table(j, fields):
        out = []
        for r in rows[1:]:
            if j >= len(r) or not r[j]:
                continue
            vals = [r[j + 1 + i] if j + 1 + i < len(r) else None for i in range(len(fields))]
            out.append(dict(zip(fields, [("" if v is None else str(v).strip()) for v in vals])))
        return out

    cards = None
    id_tables = []
    for start, fields in blocks:
        if "day" in fields and "period" in fields:
            cards = table(start, fields)
        elif fields and fields[0] == "id":
            id_tables.append(table(start, fields))
    if cards is None:
        raise ValueError("لم يُعثر على جدول البطاقات (day, period) في الملف")

    # تحديد دور كل جدول بمحتواه (المعرّفات كلها من الشكل *n فلا تصلح للتمييز)
    def frac(t, pred):
        return sum(1 for r in t if pred(r.get("name", ""))) / max(len(t), 1)

    rest = list(id_tables)
    tt = max(rest, key=lambda t: frac(t, lambda n: bool(parse_class(n))), default=[])
    if tt in rest:
        rest.remove(tt)
    tt4 = max(rest, key=lambda t: frac(t, lambda n: "قاع" in n or "salle" in n.lower()), default=[])
    if tt4 in rest:
        rest.remove(tt4)
    tt2 = max(rest, key=len, default=[])
    if tt2 in rest:
        rest.remove(tt2)
    tt3 = rest[0] if rest else []
    classes = {r["id"]: r.get("name", "") for r in tt}
    def _clean_name(n):
        # يُحذف رمز الأستاذ الملصق بالاسم (مثل «طرشي ربيعة عر8»)
        return re.sub(r"\s+[\u0621-\u064a]{1,8}\d+\s*$", "", n or "").strip()
    tchs = {r["id"]: {"name": _clean_name(r.get("name", "")), "short": r.get("short", "")} for r in tt2}
    subjects = {r["id"]: r.get("name", "") for r in tt3}
    rooms = {r["id"]: r.get("name", "") for r in tt4}

    entries, no_class, activities = [], 0, []
    for c in cards:
        try:
            day = int(c.get("day", "")) + 1       # 0=الأحد في هذا التصدير ← فهرس النظام 1
            period = period_label(int(c.get("period", "")), pm)
        except ValueError:
            continue
        cls_ids = [x.strip() for x in str(c.get("classids", "")).split(",") if x.strip()]
        subj = subjects.get(c.get("subjectid", ""), "")
        tkeys = [x.strip() for x in str(c.get("teacherids", "")).split(",") if x.strip()]
        if not cls_ids:
            no_class += 1
            for tk in tkeys:
                activities.append({"teacher": tk, "label": subj, "day": day, "period": period})
            continue
        room = rooms.get(c.get("classroomids", ""), "") or None
        for cid in cls_ids:
            cname = classes.get(cid, "")
            if not parse_class(cname):
                continue
            entries.append({"teachers": tkeys, "subject_raw": subj, "type": None,
                            "class": cname, "room": room, "day": day, "period": period})
    return {"format": "cards", "teachers": tchs, "entries": entries, "skipped_no_class": no_class,
            "activities": activities}


def match_teacher(name, candidates):
    """candidates: [(id, full_name)] → (id, quality) أو (None, None).
    quality: 'exact' تطابق كامل بترتيب أو بدونه، 'approx' احتواء فريد."""
    tn = norm(name)
    if not tn:
        return None, None
    ts = set(tn.split())
    exact = [i for i, n in candidates if set(norm(n).split()) == ts]
    if len(exact) == 1:
        return exact[0], "exact"
    sub = [i for i, n in candidates if ts and ts <= set(norm(n).split())]
    if len(sub) == 1:
        return sub[0], "approx"
    return None, None


def suggest_teacher(name, candidates, cutoff=0.72):
    """أقرب مرشح بالتشابه النصي (للاقتراح فقط، لا يُطبَّق تلقائياً)."""
    import difflib
    tn = " ".join(sorted(norm(name).split()))
    if not tn:
        return None
    best, score = None, 0.0
    for i, n in candidates:
        sc = difflib.SequenceMatcher(None, tn, " ".join(sorted(norm(n).split()))).ratio()
        if sc > score:
            best, score = i, sc
    return best if score >= cutoff else None
