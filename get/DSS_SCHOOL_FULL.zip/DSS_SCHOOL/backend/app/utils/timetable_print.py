# -*- coding: utf-8 -*-
"""
DONIA SMART SCHOOL — مطبوعات المواقيت الرسمية (أستاذ / قسم / محل / تلميذ)
تحاكي نموذج «الجدول الزمني للأستاذ(ة)» المعتمد: عمود الأوقات على اليمين، الأيام من
الأحد إلى الخميس، صفّ فاصل «استراحة المساء»، نص المواد القانونية، ثم التاريخ وإمضاء المدير.
هذه الوحدة لا تصل إلى قاعدة البيانات: تستقبل خلايا جاهزة وتُعيد HTML.
"""
from datetime import date, datetime, timedelta

DAY_NAMES = ["السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس"]

LEGAL_TEACHER = """
<div class="tt-legal">
<b>طبقا للقرار: 153 المؤرخ في 26 فيفري 1991 المحدد لمهام أستاذ التعليم المتوسط:</b>
<div>المادة 02: يقوم الأستاذ بنصاب التعليم الأسبوعي المقرر له وفقا للأحكام القانونية المطبقة على كل سلك و يلزم بأداء الساعات الإضافية المسندة له.</div>
<div>المادة12: يكون الأستاذ مسؤولا عن جميع التلاميذ الموضوعين تحت سلطته المباشرة و في القسم طيلة المدة التي يستغرقها الدرس.</div>
<div>المادة 13: يكون الأستاذ مسؤولا عن انضباط التلاميذ و على أمنهم و يلتزم بالتكفل بهم من بداية الحصة إلى نهايتها.</div>
<div>المادة 14: لا يمكن للأستاذ التكفل بقسم غير منصوص عليه في جدول خدماته، أو يشغل قاعة أخرى غير المعينة له إلا بعد موافقة المدير أو نائبه.</div>
<b>المرسوم تنفيذي رقم 25-54 مؤرخ في 21 جانفي 2025، يتضمن القانون الأساسي الخاص بالموظفين المنتمين للأسلاك الخاصة بالتربية الوطنية.</b>
<div>المادة 91: يكلف أستاذ التعليم المتوسط تحت سلطة مدير المتوسطة وإشراف الناظر في التعليم المتوسط، بتعليم وتنشئة وتأهيل التلاميذ ومنحهم حسب مادة الاختصاص تعليما في المواد الأدبية والعلمية والتكنولوجية، وكذا التربية الفنية والتربية البدنية والرياضية، ويمارسون أنشطتهم في المتوسطات حسب المواد 94،92،91، ويحدد نصاب عملهم من التدريس في الأسبوع حسب أحكام المواد السابقة الذكر (أستاذ التعليم المتوسط، أستاذ التعليم المتوسط قسم أول وقسم ثان 20 ساعة) و(الأستاذ المميز 18 ساعة).</div>
</div>
"""

_CSS = """
<style>
 .tt-title{text-align:center;font-size:17px;font-weight:bold;margin:14px 0 8px;text-decoration:underline}
 table.tt{width:100%;border-collapse:collapse;margin:6px 0}
 table.tt th,table.tt td{border:1px solid #222;padding:3px 4px;text-align:center;font-size:12px;vertical-align:middle}
 table.tt th{background:#f2f2f2;font-size:13px}
 table.tt td.tm{width:62px;font-weight:bold;font-size:13px;white-space:nowrap;line-height:1.5}
 table.tt td.cell{height:48px;line-height:1.35}
 table.tt td.cell small{display:block;color:#222;font-size:11.5px}
 table.tt tr.brk td{background:#fafafa;font-weight:bold;letter-spacing:3px;height:22px}
 .tt-legal{font-size:11.5px;line-height:1.7;margin-top:8px}
 .tt-legal b{display:block;margin-top:4px;text-decoration:underline}
 .tt-foot{margin-top:14px;font-size:13px;line-height:2}
 .tt-page{page-break-after:always}
</style>
"""


def period_times(si_cfg, labels):
    """label → (بداية، نهاية) اعتماداً على ضبط المؤسسة (بداية صباحاً/مساءً + مدة الحصة)."""
    m0 = getattr(si_cfg, "tt_morning_start", None) or "08:00"
    e0 = getattr(si_cfg, "tt_evening_start", None) or "13:30"
    dur = int(getattr(si_cfg, "tt_period_minutes", None) or 60)
    out = {}
    def add(start, label_prefix):
        try:
            t = datetime.strptime(start, "%H:%M")
        except ValueError:
            t = datetime.strptime("08:00", "%H:%M")
        i = 1
        while f"{label_prefix}{i}" in labels:
            out[f"{label_prefix}{i}"] = (t.strftime("%H:%M"), (t + timedelta(minutes=dur)).strftime("%H:%M"))
            t += timedelta(minutes=dur)
            i += 1
    add(m0, "ص")
    add(e0, "م")
    return out


def render_timetable(title, cells, labels, times, days_used=None, legal=False, si=None, subtitle="",
                     city="", page_break=False):
    """cells: {(day_idx, period_label): html}. labels: ["ص1".."م4"]. يعيد HTML جاهزاً للإدراج داخل _doc_page."""
    days = [1, 2, 3, 4, 5]
    if any(k[0] == 0 for k in cells):
        days = [0] + days
    ths = "".join(f"<th>{DAY_NAMES[d]}</th>" for d in days)
    rows = ""
    morning = [p for p in labels if p.startswith("ص")]
    evening = [p for p in labels if p.startswith("م")]
    def row(p):
        a, b = times.get(p, ("", ""))
        tcell = f"<td class='tm'>{a}<br>{b}</td>"
        tds = "".join(f"<td class='cell'>{cells.get((d, p), '')}</td>" for d in days)
        return f"<tr>{tcell}{tds}</tr>"
    for p in morning:
        rows += row(p)
    if evening:
        rows += f"<tr class='brk'><td colspan='{len(days)+1}'>استراحـــــة المســـــاء</td></tr>"
        for p in evening:
            rows += row(p)
    today = date.today().strftime("%Y-%m-%d")
    head_sub = f"<div class='tt-title' style='font-size:14px;text-decoration:none'>{subtitle}</div>" if subtitle else ""
    foot = (f"<div class='tt-foot'>{(city + ' ') if city else ''}في: {today}<br>"
            f"<b style='text-decoration:underline'>إمضاء المدير:</b>"
            f"<div style='margin-top:2px'>{(si.director_name if si and si.director_name else '')}</div></div>")
    html = (f"{_CSS}<div class='tt-title'>{title}</div>{head_sub}"
            f"<table class='tt'><thead><tr><th style='width:62px'></th>{ths}</tr></thead><tbody>{rows}</tbody></table>"
            f"{LEGAL_TEACHER if legal else ''}{foot}")
    return f"<div class='tt-page'>{html}</div>" if page_break else html
