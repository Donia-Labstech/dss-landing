// DONIA SMART SCHOOL — خدمة عمل خفيفة: تجعل الواجهة قابلة للتثبيت وتفتح غلافها حتى لو انقطع الخادم.
// لا تُخزَّن أي استجابة /api/ أبداً (بيانات حيّة وحساسة).
const V = 'dss-shell-v1';
self.addEventListener('install', e => { self.skipWaiting(); e.waitUntil(caches.open(V).then(c => c.add('/')).catch(() => {})); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/') || u.pathname.startsWith('/uploads/')) return;
  if (r.mode === 'navigate') {
    e.respondWith(fetch(r).then(res => { const cp = res.clone(); caches.open(V).then(c => c.put('/', cp)); return res; })
      .catch(() => caches.match('/').then(m => m || new Response('الخادم غير متاح حالياً — تأكد أن برنامج DONIA SMART SCHOOL يعمل على الحاسوب.', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } }))));
    return;
  }
  if (u.pathname.startsWith('/assets/')) {
    e.respondWith(caches.match(r).then(m => m || fetch(r).then(res => { const cp = res.clone(); caches.open(V).then(c => c.put(r, cp)); return res; })));
  }
});
