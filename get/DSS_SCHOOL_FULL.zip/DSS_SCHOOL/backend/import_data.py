# -*- coding: utf-8 -*-
"""
DONIA SMART SCHOOL - استيراد البيانات
يستورد الموظفين والتلاميذ مباشرة لقاعدة البيانات
"""
import sys, os, json, sqlite3, hashlib, re
from pathlib import Path
from datetime import datetime

BASE = Path(__file__).parent
sys.path.insert(0, str(BASE))
os.makedirs(BASE / 'data', exist_ok=True)
os.makedirs(BASE / 'licenses', exist_ok=True)

from dotenv import load_dotenv
load_dotenv(BASE / '.env')

DB_PATH = BASE / 'data' / 'dss_school.db'

ROLE_GATES = {
    "director":   ["G01","G02","G03","G04","G05","G06","G07","G08","G09","G10","G11","G12","G13","G14","G15","G16","G17","G18","G19","G20","G21","G22"],
    "teacher":    ["G04","G05","G09","G18"],
    "supervisor": ["G02","G07","G11","G18"],
    "counselor":  ["G01","G02","G03","G07","G11","G12","G13","G14","G18","G19"],
    "accountant": ["G11","G12","G18"],
    "admin":      ["G01","G06","G12","G13","G17","G18"],
    "worker":     ["G18"],
    "nazir":      ["G01","G07","G08","G09","G10","G12","G13","G14","G17","G18"],
}

def hash_pw(p):
    try:
        import bcrypt
        return bcrypt.hashpw(p.encode(), bcrypt.gensalt(12)).decode()
    except:
        return "SHA256:" + hashlib.sha256(p.encode()).hexdigest()

def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'teacher',
        gates TEXT DEFAULT '[]',
        is_active INTEGER DEFAULT 1,
        last_login TEXT, login_attempts INTEGER DEFAULT 0,
        locked_until TEXT, phone TEXT DEFAULT '', email TEXT DEFAULT '',
        created_at TEXT DEFAULT (datetime('now')), created_by INTEGER
    );
    CREATE TABLE IF NOT EXISTS teachers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, first_name TEXT NOT NULL DEFAULT '',
        last_name TEXT NOT NULL DEFAULT '', specialty TEXT DEFAULT '',
        grade_rank TEXT DEFAULT '', weekly_hours INTEGER DEFAULT 18,
        phone TEXT DEFAULT '', email TEXT DEFAULT '', is_active INTEGER DEFAULT 1,
        start_date TEXT
    );
    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        national_id TEXT UNIQUE, registration_num TEXT UNIQUE,
        first_name_ar TEXT NOT NULL, last_name_ar TEXT NOT NULL,
        first_name_fr TEXT DEFAULT '', last_name_fr TEXT DEFAULT '',
        birth_date TEXT, birth_place TEXT DEFAULT '',
        gender TEXT DEFAULT 'ذكر', division_id INTEGER,
        status TEXT DEFAULT 'خارجي', is_repeating INTEGER DEFAULT 0,
        academic_year TEXT DEFAULT '2025/2026',
        father_name TEXT DEFAULT '', mother_name TEXT DEFAULT '',
        guardian_name TEXT DEFAULT '', guardian_phone TEXT DEFAULT '',
        is_active INTEGER DEFAULT 1, is_expelled INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now'))
    );
    """)
    conn.commit()
    return conn

def import_staff(filepath):
    from app.utils.xls_parser import parse_staff_xls
    print(f"\n  قراءة: {Path(filepath).name}")
    with open(filepath, 'rb') as f:
        staff = parse_staff_xls(f.read())
    if not staff:
        print("  [!] لا توجد بيانات في الملف"); return 0

    print(f"  ✓ {len(staff)} موظف")
    roles = {}
    for s in staff:
        roles[s['role']] = roles.get(s['role'], 0) + 1
    rn = {'teacher':'أستاذ','supervisor':'مشرف','director':'مدير',
          'counselor':'مستشار','accountant':'مقتصد','admin':'إداري','worker':'عامل'}
    for r, c in sorted(roles.items(), key=lambda x: -x[1]):
        print(f"     {c:3d} × {rn.get(r, r)}")

    ans = input("\n  هل تريد الاستيراد؟ (نعم): ").strip().lower()
    if ans not in ['نعم','oui','yes','y','']:
        print("  ألغيت"); return 0

    conn = get_db()
    pwd = hash_pw("Donia@2026")
    imported = skipped = 0
    for s in staff:
        try:
            un = s['username']; base = un; i = 1
            while conn.execute("SELECT id FROM users WHERE username=?", (un,)).fetchone():
                un = f"{base}{i}"; i += 1
            role = s['role']
            conn.execute(
                "INSERT INTO users (username,full_name,password_hash,role,gates,is_active) VALUES (?,?,?,?,?,1)",
                (un, s['full_name'], pwd, role, json.dumps(ROLE_GATES.get(role, ['G18'])))
            )
            if role == 'teacher':
                uid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                conn.execute(
                    "INSERT INTO teachers (user_id,first_name,last_name,specialty,is_active) VALUES (?,?,?,?,1)",
                    (uid, s.get('first',''), s.get('last',''), s.get('subject',''))
                )
            imported += 1
        except sqlite3.IntegrityError:
            skipped += 1
        except Exception as e:
            print(f"  خطأ: {e}"); skipped += 1
    conn.commit()
    total = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    conn.close()
    print(f"\n  ✓ مستورد: {imported} موظف")
    if skipped: print(f"  تخطي (مكرر): {skipped}")
    print(f"  إجمالي المستخدمين: {total}")
    print(f"  كلمة المرور: Donia@2026")
    return imported

def import_students(filepath):
    from app.utils.xls_parser import parse_ministry_xls, is_frameset
    with open(filepath, 'rb') as f:
        content = f.read()
    if is_frameset(content):
        print("  [!] هذا ملف Eleve.xls الفارغ")
        print("  يجب رفع ملف sheet001.htm من مجلد Eleve.files")
        return 0
    rows = parse_ministry_xls(content)
    if not rows:
        print("  [!] لا توجد بيانات"); return 0
    print(f"  ✓ {len(rows)} تلميذ")
    for s in rows[:3]:
        print(f"     {s.get('last_name_ar','')} {s.get('first_name_ar','')} — {s.get('gender','')}")
    ans = input("\n  هل تريد الاستيراد؟ (نعم): ").strip().lower()
    if ans not in ['نعم','oui','yes','y','']:
        print("  ألغيت"); return 0
    conn = get_db()
    imported = skipped = 0
    for row in rows:
        try:
            if not row.get('last_name_ar'): continue
            if row.get('national_id') and conn.execute(
                "SELECT id FROM students WHERE national_id=?", (row['national_id'],)
            ).fetchone():
                skipped += 1; continue
            conn.execute("""
                INSERT INTO students (national_id,registration_num,last_name_ar,first_name_ar,
                gender,birth_date,birth_place,status,is_repeating,is_active,academic_year)
                VALUES (?,?,?,?,?,?,?,?,?,1,'2025/2026')
            """, (
                row.get('national_id'), row.get('registration_num'),
                row.get('last_name_ar',''), row.get('first_name_ar',''),
                row.get('gender','ذكر'), str(row['birth_date']) if row.get('birth_date') else None,
                row.get('birth_place',''), row.get('status','خارجي'),
                1 if row.get('is_repeating') else 0,
            ))
            imported += 1
        except sqlite3.IntegrityError: skipped += 1
        except Exception as e: print(f"  خطأ: {e}")
    conn.commit()
    total = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    conn.close()
    print(f"\n  ✓ مستورد: {imported} تلميذ")
    if skipped: print(f"  تخطي (مكرر): {skipped}")
    print(f"  إجمالي التلاميذ: {total}")
    return imported

def find_file(patterns):
    import glob
    up = os.environ.get('USERPROFILE', os.path.expanduser('~'))
    for loc in [up + '/Downloads', up + '/Desktop', str(BASE), '.']:
        for pat in patterns:
            found = glob.glob(os.path.join(loc, pat))
            if found: return found[0]
    return None

def main():
    print()
    print("  ╔══════════════════════════════════════╗")
    print("  ║   DONIA SMART SCHOOL — الاستيراد    ║")
    print("  ╚══════════════════════════════════════╝")
    print()
    print("  [1] استيراد الموظفين (وزارة التربية.xls)")
    print("  [2] استيراد التلاميذ (sheet001.htm)")
    print("  [3] الاثنان معاً")
    print()
    choice = input("  اختيارك: ").strip()

    if choice in ['1', '3']:
        print("\n═══ الموظفون ═══")
        f = find_file(['وزارة*.xls', '*رقمنة*.xls', 'staff*.xls'])
        if f:
            print(f"  وجدت تلقائياً: {f}")
            ans = input("  استخدامه؟ Enter=نعم / n=لا: ").strip()
            if ans.lower() == 'n': f = None
        if not f:
            f = input("  المسار الكامل للملف: ").strip().strip('"').strip("'")
        if f and Path(f).exists():
            import_staff(f)
        else:
            print("  [!] الملف غير موجود")

    if choice in ['2', '3']:
        print("\n═══ التلاميذ ═══")
        f = find_file(['sheet001.htm', 'Eleve.files/sheet001.htm'])
        if f:
            print(f"  وجدت تلقائياً: {f}")
            ans = input("  استخدامه؟ Enter=نعم / n=لا: ").strip()
            if ans.lower() == 'n': f = None
        if not f:
            print()
            print("  تنبيه: ابحث عن مجلد Eleve.files على جهازك")
            print("  داخله ملف sheet001.htm — هذا هو الملف الصحيح")
            print()
            f = input("  المسار الكامل: ").strip().strip('"').strip("'")
        if f and Path(f).exists():
            import_students(f)
        else:
            print("  [!] الملف غير موجود")

    print()
    print("  ✓ اكتمل — شغّل main.py ثم افتح المتصفح")
    input("  اضغط Enter...")

if __name__ == '__main__':
    main()
