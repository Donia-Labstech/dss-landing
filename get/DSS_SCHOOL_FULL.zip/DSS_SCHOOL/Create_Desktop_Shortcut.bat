@echo off
rem Creates a "DONIA SMART SCHOOL" shortcut (with icon) on the Desktop. Run once.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\DONIA SMART SCHOOL.lnk'); $s.TargetPath='%~dp0start.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0backend\assets\dss.ico'; $s.WindowStyle=7; $s.Description='DONIA SMART SCHOOL'; $s.Save()"
if errorlevel 1 (
  echo Could not create the shortcut. You can right-click start.bat, Send to - Desktop, create shortcut.
) else (
  echo Done. A shortcut "DONIA SMART SCHOOL" was added to your Desktop.
)
pause
