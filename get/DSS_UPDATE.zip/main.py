"""
DONIA SMART SCHOOL v3 — Main (Fixed)
Flask + CORS Full + Index Route
DONIA LABS TECH © 2026
"""
import os, json, asyncio
from datetime import date, datetime, timedelta
from flask import Flask, jsonify, request, g, Response
from flask_cors import CORS

from app.core.config import cfg, GATES, ROLE_GATES, DECREE_833, ABSENCE_RULES, LEGAL_BASIS, LEGAL_SHORT, DAYS_OF_WEEK
from sqlalchemy import func as sa_func
from app.core.database import (
    init_db, Session,
    User, Student, Division, Subject, Grade, TermResult,
    Absence, AbsenceNotice, DailyReport, DailyAbsenceLog,
    OfficialDocument, DisciplineRecord, CheckPoint, LocationScan,
    ParentLink, Message, SchoolInfo, DocTemplateSample, NotificationLog,
    Room, ScheduleEntry, Teacher, OfficialHoursNorm, TeacherActivity,
    SessionCheck, ParentSummons, TeacherAbsence, SchoolHoliday,
    Club, ClubMember, ServiceScan
)
from app.core.auth import (
    authenticate, make_token, hash_pw, check_pw,
    login_required, gate_required, gate_any, write_audit
)
from app.services.services import GradeService, AbsenceService, DocNumberService, DisciplineService, StaffDocService
from app.services.notify import notify_absence
from app.services import daily_report as DR
from app.services import cards as CARDS
from app.services import guide as GUIDE
from app.services import remote as REMOTE
from app.services import updater as UPDATER

# ── App ───────────────────────────────────────────────────────
app = Flask(__name__)
app.config["JSON_AS_ASCII"] = False
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB max upload

from pathlib import Path as _Path
UPLOADS_DIR = _Path(__file__).parent / "uploads" / "photos"
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

# CORS — allow EVERYTHING (fixes browser file issue)
CORS(app,
     resources={r"/*": {"origins": "*"}},
     allow_headers=["Content-Type", "Authorization"],
     methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
     supports_credentials=False)

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# ── License gate ──────────────────────────────────────────────
# مسارات تبقى متاحة دائماً بغض النظر عن حالة الترخيص: تسجيل الدخول (حتى
# يستطيع المدير الوصول لصفحة الترخيص بعد الدخول)، ومسارات الترخيص نفسها،
# وتقديم الواجهة (index.html) حتى تظهر شاشة القفل بدل صفحة بيضاء.
_LICENSE_EXEMPT_PREFIXES = ("/api/license/", "/api/auth/login", "/api/public/")
_LICENSE_CACHE = {"ts": 0.0, "valid": False, "message": ""}
_LICENSE_CACHE_TTL = 15  # ثانية — يتحقق دورياً بدل كل طلب لتفادي كلفة تحقق التوقيع المتكررة

def _license_ok():
    """يتحقق من صلاحية الترخيص محلياً (مع تخزين مؤقت قصير) ويُعيد (valid, message).
    DSS_TRIAL_MODE=1 في .env يتجاوز التحقق تماماً — يُستعمل فقط لنسخة تجريبية
    محلية للتجربة قبل الشراء، ولا يُفعَّل أبداً في نسخة مؤسسة حقيقية."""
    if os.getenv("DSS_TRIAL_MODE") == "1":
        return True, "وضع تجريبي — بلا ترخيص"
    import time as _time
    from app.core.license import verify_license
    now = _time.time()
    if now - _LICENSE_CACHE["ts"] > _LICENSE_CACHE_TTL:
        res = verify_license(cfg.LICENSE_FILE)
        _LICENSE_CACHE["valid"] = bool(res.get("valid"))
        _LICENSE_CACHE["message"] = res.get("message", "")
        _LICENSE_CACHE["ts"] = now
    return _LICENSE_CACHE["valid"], _LICENSE_CACHE["message"]

@app.before_request
def _enforce_license():
    path = request.path or ""
    if request.method == "OPTIONS":
        return None
    if not path.startswith("/api/"):
        return None  # يسمح بتقديم index.html والملفات الساكنة دوماً
    if path.startswith(_LICENSE_EXEMPT_PREFIXES):
        return None
    valid, message = _license_ok()
    if not valid:
        return jsonify({
            "success": False,
            "error": "النظام غير مُفعَّل — يرجى تفعيل الترخيص من صفحة «الترخيص» للمتابعة",
            "license_required": True,
            "license_message": message,
        }), 402

# ── Helpers ───────────────────────────────────────────────────
def ok(data=None, msg="", code=200):
    r = {"success": True}
    if msg: r["message"] = msg
    if data is not None: r["data"] = data
    return jsonify(r), code

def err(msg, code=400):
    return jsonify({"success": False, "error": msg}), code

def SI(db):
    """يُعيد سطر معلومات المؤسسة الحيّ من قاعدة البيانات (اسم، ولاية، بلدية،
    أسماء المدير/الناظر/مستشار التربية/مستشار التوجيه/المشرف العام/المقتصد...)
    يُستعمل في كل مسارات توليد الوثائق الرسمية بدل القيم الثابتة في .env"""
    si = db.query(SchoolInfo).first()
    if not si:
        si = SchoolInfo(name_ar=cfg.SCHOOL_NAME, wilaya=cfg.WILAYA,
                        academic_year=cfg.ACADEMIC_YEAR, school_code=cfg.SCHOOL_CODE)
        db.add(si); db.commit(); db.refresh(si)
    _sync_rules(si)
    return si

def _sync_rules(si):
    """يُحدّث قاموس قواعد المواظبة (في الذاكرة) من إعدادات المؤسسة المحفوظة."""
    for col, key, lo, hi in (("abs_first", "first_notice", 1, 60), ("abs_second", "second_notice", 1, 60),
                             ("abs_warning", "warning", 1, 90), ("abs_evict_days", "eviction_days", 1, 90)):
        v = getattr(si, col, None)
        if isinstance(v, int) and lo <= v <= hi:
            ABSENCE_RULES[key] = v

def _countable_abs_dates(dates):
    """التغيّبات التي انقضى أجل تبريرها (48 ساعة) فقط هي التي تُحتسب نحو الإنذارات."""
    cutoff = date.today() - timedelta(days=max(1, ABSENCE_RULES.get("justify_hours", 48) // 24))
    return [d for d in dates if d <= cutoff]

# أسماء الطور المعرّفة (تُستعمل في كل الوثائق بدل النص الثابت "متوسطة")
LEVEL_LABELS = {
    "ابتدائية": {"institution": "الابتدائية", "director": "مدير(ة) المدرسة الابتدائية"},
    "متوسطة":   {"institution": "المتوسطة",   "director": "مدير(ة) المتوسطة"},
    "ثانوية":   {"institution": "الثانوية",   "director": "مدير(ة) الثانوية"},
}

def level_label(si, key="institution"):
    """يُعيد التسمية الصحيحة (الابتدائية/المتوسطة/الثانوية) حسب طور المؤسسة
    المسجّل فعلياً في الإعدادات، بدل الاعتماد على نص ثابت داخل الوثائق."""
    lt = (getattr(si, "level_type", None) or "متوسطة").strip()
    return LEVEL_LABELS.get(lt, LEVEL_LABELS["متوسطة"])[key]

# الشعب الرسمية للتعليم الثانوي الجزائري (تظهر فقط عندما تكون المؤسسة "ثانوية")
SECONDARY_STREAMS = {
    "جذع مشترك": ["جذع مشترك آداب", "جذع مشترك علوم وتكنولوجيا"],
    "السنتان الثانية والثالثة": [
        "آداب وفلسفة",
        "لغات أجنبية",
        "علوم تجريبية",
        "رياضيات",
        "تقني رياضي",
        "تسيير واقتصاد",
    ],
}
SECONDARY_STREAMS_FLAT = [s for grp in SECONDARY_STREAMS.values() for s in grp]

ALLOWED_PHOTO_EXT = {"jpg", "jpeg", "png", "webp"}

@app.post("/api/upload/photo")
@login_required
def upload_photo():
    """رفع صورة شخصية (تلميذ أو موظف) — تُعاد كمسار نسبي يُخزَّن في
    photo_path ويُستعمل مباشرة في بطاقات التعريف."""
    f = request.files.get("file")
    if not f or not f.filename:
        return err("لم يتم رفع ملف")
    ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
    if ext not in ALLOWED_PHOTO_EXT:
        return err("الصيغة غير مدعومة — استعمل jpg أو png أو webp")
    import uuid
    fname = f"{uuid.uuid4().hex}.{ext}"
    raw = f.read()
    if len(raw) > 12 * 1024 * 1024:
        return err("الصورة كبيرة جداً (الحد 12 ميغابايت)")
    try:   # تطبيع: تدوير حسب EXIF، تصغير إلى 640px، JPEG مضغوط (يُصغّر الحجم ويحذف بيانات الموقع)
        from PIL import Image, ImageOps
        import io as _io
        im = ImageOps.exif_transpose(Image.open(_io.BytesIO(raw))).convert("RGB")
        im.thumbnail((640, 640))
        buf = _io.BytesIO(); im.save(buf, "JPEG", quality=86, optimize=True)
        raw, fname = buf.getvalue(), f"{uuid.uuid4().hex}.jpg"
    except Exception:
        pass
    (UPLOADS_DIR / fname).write_bytes(raw)
    return ok({"photo_path": f"/uploads/photos/{fname}"})

@app.get("/uploads/photos/<path:fname>")
def serve_photo(fname):
    from flask import send_from_directory
    return send_from_directory(str(UPLOADS_DIR), fname)


@app.route('/assets/<path:fname>')
def serve_asset(fname):
    """أصول الواجهة الثابتة (الشعار) — قائمة بيضاء، لا تدخل في أي وثيقة مطبوعة."""
    from flask import send_from_directory
    if fname not in ("donia-logo.jpg", "app-icon-192.png", "app-icon-512.png",
                     "app-icon-maskable-512.png", "apple-touch-icon.png"):
        return Response("Not found", status=404)
    return send_from_directory(os.path.join(os.path.dirname(__file__), "assets"), fname,
                               max_age=86400)



@app.route('/manifest.webmanifest')
def web_manifest():
    """بيان تطبيق الويب (PWA): يجعل النظام قابلاً للتثبيت كتطبيق على الحاسوب والهاتف."""
    db = Session()
    try:
        si = SI(db)
        name = si.name_ar or "DONIA SMART SCHOOL"
    finally:
        db.close()
    m = {"name": f"DONIA SMART SCHOOL — {name}", "short_name": "DSS", "lang": "ar", "dir": "rtl",
         "start_url": "/", "scope": "/", "display": "standalone", "orientation": "any",
         "background_color": "#0F1117", "theme_color": "#0F1117",
         "icons": [{"src": "/assets/app-icon-192.png", "sizes": "192x192", "type": "image/png"},
                   {"src": "/assets/app-icon-512.png", "sizes": "512x512", "type": "image/png"},
                   {"src": "/assets/app-icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}]}
    return Response(json.dumps(m, ensure_ascii=False), mimetype="application/manifest+json")


@app.route('/sw.js')
def service_worker():
    from flask import send_from_directory
    resp = send_from_directory(os.path.join(os.path.dirname(__file__), "assets"), "sw.js",
                               mimetype="application/javascript")
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["Service-Worker-Allowed"] = "/"
    return resp


def _lan_ips():
    """عناوين IPv4 المحلية لهذا الحاسوب (للوصول من الهاتف عبر الواي فاي نفسه)."""
    import socket
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))     # لا تُرسَل أي حزمة؛ لاختيار واجهة الشبكة الفعّالة فقط
        ips.append(s.getsockname()[0]); s.close()
    except Exception:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.append(info[4][0])
    except Exception:
        pass
    out = []
    for ip in ips:
        if ip and not ip.startswith(("127.", "169.254.", "0.")) and ip not in out:
            out.append(ip)
    out.sort(key=lambda x: (not x.startswith(("192.168.", "10.")), x))
    return out


@app.get("/api/system/access")
@gate_required("G21")
def system_access():
    """عناوين الوصول للنظام من الهاتف/أجهزة أخرى داخل شبكة المؤسسة + رمز QR لكل عنوان."""
    import io, base64
    import qrcode
    port = request.host.rsplit(":", 1)[-1] if ":" in request.host else str(cfg.PORT)
    urls = []
    for ip in _lan_ips():
        u = f"http://{ip}:{port}"
        buf = io.BytesIO()
        qrcode.make(u, box_size=6, border=2).save(buf, format="PNG")
        urls.append({"url": u, "qr": "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()})
    return ok({"port": port, "urls": urls, "local": f"http://127.0.0.1:{port}"})

# ════════════════ الوصول عبر الإنترنت + التحديثات (المدير فقط) ════════════════
def _director_only():
    if g.role != "director":
        return err("للمدير فقط", 403)
    return None

def _default_admin_password_active():
    """يمنع فتح النظام للإنترنت وكلمة مرور admin الافتراضية ما زالت سارية."""
    from app.core.auth import check_pw
    db = Session()
    try:
        u = db.query(User).filter(User.username == "admin").first()
        return bool(u and u.is_active and check_pw("Donia@2026", u.password_hash))
    finally:
        db.close()

@app.get("/api/system/support")
@login_required
def support_status():
    e = _director_only()
    if e: return e
    from app.services import support as SUP
    return ok(SUP.status())

@app.post("/api/system/support")
@login_required
def support_action():
    """الدعم عن بعد بطلب المدير وحضوره: download / start / stop — كل جلسة تُسجَّل في سجل التدقيق."""
    e = _director_only()
    if e: return e
    from app.services import support as SUP
    act = (request.get_json() or {}).get("action")
    if act == "download":
        good, m = SUP.download()
        return ok(SUP.status(), msg="تم تنزيل أداة الدعم") if good else err("تعذّر التنزيل: " + m)
    if act == "start":
        good, m = SUP.start()
        if good: write_audit(g.user_id, "SUPPORT_SESSION_START", "system", 0)
        return ok(SUP.status(), msg="فُتحت أداة الدعم — اقرأ الرقم وكلمة المرور من نافذتها لفريق الدعم") if good else err(m)
    if act == "stop":
        mins = SUP.stop()
        write_audit(g.user_id, "SUPPORT_SESSION_END", "system", 0, new=f"{mins} min")
        return ok(SUP.status(), msg="أُغلقت جلسة الدعم")
    return err("طلب غير معروف")

@app.get("/api/system/remote")
@login_required
def remote_status():
    e = _director_only()
    if e: return e
    return ok(REMOTE.status())

@app.post("/api/system/remote")
@login_required
def remote_action():
    e = _director_only()
    if e: return e
    d = request.get_json() or {}
    act = d.get("action")
    port = request.host.rsplit(":", 1)[-1] if ":" in request.host else str(cfg.PORT)
    if act == "download":
        if not REMOTE.download():
            return err("تعذّر تنزيل أداة النفق. تأكد من اتصال الإنترنت ثم أعد المحاولة.")
        return ok(REMOTE.status(), msg="تم تنزيل أداة النفق")
    if act == "enable":
        if _default_admin_password_active():
            return err("لأمان بياناتك: غيّر كلمة مرور الحساب admin أولاً (ما زالت الافتراضية) ثم فعّل الوصول عبر الإنترنت.")
        mode = "token" if d.get("mode") == "token" else "quick"
        c = REMOTE.load()
        c.update(enabled=True, mode=mode)
        if mode == "token":
            tok = (d.get("token") or c.get("token") or "").strip()
            host = (d.get("hostname") or c.get("hostname") or "").strip().replace("https://", "").strip("/")
            if len(tok) < 40 or not host:
                return err("أدخل رمز النفق (Token) والعنوان (Hostname)")
            c.update(token=tok, hostname=host)
        REMOTE.save(c)
        if not REMOTE.has_binary() and not REMOTE.download():
            return err("تعذّر تنزيل أداة النفق. تأكد من اتصال الإنترنت ثم أعد المحاولة.")
        REMOTE.stop(); REMOTE.start(port)
        write_audit(g.user_id, "REMOTE_ENABLE", "system", 0)
        return ok(REMOTE.status(), msg="جارٍ فتح النفق...")
    if act == "disable":
        c = REMOTE.load(); c["enabled"] = False; REMOTE.save(c)
        REMOTE.stop()
        write_audit(g.user_id, "REMOTE_DISABLE", "system", 0)
        return ok(REMOTE.status(), msg="أُغلق الوصول عبر الإنترنت")
    return err("طلب غير معروف")

@app.get("/api/system/update")
@login_required
def update_info():
    e = _director_only()
    if e: return e
    return ok(UPDATER.info())

@app.post("/api/system/update")
@login_required
def update_action():
    e = _director_only()
    if e: return e
    d = request.get_json() or {}
    act = d.get("action")
    if act == "check":
        return ok(UPDATER.check())
    if act == "auto":
        UPDATER.set_auto(bool(d.get("value")))
        return ok(UPDATER.info())
    if act == "apply":
        good, m = UPDATER.apply()
        if good: write_audit(g.user_id, "SYSTEM_UPDATE", "system", 0)
        return (ok(UPDATER.info(), msg=m) if good else err(m))
    return err("طلب غير معروف")

# ── Index — Serve HTML frontend ───────────────────────────────
@app.route('/')
def index():
    path = os.path.join(os.path.dirname(__file__), 'index.html')
    if os.path.exists(path):
        content = open(path, encoding='utf-8').read()
        resp = Response(content, mimetype='text/html')
        resp.headers["Cache-Control"] = "no-store, max-age=0"   # لا تُخزَّن الواجهة: كل تحديث يظهر فوراً
        return resp
    return jsonify({"status": "running", "message": "ضع ملف index.html في مجلد backend"})

# ════════════════ AUTH ════════════════
@app.post("/api/auth/login")
def login():
    data = request.get_json() or {}
    user = authenticate(data.get("username",""), data.get("password",""))
    if not user:
        return err("اسم المستخدم أو كلمة المرور غير صحيحة", 401)
    if not user.is_active:
        return err("حسابك لم يُفعَّل بعد من طرف إدارة المؤسسة — يرجى الانتظار أو التواصل مع الإدارة", 403)
    token = make_token(user.id, user.role, user.full_name)
    write_audit(user.id, "LOGIN")
    return ok({"access_token": token, "token_type": "bearer",
               "user": {"id": user.id, "username": user.username,
                        "full_name": user.full_name, "role": user.role,
                        "gates": user.get_gates(), "must_change": bool(user.must_change)}})

@app.post("/api/public/parent-register")
def public_parent_register():
    """تسجيل ذاتي لولي الأمر عبر الرابط العمومي — يُدخل الرقم الوطني للتلميذ
    وكلمة مرور من اختياره، فيُنشأ له حساب بانتظار تفعيل المؤسسة (نفس أسلوب
    فضاء الأولياء في تطبيق الوزارة)."""
    data = request.get_json() or {}
    national_id = (data.get("national_id") or "").strip()
    password = data.get("password") or ""
    full_name = (data.get("full_name") or "").strip()
    phone = (data.get("phone") or "").strip()
    relation = (data.get("relation") or "ولي").strip()
    email = (data.get("email") or "").strip().lower()
    if not national_id or not password or not full_name:
        return err("أدخل الرقم الوطني للتلميذ واسمك الكامل وكلمة المرور")
    import re as _rem
    if not _rem.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        return err("البريد الإلكتروني إلزامي وبصيغة صحيحة — تُرسَل إليه إشعارات الغياب والاستدعاءات")
    if len(password) < 6:
        return err("كلمة المرور يجب أن تكون 6 خانات على الأقل")
    db = Session()
    try:
        s = db.query(Student).filter(Student.national_id == national_id, Student.is_active == True).first()
        if not s:
            return err("لم يُعثر على تلميذ بهذا الرقم الوطني — تأكد من الرقم أو راجع إدارة المؤسسة")
        existing = db.query(User).filter(User.username == national_id).first()
        if existing:
            if existing.is_active:
                return err("يوجد حساب مُفعَّل بهذا الرقم مسبقاً — استعمل صفحة الدخول العادية")
            return err("سبق إرسال طلب تسجيل بهذا الرقم، بانتظار تفعيل المؤسسة")
        from app.core.config import ROLE_GATES
        u = User(username=national_id, password_hash=hash_pw(password),
                 full_name=full_name, phone=phone, email=email, role="parent",
                 gates=json.dumps(ROLE_GATES.get("parent", [])), is_active=False)
        if not (s.guardian_email or "").strip():
            s.guardian_email = email          # يُعتمد كبريد الإشعارات إن لم يكن مسجَّلاً
        db.add(u); db.commit(); db.refresh(u)
        db.add(ParentLink(parent_id=u.id, student_id=s.id, relation=relation))
        db.commit()
        write_audit(None, "PARENT_SELF_REGISTER", "user", u.id, new=f"student:{s.id}")
        return ok({"student_name": s.full_name},
                  "تم إرسال طلبك بنجاح. سيُفعَّل حسابك من طرف إدارة المؤسسة قريباً — يمكنك المحاولة بالدخول لاحقاً بنفس البيانات.",
                  201)
    finally:
        db.close()


@app.put("/api/auth/password")
@login_required
def change_password():
    """تغيير كلمة المرور الذاتي (كان معرَّفاً بلا مسار فلم يكن يعمل). يُلغي علامة «يجب التغيير»."""
    data = request.get_json() or {}
    newp = data.get("new_password") or ""
    if len(newp) < 6:
        return err("كلمة المرور الجديدة 6 خانات على الأقل")
    if newp.lower() in ("donia@2026", "parent@2026", "123456", "password", "admin"):
        return err("كلمة مرور ضعيفة — اختر غيرها")
    db = Session()
    try:
        u = db.query(User).filter(User.id == g.user_id).first()
        if not check_pw(data.get("old_password", ""), u.password_hash):
            return err("كلمة المرور الحالية غير صحيحة")
        if newp == data.get("old_password", ""):
            return err("اختر كلمة مرور مختلفة عن الحالية")
        u.password_hash = hash_pw(newp)
        u.must_change = False
        db.commit()
        write_audit(g.user_id, "CHANGE_PASSWORD")
        return ok(msg="تم تغيير كلمة المرور بنجاح")
    finally:
        db.close()

@app.get("/api/auth/me")
@login_required
def get_me():
    return ok({"id": g.user.id, "username": g.user.username,
               "full_name": g.user.full_name, "role": g.user.role,
               "gates": g.user.get_gates(), "must_change": bool(g.user.must_change)})

# ════════════════ STUDENTS ════════════════
@app.get("/api/students")
@gate_required("G01")
def list_students():
    db = Session()
    try:
        q = db.query(Student).filter(Student.is_active == True)
        if div_id := request.args.get("division_id"):
            q = q.filter(Student.division_id == int(div_id))
        if s := request.args.get("search"):
            q = q.filter(Student.last_name_ar.contains(s)|Student.first_name_ar.contains(s)|Student.national_id.contains(s))
        return ok([_stu(s) for s in q.order_by(Student.last_name_ar).all()])
    finally:
        db.close()

@app.get("/api/students/<int:sid>")
@gate_required("G01")
def get_student(sid):
    db = Session()
    try:
        s = db.query(Student).filter(Student.id == sid).first()
        return ok(_stu_full(s)) if s else err("غير موجود", 404)
    finally:
        db.close()

def _parse_date_field(v):
    """يحوّل نص التاريخ (YYYY-MM-DD أو DD/MM/YYYY) إلى كائن date، أو يعيده كما هو إن كان date بالفعل"""
    if v is None or v == "" or isinstance(v, date):
        return v
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%Y/%m/%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(str(v), fmt).date()
        except ValueError:
            continue
    return None

_DATE_FIELDS = {"birth_date", "expelled_date", "entry_date"}

@app.post("/api/students")
@gate_required("G01")
def create_student():
    data = request.get_json() or {}
    db = Session()
    try:
        if data.get("national_id"):
            if db.query(Student).filter(Student.national_id == data["national_id"]).first():
                return err(f"الرقم الوطني {data['national_id']} موجود مسبقاً")
        if data.get("registration_num"):
            if db.query(Student).filter(Student.registration_num == data["registration_num"]).first():
                return err(f"رقم التسجيل {data['registration_num']} مستخدم مسبقاً")
        clean = {k: (_parse_date_field(v) if k in _DATE_FIELDS else v)
                 for k, v in data.items() if hasattr(Student, k) and k != "id"}
        s = Student(**clean)
        db.add(s); db.commit(); db.refresh(s)
        write_audit(g.user_id, "CREATE_STUDENT", "student", s.id)
        return ok({"id": s.id}, "تم إضافة التلميذ بنجاح", 201)
    except Exception as ex:
        db.rollback()
        return err(f"خطأ في إضافة التلميذ: {str(ex)}")
    finally:
        db.close()

@app.put("/api/students/<int:sid>")
@login_required
def update_student(sid):
    data = request.get_json() or {}
    db = Session()
    try:
        s = db.query(Student).filter(Student.id == sid).first()
        if not s: return err("غير موجود", 404)
        for k, v in data.items():
            if hasattr(s, k) and k not in ("id","created_at"):
                setattr(s, k, _parse_date_field(v) if k in _DATE_FIELDS else v)
        db.commit()
        return ok(msg="تم التحديث")
    except Exception as ex:
        db.rollback()
        return err(f"خطأ في التحديث: {str(ex)}")
    finally:
        db.close()

@app.post("/api/students/import-preview")
@login_required
def import_students_preview():
    """معاينة تشخيصية بلا حفظ: تُظهر الأعمدة التي اكتشفها المحلل فعلياً من الملف
    وأول 3 أسطر — لمعرفة سبب استيراد 0 تلميذ بدل التخمين."""
    from app.utils.xls_parser import parse_ministry_xls_debug
    f = request.files.get("file")
    if not f:
        return err("لم يتم رفع ملف")
    content = f.read()
    if not content:
        return err("الملف فارغ")
    info = parse_ministry_xls_debug(content)
    return ok(info)


@app.post("/api/students/import-xls")
@login_required
def import_xls():
    from app.utils.xls_parser import parse_ministry_xls, is_frameset
    f = request.files.get("file")
    if not f:
        return err("لم يتم رفع ملف")
    try:
        content = f.read()
        if not content:
            return err("الملف فارغ")
    except Exception as e:
        return err(f"فشل قراءة الملف: {str(e)}")

    # Check if it's a frameset (Eleve.xls main file - no data inside)
    if is_frameset(content):
        return jsonify({
            "success": False,
            "is_frameset": True,
            "error": "ملف Eleve.xls لا يحتوي بيانات مباشرة",
            "solution": (
                "على جهازك، ابحث عن مجلد Eleve.files بجانب ملف Eleve.xls، "
                "افتحه وارفع ملف sheet001.htm"
            ),
            "steps": [
                "1. اذهب للمجلد الذي فيه Eleve.xls",
                "2. ستجد مجلداً باسم Eleve.files",
                "3. افتح المجلد",
                "4. ارفع ملف sheet001.htm بدلاً من Eleve.xls"
            ]
        }), 400

    rows = parse_ministry_xls(content)
    if not rows:
        return err("لم يتم العثور على بيانات — جرّب رفع sheet001.htm من مجلد Eleve.files")

    div_id = request.form.get("division_id")
    db = Session()
    imported = skipped = errors = 0
    try:
        # تجهيز خريطة الأقسام (نُنشئ تلقائياً كل قسم مذكور في الملف تحت مفتاح _class)
        div_cache = {d.name: d.id for d in db.query(Division).all()}

        def get_or_create_division(name):
            if name in div_cache:
                return div_cache[name]
            parts = name.split()
            lvl = int(parts[0]) if parts and parts[0].isdigit() else 1
            sec = parts[-1] if parts else "1"
            d = Division(name=name, level=lvl, section=sec)
            db.add(d); db.flush()
            div_cache[name] = d.id
            return d.id

        for row in rows:
            try:
                if not row.get("last_name_ar"):
                    continue
                if row.get("national_id"):
                    if db.query(Student).filter(
                        Student.national_id == row["national_id"]
                    ).first():
                        skipped += 1
                        continue
                if row.get("registration_num"):
                    if db.query(Student).filter(
                        Student.registration_num == row["registration_num"]
                    ).first():
                        row["registration_num"] = None  # تفادي تعارض التفرّد بدل رفض السطر كاملاً
                cls = row.pop("_class", None)
                if div_id:
                    row["division_id"] = int(div_id)
                elif cls:
                    row["division_id"] = get_or_create_division(cls)
                db.add(Student(**{
                    k: v for k, v in row.items()
                    if hasattr(Student, k) and k != "id"
                }))
                db.flush()
                imported += 1
            except Exception as ex:
                db.rollback()
                errors += 1
                continue
        db.commit()
        write_audit(g.user_id, "IMPORT_STUDENTS",
                    new=f"imported:{imported},skipped:{skipped}")
        result = {
            "imported": imported,
            "skipped": skipped,
            "errors": errors,
            "total_in_file": len(rows),
        }
        if imported == 0 and len(rows) > 0:
            if skipped > 0 and skipped >= len(rows) - errors:
                result["warning"] = (
                    f"كل تلاميذ هذا الملف ({skipped} من {len(rows)}) موجودون مسبقاً في القاعدة "
                    "(بنفس الرقم الوطني) — لا يوجد تلميذ جديد ليُستورد. هذا ليس عطلاً؛ على الأرجح "
                    "استوردتم هذا الملف من قبل بنجاح. تحققوا من صفحة «قائمة التلاميذ»."
                )
            else:
                result["warning"] = (
                    f"تم العثور على {len(rows)} سطر في الملف لكن لم يُستورد أي تلميذ جديد. "
                    "غالباً لم يتعرف المحلل على عمود 'اللقب' أو 'اللقب والاسم' بشكل صحيح. "
                    "استعمل زر «معاينة قبل الاستيراد» لرؤية الأعمدة التي اكتشفها النظام فعلياً."
                )
        return ok(result)
    finally:
        db.close()


@app.post("/api/students/import-addresses")
@login_required
def import_addresses():
    """استيراد ملف 'حالة أول أكتوبر' لإثراء بيانات التلاميذ الموجودين
    (اسم الأب + العنوان) بمطابقة الاسم + تاريخ الميلاد، دون إنشاء تلاميذ جدد
    ودون التأثير على رقم التسجيل أو الرقم الوطني الأصليين."""
    from app.utils.xls_parser import parse_ministry_xls
    f = request.files.get("file")
    if not f:
        return err("لم يتم رفع ملف")
    content = f.read()
    if not content:
        return err("الملف فارغ")
    rows = parse_ministry_xls(content)
    if not rows:
        return err("لم يتم العثور على بيانات في الملف")

    db = Session()
    updated = not_found = skipped = 0
    try:
        for row in rows:
            if not row.get("last_name_ar") or not row.get("first_name_ar"):
                skipped += 1
                continue
            q = db.query(Student).filter(
                Student.last_name_ar == row["last_name_ar"],
                Student.first_name_ar == row["first_name_ar"],
            )
            if row.get("birth_date"):
                q = q.filter(Student.birth_date == row["birth_date"])
            s = q.first()
            if not s:
                not_found += 1
                continue
            changed = False
            if row.get("father_name") and not s.father_name:
                s.father_name = row["father_name"]; changed = True
            if row.get("guardian_address") and not s.guardian_address:
                s.guardian_address = row["guardian_address"]; changed = True
            if changed:
                updated += 1
        db.commit()
        write_audit(g.user_id, "IMPORT_ADDRESSES",
                    new=f"updated:{updated},not_found:{not_found}")
        return ok({
            "updated": updated, "not_found": not_found, "skipped": skipped,
            "total_in_file": len(rows),
        })
    finally:
        db.close()

@app.get("/api/students/csv-template")
@login_required
def download_csv_template():
    """Download CSV template for manual student entry."""
    from app.utils.xls_parser import generate_csv_template
    from flask import Response
    csv_content = generate_csv_template()
    return Response(
        csv_content,
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=students_template.csv"}
    )


@app.post("/api/staff/import-xls")
@login_required
def import_staff_xls():
    """Import staff from القائمة الاسمية للمستخدمين"""
    from app.utils.xls_parser import parse_staff_xls
    from app.core.config import ROLE_GATES

    f = request.files.get("file")
    if not f: return err("لم يتم رفع ملف")
    try:
        content = f.read()
        if not content:
            return err("الملف فارغ")
    except Exception as e:
        return err(f"فشل قراءة الملف: {str(e)}")

    staff_rows = parse_staff_xls(content)
    if not staff_rows:
        return err("لم يتم العثور على بيانات — تأكد أنه ملف القائمة الاسمية للمستخدمين")

    db = Session()
    imported = skipped = errors = 0
    results = []

    try:
        for s in staff_rows:
            try:
                # لا تكرار: نفس الاسم الكامل (ونفس تاريخ الميلاد إن توفر) موجود مسبقاً → تخطٍّ
                dup_q = db.query(User).filter(User.full_name == s["full_name"])
                if s.get("birth_date"):
                    dup_q = dup_q.filter((User.birth_date == s["birth_date"]) | (User.birth_date.is_(None)))
                if dup_q.first():
                    skipped += 1
                    continue
                username = s["username"]
                # Make username unique if exists
                base_username = username
                counter = 1
                while db.query(User).filter(User.username == username).first():
                    username = f"{base_username}{counter}"
                    counter += 1

                role = s.get("role", "teacher")
                gates = ROLE_GATES.get(role, ["G18"])
                from app.services import accounts as _AC
                _pw_imp = _AC.gen_password()

                user = User(
                    username=username,
                    full_name=s["full_name"],
                    password_hash=hash_pw(_pw_imp),
                    must_change=True,
                    role=role,
                    gates=json.dumps(gates),
                    is_active=True,
                    created_by=g.user_id,
                    birth_date=s.get("birth_date") or None,
                    position_title=" ".join(str(s.get("rank", "")).split())[:100],
                )
                db.add(user)
                db.flush()

                # Add to Teacher table if teacher role
                from app.core.database import Teacher
                if role == "teacher":
                    teacher = Teacher(
                        user_id=user.id,
                        first_name=s.get("first_name",""),
                        last_name=s.get("last_name",""),
                        specialty=" ".join(str(s.get("subject", "")).split()),
                        grade_rank=" ".join(str(s.get("rank", "")).split()),
                        is_active=True,
                    )
                    db.add(teacher)

                imported += 1
                results.append({
                    "name": s["full_name"],
                    "role": role,
                    "username": username,
                    "password": _pw_imp,
                    "full_name": s["full_name"],
                    "role_label": _AC.ROLE_AR.get(role, role),
                    "subject": s.get("subject",""),
                })
            except Exception as ex:
                errors += 1
                continue

        db.commit()
        write_audit(g.user_id, "IMPORT_STAFF", new=f"imported:{imported}")
        return ok({
            "imported": imported,
            "skipped": skipped,
            "errors": errors,
            "total_in_file": len(staff_rows),
            "staff": [{k: v for k, v in r.items() if k != "password"} for r in results[:10]],  # أول 10 للعرض بلا كلمات مرور
            "accounts": results,    # كل الحسابات الجديدة بكلمات مرورها (تُعاد مرة واحدة لطباعة بطاقات الدخول)
        })
    finally:
        db.close()


@app.get("/api/staff")
@gate_required("G08")
def list_staff():
    """List all staff (users except students/parents/workers)."""
    db = Session()
    try:
        staff_roles = ["director","nazir","counselor","supervisor_general","teacher","admin","accountant","supervisor"]
        users = db.query(User).filter(
            User.is_active == True,
            User.role.in_(staff_roles)
        ).all()
        return ok([{
            "id": u.id, "username": u.username,
            "full_name": u.full_name, "role": u.role,
            "gates_count": len(u.get_gates()), "photo_path": u.photo_path,
            "birth_date": str(u.birth_date) if u.birth_date else "",
            "degree": u.degree, "employment_status": u.employment_status,
            "first_appointment_date": str(u.first_appointment_date) if u.first_appointment_date else "",
            "hire_date": str(u.hire_date) if u.hire_date else "",
            "position_title": u.position_title, "hr_notes": u.hr_notes,
        } for u in users])
    finally:
        db.close()

@app.get("/api/teachers")
@gate_required("G09")
def list_teachers():
    """قائمة الأساتذة (جدول Teacher وليس User) — تُستعمل في قوائم اختيار
    الأستاذ عند بناء استعمال الزمن ولحساب حوصلة الساعات."""
    db = Session()
    try:
        teachers = db.query(Teacher).filter(Teacher.is_active == True).order_by(Teacher.last_name).all()
        return ok([{"id": t.id, "name": f"{t.last_name} {t.first_name}", "specialty": t.specialty,
                   "weekly_hours": t.weekly_hours} for t in teachers])
    finally:
        db.close()


def _sort_divs(divs):
    """ترتيب طبيعي للأقسام: المستوى ثم رقم الشعبة عددياً (2 قبل 10)."""
    def k(d):
        sec = str(d.section or "").strip()
        return (d.level or 0, 0, int(sec), "") if sec.isdigit() else (d.level or 0, 1, 0, sec)
    return sorted(divs, key=k)

# ════════════════ DIVISIONS ════════════════
def _div_counts(db):
    """إحصاء كل قسم من قاعدة البيانات مباشرة (لا يعتمد على الواجهة):
    ذكور/إناث/مجموع، معيدون ذكور/إناث/مجموع، جدد، وتوزيع الصفة."""
    out = {}
    for s in db.query(Student).filter(Student.is_active == True, Student.division_id.isnot(None)).all():
        c = out.setdefault(s.division_id, dict(m=0, f=0, rep_m=0, rep_f=0, ext=0, half=0, inn=0))
        sex = "m" if s.gender == "ذكر" else "f"
        c[sex] += 1
        if s.is_repeating:
            c["rep_" + sex] += 1
        if s.status == "داخلي": c["inn"] += 1
        elif s.status == "نصف داخلي": c["half"] += 1
        else: c["ext"] += 1
    for c in out.values():
        c["total"] = c["m"] + c["f"]
        c["rep"] = c["rep_m"] + c["rep_f"]
        c["new_m"] = c["m"] - c["rep_m"]; c["new_f"] = c["f"] - c["rep_f"]
        c["new"] = c["total"] - c["rep"]
    return out

_EMPTY_CNT = dict(m=0, f=0, rep_m=0, rep_f=0, ext=0, half=0, inn=0, total=0, rep=0, new_m=0, new_f=0, new=0)

@app.get("/api/divisions")
@gate_any("G17","G01","G02","G04","G05","G07","G09","G12","G13","G14","G25","G26","G27")
def list_divisions():
    db = Session()
    try:
        divs = _sort_divs(db.query(Division).filter(Division.is_active==True).all())
        cnt = _div_counts(db)
        return ok([{"id":d.id,"name":d.name,"level":d.level,"section":d.section,"room":d.room,
                    **cnt.get(d.id, _EMPTY_CNT)} for d in divs])
    finally:
        db.close()

@app.get("/api/divisions/<int:did>/students")
@gate_required("G17")
def division_students(did):
    """قائمة تلاميذ القسم لتحديد المعيدين."""
    db = Session()
    try:
        studs = db.query(Student).filter(Student.division_id == did, Student.is_active == True)\
                  .order_by(Student.last_name_ar, Student.first_name_ar).all()
        return ok([{"id": s.id, "name": f"{s.last_name_ar} {s.first_name_ar}", "gender": s.gender,
                    "status": s.status, "is_repeating": bool(s.is_repeating),
                    "birth_date": str(s.birth_date) if s.birth_date else ""} for s in studs])
    finally:
        db.close()

@app.put("/api/divisions/<int:did>/repeaters")
@gate_required("G17")
def set_division_repeaters(did):
    """يضبط المعيدين في قسم دفعة واحدة: {repeater_ids:[...]} — الباقي يصبح جديداً."""
    ids = {int(i) for i in ((request.get_json() or {}).get("repeater_ids") or [])}
    db = Session()
    try:
        n = 0
        for s in db.query(Student).filter(Student.division_id == did, Student.is_active == True).all():
            flag = s.id in ids
            if bool(s.is_repeating) != flag:
                s.is_repeating = flag; n += 1
        db.commit()
        write_audit(g.user_id, "SET_REPEATERS", "division", did)
        return ok({"changed": n, "repeaters": len(ids)}, "تم حفظ المعيدين")
    except Exception as ex:
        db.rollback(); return err(f"تعذّر الحفظ: {ex}")
    finally:
        db.close()

@app.post("/api/divisions")
@gate_required("G17")
def create_division():
    data = request.get_json() or {}
    db = Session()
    try:
        d = Division(**{k:v for k,v in data.items() if hasattr(Division,k) and k!="id"})
        db.add(d); db.commit(); db.refresh(d)
        return ok({"id":d.id},"تم إنشاء القسم",201)
    finally:
        db.close()

# ════════════════ الجداول الزمنية (استعمال الزمن) — التقرير العام للتسيير ════════════════
# محرك جدولة كامل: محلات (رووم) + خانات استعمال الزمن (قسم/أستاذ/مادة/محل/يوم/حصة)
# هذا هو الأساس الحقيقي لوثائق التقرير العام للتسيير الرسمي (حسب المنشور الوزاري
# 177/93): مواقيت الأقسام، مواقيت الأساتذة، مواقيت المحلات (عادية/متخصصة)،
# خدمات الأساتذة، وحوصلة الساعات الإضافية والفائضة — بدل التقرير الإحصائي البسيط
# الذي بُني في جولة سابقة (والذي يبقى متاحاً بشكل منفصل كلوحة مؤشرات عامة).

def _period_labels(si):
    """يبني قائمة رموز الحصص (ص1..صN، م1..مN) من إعدادات المؤسسة — نفس منطق
    buildPeriodOptions في الواجهة، لضمان تطابق الحصص بين الحضور والجدولة."""
    labels = []
    for i in range(1, (si.periods_morning or 4) + 1):
        labels.append(f"ص{i}")
    for i in range(1, (si.periods_evening or 4) + 1):
        labels.append(f"م{i}")
    return labels

# ── محلات (Rooms) ──
@app.get("/api/rooms")
@gate_required("G09")
def list_rooms():
    db = Session()
    try:
        rooms = db.query(Room).filter(Room.is_active == True).order_by(Room.room_type, Room.name).all()
        return ok([{"id": r.id, "name": r.name, "room_type": r.room_type, "capacity": r.capacity} for r in rooms])
    finally:
        db.close()

@app.post("/api/rooms")
@gate_required("G09")
def create_room():
    data = request.get_json() or {}
    if not (data.get("name") or "").strip():
        return err("اسم المحل مطلوب")
    db = Session()
    try:
        r = Room(name=data["name"].strip(), room_type=data.get("room_type", "عادي"),
                  capacity=int(data.get("capacity") or 0))
        db.add(r); db.commit(); db.refresh(r)
        write_audit(g.user_id, "CREATE_ROOM", "room", r.id, new=r.name)
        return ok({"id": r.id}, "تم إنشاء المحل", 201)
    finally:
        db.close()

@app.put("/api/rooms/<int:rid>")
@gate_required("G09")
def update_room(rid):
    data = request.get_json() or {}
    db = Session()
    try:
        r = db.query(Room).filter(Room.id == rid).first()
        if not r: return err("المحل غير موجود", 404)
        for f in ("name", "room_type"):
            if f in data: setattr(r, f, data[f])
        if "capacity" in data:
            try: r.capacity = int(data["capacity"])
            except (TypeError, ValueError): pass
        db.commit()
        return ok(msg="تم تحديث المحل")
    finally:
        db.close()

@app.delete("/api/rooms/<int:rid>")
@gate_required("G09")
def delete_room(rid):
    db = Session()
    try:
        r = db.query(Room).filter(Room.id == rid).first()
        if not r: return err("المحل غير موجود", 404)
        r.is_active = False
        db.commit()
        write_audit(g.user_id, "DELETE_ROOM", "room", rid, new=r.name)
        return ok(msg="تم حذف المحل")
    finally:
        db.close()

# ── استعمال الزمن (Schedule) ──
def _schedule_entry_dict(e, db):
    div = db.query(Division).filter(Division.id == e.division_id).first()
    t = db.query(Teacher).filter(Teacher.id == e.teacher_id).first() if e.teacher_id else None
    subj = db.query(Subject).filter(Subject.id == e.subject_id).first() if e.subject_id else None
    room = db.query(Room).filter(Room.id == e.room_id).first() if e.room_id else None
    return {"id": e.id, "division_id": e.division_id, "division_name": div.name if div else "",
            "teacher_id": e.teacher_id, "teacher_name": f"{t.last_name} {t.first_name}" if t else "",
            "subject_id": e.subject_id, "subject_name": subj.name_ar if subj else "",
            "room_id": e.room_id, "room_name": room.name if room else "",
            "day_of_week": e.day_of_week, "day_name": DAYS_OF_WEEK[e.day_of_week] if 0 <= e.day_of_week < 6 else "",
            "period": e.period, "label": getattr(e, "label", "") or "",
            "co_teacher_id": getattr(e, "co_teacher_id", None)}

@app.get("/api/schedule/grid")
@gate_required("G09")
def schedule_grid():
    """يُعيد شبكة استعمال الزمن الكاملة لأسبوع دراسي واحد، مُصفّاة حسب قسم
    أو أستاذ أو محل (حسب ما يُمرَّر من معاملات) — تُستعمل لعرض الشبكة في
    واجهة الإدارة ولبناء وثائق الطباعة الرسمية الثلاث (أقسام/أساتذة/محلات)."""
    db = Session()
    try:
        si = SI(db)
        q = db.query(ScheduleEntry).filter(ScheduleEntry.academic_year == si.academic_year)
        division_id = request.args.get("division_id")
        teacher_id = request.args.get("teacher_id")
        room_id = request.args.get("room_id")
        if division_id: q = q.filter(ScheduleEntry.division_id == int(division_id))
        if teacher_id: q = q.filter(_tq(int(teacher_id)))
        if room_id: q = q.filter(ScheduleEntry.room_id == int(room_id))
        entries = q.all()
        return ok({"days": DAYS_OF_WEEK, "periods": _period_labels(si),
                   "entries": [_schedule_entry_dict(e, db) for e in entries]})
    finally:
        db.close()

@app.post("/api/schedule")
@gate_required("G09")
def create_schedule_entry():
    """يُضيف خانة واحدة في استعمال الزمن، مع رفض أي تعارض حقيقي: نفس القسم
    مشغول في نفس الحصة، أو نفس الأستاذ مُدرِّس في مكانين معاً، أو نفس المحل
    مشغول بقسم آخر في نفس التوقيت — تعارضات لا يمكن أن تحدث فعلياً في مؤسسة حقيقية."""
    data = request.get_json() or {}
    div_id = data.get("division_id")
    day = data.get("day_of_week")
    period = (data.get("period") or "").strip()
    teacher_id = data.get("teacher_id") or None
    room_id = data.get("room_id") or None
    if div_id is None or day is None or not period:
        return err("القسم واليوم والحصة مطلوبون")
    try:
        day = int(day)
        if day < 0 or day > 5: raise ValueError()
    except (TypeError, ValueError):
        return err("يوم غير صالح")
    db = Session()
    try:
        si = SI(db)
        year = si.academic_year
        if db.query(ScheduleEntry).filter(ScheduleEntry.division_id == div_id, ScheduleEntry.day_of_week == day,
                                          ScheduleEntry.period == period, ScheduleEntry.academic_year == year).first():
            return err("القسم مشغول بالفعل في هذه الحصة — احذف الخانة الحالية أولاً إن أردت تغييرها")
        if teacher_id and db.query(ScheduleEntry).filter(ScheduleEntry.teacher_id == teacher_id, ScheduleEntry.day_of_week == day,
                                                          ScheduleEntry.period == period, ScheduleEntry.academic_year == year).first():
            return err("الأستاذ مُدرِّس بالفعل لقسم آخر في نفس هذه الحصة")
        if room_id and db.query(ScheduleEntry).filter(ScheduleEntry.room_id == room_id, ScheduleEntry.day_of_week == day,
                                                       ScheduleEntry.period == period, ScheduleEntry.academic_year == year).first():
            return err("المحل مشغول بقسم آخر في نفس هذه الحصة")
        e = ScheduleEntry(division_id=div_id, teacher_id=teacher_id, subject_id=data.get("subject_id") or None,
                          room_id=room_id, day_of_week=day, period=period, academic_year=year)
        db.add(e); db.commit(); db.refresh(e)
        return ok({"id": e.id}, "تم إضافة الحصة إلى استعمال الزمن", 201)
    finally:
        db.close()

@app.delete("/api/schedule/<int:eid>")
@gate_required("G09")
def delete_schedule_entry(eid):
    db = Session()
    try:
        e = db.query(ScheduleEntry).filter(ScheduleEntry.id == eid).first()
        if not e: return err("غير موجود", 404)
        db.delete(e); db.commit()
        return ok(msg="تم حذف الحصة من استعمال الزمن")
    finally:
        db.close()

def _tq(tid):
    from sqlalchemy import or_
    return or_(ScheduleEntry.teacher_id == tid, ScheduleEntry.co_teacher_id == tid)

def _tt_candidates(db):
    return [(t.id, f"{t.last_name} {t.first_name}".strip()) for t in db.query(Teacher).filter(Teacher.is_active == True).all()]

@app.post("/api/schedule/import-xlsx")
@gate_required("G09")
def import_schedule_xlsx():
    """استيراد استعمال الزمن من ملف xlsx (OSCTIME/aSc Timetables أو شبكة FET للأساتذة).
    mode=preview: يحلّل ويُطابق الأقسام والأساتذة والمواد ولا يكتب شيئاً.
    mode=commit : يبني استعمال الزمن مباشرة للأقسام (وبالتالي لتلاميذها)؛
    options = {replace, create_missing, teacher_map{code: id|'new'|'skip'},
               class_map{اسم القسم في الملف: id|'new'|'skip'}, subject_map{اسم في الملف: مادة النظام}}."""
    from app.utils import timetable_import as TI
    f = request.files.get("file")
    if not f: return err("لم يتم رفع ملف")
    content = f.read()
    if not content: return err("الملف فارغ")
    mode = request.form.get("mode", "preview")
    try:
        opts = json.loads(request.form.get("options") or "{}")
    except ValueError:
        opts = {}
    db = Session()
    try:
        si = SI(db)
        year = si.academic_year
        try:
            parsed = TI.parse_timetable_xlsx(content, si.periods_morning or 4)
        except Exception as ex:
            return err(f"تعذّرت قراءة الملف: {ex}")
        valid_periods = set(_period_labels(si))
        cands = _tt_candidates(db)
        lessons = {}
        for e in parsed["entries"]:
            for c in e["teachers"]:
                lessons[c] = lessons.get(c, 0) + 1
        for a_ in parsed.get("activities", []):
            lessons[a_["teacher"]] = lessons.get(a_["teacher"], 0) + 0
        tinfo = []
        for code, info in parsed["teachers"].items():
            if code not in lessons:
                continue
            mid, q = TI.match_teacher(info.get("name", ""), cands)
            sug = None if mid else TI.suggest_teacher(info.get("name", ""), cands)
            tinfo.append({"code": code, "name": info.get("name", ""), "short": info.get("short", ""),
                          "subject_hint": info.get("subject_hint") or "", "lessons": lessons.get(code, 0),
                          "matched_id": mid, "quality": q, "suggested_id": sug})
        # الأقسام: مطابقة (مستوى، شعبة) مع أقسام النظام
        divs_db = db.query(Division).filter(Division.academic_year == year).all()
        by_key = {(d.level, str(d.section)): d for d in divs_db}
        class_counts = {}
        for e in parsed["entries"]:
            class_counts[e["class"]] = class_counts.get(e["class"], 0) + 1
        cinfo = []
        for cname in sorted(class_counts):
            lv, sec = TI.parse_class(cname)
            d = by_key.get((lv, sec))
            cinfo.append({"name": cname, "level": lv, "section": sec, "lessons": class_counts[cname],
                          "matched_id": d.id if d else None, "matched_name": d.name if d else None,
                          "students": db.query(Student).filter(Student.division_id == d.id).count() if d else 0})
        subj_names = sorted({sb.name_ar for sb in db.query(Subject).all()})
        unmapped_subj = sorted({e["subject_raw"] for e in parsed["entries"]
                                if not TI.map_subject(e["subject_raw"])})
        out_periods = sorted({e["period"] for e in parsed["entries"] if e["period"] not in valid_periods})
        if mode != "commit":
            return ok({"format": parsed["format"], "entries": len(parsed["entries"]),
                       "skipped_no_class": parsed["skipped_no_class"],
                       "activities": len(parsed.get("activities", [])),
                       "classes": cinfo, "teachers": tinfo, "unmapped_subjects": unmapped_subj,
                       "periods_outside_settings": out_periods,
                       "candidates": [{"id": i, "name": n} for i, n in cands],
                       "divisions": [{"id": d.id, "name": d.name} for d in _sort_divs(divs_db)],
                       "subjects": subj_names})
        # ── commit ──
        create_missing = bool(opts.get("create_missing", True))
        tm = opts.get("teacher_map") or {}
        cm_ = opts.get("class_map") or {}
        sm = opts.get("subject_map") or {}
        spec_by_id = {t.id: (t.specialty or "") for t in db.query(Teacher).all()}
        resolved, created_t = {}, 0
        for t in tinfo:
            default = t["matched_id"] if t["matched_id"] else ("new" if (create_missing and t["name"]) else "skip")
            sel = tm.get(t["code"], default)
            if sel in ("skip", None, ""):
                continue
            if sel == "new":
                parts = t["name"].split()
                if not parts: continue
                nt = Teacher(last_name=parts[0], first_name=" ".join(parts[1:]),
                             specialty=TI.map_subject(t["subject_hint"]) or "", is_active=True)
                db.add(nt); db.flush()
                spec_by_id[nt.id] = nt.specialty
                resolved[t["code"]] = nt.id; created_t += 1
            else:
                resolved[t["code"]] = int(sel)
        if opts.get("replace"):
            db.query(ScheduleEntry).filter(ScheduleEntry.academic_year == year).delete()
            db.query(TeacherActivity).filter(TeacherActivity.academic_year == year).delete()
            db.flush()
        divs, subs, rooms = {}, {}, {}
        def get_div(name):
            if name in divs:
                return divs[name]
            sel = cm_.get(name)
            lv, sec = TI.parse_class(name)
            d = None
            if sel == "skip":
                divs[name] = None; return None
            if sel and sel != "new":
                d = db.query(Division).filter(Division.id == int(sel)).first()
            if d is None:
                d = by_key.get((lv, sec)) if sel != "new" else None
            if d is None:
                d = Division(name=TI.division_name(lv, sec), level=lv, section=sec, academic_year=year, is_active=True)
                db.add(d); db.flush()
                by_key[(lv, sec)] = d
            divs[name] = d
            return d
        def get_sub(name):
            if not name: return None
            if name not in subs:
                sb = db.query(Subject).filter(Subject.name_ar == name).first()
                if not sb:
                    sb = Subject(name_ar=name, coefficient=1)
                    db.add(sb); db.flush()
                subs[name] = sb
            return subs[name].id
        def get_room(name):
            if not name: return None
            if name not in rooms:
                r = db.query(Room).filter(Room.name == name).first()
                if not r:
                    r = Room(name=name[:50]); db.add(r); db.flush()
                rooms[name] = r
            return rooms[name].id
        added = dup = skipped_t = skipped_c = 0
        busy_t = {}
        seen = {(e.division_id, e.day_of_week, e.period) for e in
                db.query(ScheduleEntry).filter(ScheduleEntry.academic_year == year).all()}
        teacher_conflicts = 0
        for e in parsed["entries"]:
            if e["period"] not in valid_periods:
                continue
            d = get_div(e["class"])
            if d is None:
                skipped_c += 1; continue
            key = (d.id, e["day"], e["period"])
            if key in seen:
                dup += 1; continue
            tids = [resolved[c] for c in e["teachers"] if c in resolved]
            if e["teachers"] and not tids:
                skipped_t += 1
            raw = e["subject_raw"]
            subj_name = sm[raw] if sm.get(raw) else TI.map_subject(raw)
            primary = tids[0] if tids else None
            if tids:
                for tid in tids:      # الأستاذ صاحب التخصص المطابق للمادة هو الأساسي
                    if subj_name and TI.map_subject(spec_by_id.get(tid, "")) == subj_name:
                        primary = tid; break
                if not subj_name:
                    subj_name = TI.map_subject(spec_by_id.get(primary, ""))
            co = next((t for t in tids if t != primary), None)
            for tid in tids:
                kk = (tid, e["day"], e["period"])
                if kk in busy_t: teacher_conflicts += 1
                busy_t[kk] = 1
            db.add(ScheduleEntry(division_id=d.id, teacher_id=primary, co_teacher_id=co,
                                 subject_id=get_sub(subj_name), room_id=get_room(e["room"]),
                                 day_of_week=e["day"], period=e["period"], academic_year=year,
                                 label=TI.clean_label(raw)))
            seen.add(key); added += 1
        # أنشطة بلا قسم (استقبال الأولياء، تنسيق، صيانة...) تظهر في مواقيت الأستاذ
        act_added = 0
        act_seen = {(a_.teacher_id, a_.day_of_week, a_.period) for a_ in
                    db.query(TeacherActivity).filter(TeacherActivity.academic_year == year).all()}
        for a_ in parsed.get("activities", []):
            tid = resolved.get(a_["teacher"])
            if not tid or a_["period"] not in valid_periods:
                continue
            k = (tid, a_["day"], a_["period"])
            if k in act_seen: continue
            act_seen.add(k)
            db.add(TeacherActivity(teacher_id=tid, day_of_week=a_["day"], period=a_["period"],
                                   label=(a_["label"] or "")[:100], academic_year=year))
            act_added += 1
        # تخصص الأستاذ (للعنوان «المادة:» في مواقيته) يُستنتج من أكثر مادة يدرّسها إن كان فارغاً
        from collections import Counter as _C
        cnt = {}
        for en in db.query(ScheduleEntry).filter(ScheduleEntry.academic_year == year,
                                                 ScheduleEntry.teacher_id.isnot(None),
                                                 ScheduleEntry.subject_id.isnot(None)).all():
            cnt.setdefault(en.teacher_id, _C())[en.subject_id] += 1
        for tid, cc in cnt.items():
            tch = db.query(Teacher).filter(Teacher.id == tid).first()
            if tch and not (tch.specialty or "").strip():
                sb = db.query(Subject).filter(Subject.id == cc.most_common(1)[0][0]).first()
                if sb: tch.specialty = sb.name_ar
        db.commit()
        write_audit(g.user_id, "IMPORT_SCHEDULE", new=f"added:{added}")
        return ok({"added": added, "duplicates_skipped": dup, "entries_without_teacher": skipped_t,
                   "classes_skipped": skipped_c, "activities_added": act_added,
                   "teachers_created": created_t, "teacher_conflicts": teacher_conflicts,
                   "divisions": len([d for d in divs.values() if d])}, f"تم استيراد {added} حصة")
    except Exception as ex:
        db.rollback()
        return err(f"فشل الاستيراد: {ex}", 500)
    finally:
        db.close()

def _tt_ctx(db, si):
    """لقطة مرجعية (أقسام/مواد/محلات/أساتذة/أوقات) لبناء مطبوعات المواقيت بسرعة."""
    from app.utils import timetable_print as TP
    labels = _period_labels(si)
    return {"si": si, "labels": labels, "times": TP.period_times(si, labels),
            "div": {d.id: d for d in db.query(Division).all()},
            "sub": {x.id: x for x in db.query(Subject).all()},
            "room": {r.id: r for r in db.query(Room).all()},
            "tch": {t.id: t for t in db.query(Teacher).all()},
            "year": si.academic_year}

def _short_div(d):
    return f"{d.level}م{d.section}" if d else ""

def _tt_body(db, ctx, kind, obj, legal=None, page_break=False):
    """جدول زمني رسمي جاهز للإدراج. kind: teacher | division | room | student."""
    from app.utils import timetable_print as TP
    si, year = ctx["si"], ctx["year"]
    q = db.query(ScheduleEntry).filter(ScheduleEntry.academic_year == year)
    cells = {}
    def subj_txt(e):
        sb = ctx["sub"].get(e.subject_id) if e.subject_id else None
        return (getattr(e, "label", "") or (sb.name_ar if sb else ""))
    def tname(tid):
        t = ctx["tch"].get(tid) if tid else None
        return f"{t.last_name} {t.first_name}".strip() if t else ""
    def rname(e):
        r = ctx["room"].get(e.room_id) if e.room_id else None
        return r.name if r else ""
    if kind == "teacher":
        entries = q.filter(_tq(obj.id)).all()
        for e in entries:
            d = ctx["div"].get(e.division_id)
            room = rname(e)
            cells[(e.day_of_week, e.period)] = f"{_short_div(d)} {room}<small>{subj_txt(e)}</small>"
        for a in db.query(TeacherActivity).filter(TeacherActivity.teacher_id == obj.id,
                                                   TeacherActivity.academic_year == year).all():
            cells.setdefault((a.day_of_week, a.period), f"<b>{a.label}</b>")
        spec = obj.specialty or ""
        title = f"الجدول الزمني للأستاذ(ة): {obj.last_name} {obj.first_name}" + (f" &nbsp;-&nbsp; المادة: {spec}" if spec else "")
        legal = True if legal is None else legal
    elif kind == "division":
        for e in q.filter(ScheduleEntry.division_id == obj.id).all():
            room = rname(e)
            cells[(e.day_of_week, e.period)] = f"{subj_txt(e)}<small>{tname(e.teacher_id)}{(' — ' + room) if room else ''}</small>"
        title = f"الجدول الزمني للقسم: {obj.name}"
    elif kind == "room":
        for e in q.filter(ScheduleEntry.room_id == obj.id).all():
            d = ctx["div"].get(e.division_id)
            cells[(e.day_of_week, e.period)] = f"{_short_div(d)}<small>{subj_txt(e)} — {tname(e.teacher_id)}</small>"
        title = f"جدول استعمال المحل: {obj.name}"
    else:  # student
        div = ctx["div"].get(obj.division_id)
        for e in q.filter(ScheduleEntry.division_id == obj.division_id).all():
            room = rname(e)
            cells[(e.day_of_week, e.period)] = f"{subj_txt(e)}<small>{tname(e.teacher_id)}{(' — ' + room) if room else ''}</small>"
        title = f"الجدول الزمني للتلميذ(ة): {obj.last_name_ar} {obj.first_name_ar}"
        div_txt = f"القسم: {div.name}" if div else ""
    sub = locals().get("div_txt", "")
    return TP.render_timetable(title, cells, ctx["labels"], ctx["times"], legal=bool(legal), si=si,
                               subtitle=sub, city=si.wilaya or "", page_break=page_break)

def _schedule_print_page(title, si, days, periods, cell_fn):
    """قالب طباعة موحّد لجداول استعمال الزمن (أقسام/أساتذة/محلات) — شبكة
    أيام × حصص، كل خانة تُبنى عبر cell_fn(day_index, period_label)."""
    head = "".join(f"<th>{p}</th>" for p in periods)
    rows = ""
    for di, day in enumerate(days):
        cells = "".join(f"<td>{cell_fn(di, p) or '—'}</td>" for p in periods)
        rows += f"<tr><td style='font-weight:600;background:#f7f7f7'>{day}</td>{cells}</tr>"
    body = f"""
    <div class="title">{title}</div>
    <table><thead><tr><th>اليوم \\ الحصة</th>{head}</tr></thead><tbody>{rows}</tbody></table>
    <div class="sign"><div>الناظر<br>{si.nazir_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
    """
    return _doc_page(title, body, landscape=True, si=si)

@app.get("/api/schedule/division/<int:did>/print")
@gate_required("G09")
def print_division_schedule(did):
    db = Session()
    try:
        si = SI(db)
        div = db.query(Division).filter(Division.id == did).first()
        if not div: return Response("القسم غير موجود", mimetype="text/html")
        html = _doc_page(f"مواقيت القسم — {div.name}", _tt_body(db, _tt_ctx(db, si), "division", div), si=si)
        return Response(html, mimetype="text/html")
    finally:
        db.close()

@app.get("/api/schedule/teacher/<int:tid>/print")
@gate_required("G09")
def print_teacher_schedule(tid):
    db = Session()
    try:
        si = SI(db)
        t = db.query(Teacher).filter(Teacher.id == tid).first()
        if not t: return Response("الأستاذ غير موجود", mimetype="text/html")
        html = _doc_page(f"مواقيت الأستاذ(ة) — {t.last_name} {t.first_name}", _tt_body(db, _tt_ctx(db, si), "teacher", t), si=si)
        return Response(html, mimetype="text/html")
    finally:
        db.close()

@app.get("/api/schedule/room/<int:rid>/print")
@gate_required("G09")
def print_room_schedule(rid):
    db = Session()
    try:
        si = SI(db)
        r = db.query(Room).filter(Room.id == rid).first()
        if not r: return Response("المحل غير موجود", mimetype="text/html")
        html = _doc_page(f"استعمال المحل — {r.name}", _tt_body(db, _tt_ctx(db, si), "room", r), si=si)
        return Response(html, mimetype="text/html")
    finally:
        db.close()

@app.get("/api/schedule/student/<int:sid>/print")
@gate_required("G09")
def print_student_schedule(sid):
    """الجدول الزمني لتلميذ = جدول قسمه (يُبنى تلقائياً من استعمال الزمن)."""
    db = Session()
    try:
        si = SI(db)
        s_ = db.query(Student).filter(Student.id == sid).first()
        if not s_ or not s_.division_id: return Response("التلميذ غير موجود أو بلا قسم", mimetype="text/html")
        html = _doc_page(f"مواقيت التلميذ(ة)", _tt_body(db, _tt_ctx(db, si), "student", s_), si=si)
        return Response(html, mimetype="text/html")
    finally:
        db.close()

@app.get("/api/schedule/division/<int:did>/students-print")
@gate_required("G09")
def print_division_students_schedule(did):
    """مواقيت كل تلاميذ القسم، صفحة لكل تلميذ."""
    db = Session()
    try:
        si = SI(db)
        div = db.query(Division).filter(Division.id == did).first()
        if not div: return Response("القسم غير موجود", mimetype="text/html")
        ctx = _tt_ctx(db, si)
        studs = db.query(Student).filter(Student.division_id == did, Student.is_active == True)\
                  .order_by(Student.last_name_ar, Student.first_name_ar).all()
        body = "".join(_tt_body(db, ctx, "student", st, page_break=True) for st in studs) or "<p>لا يوجد تلاميذ</p>"
        return Response(_doc_page(f"مواقيت تلاميذ {div.name}", body, si=si), mimetype="text/html")
    finally:
        db.close()

def _teacher_hours_data(db):
    """حوصلة الساعات لكل أستاذ: النصاب التعاقدي (Teacher.weekly_hours) مقابل الحصص
    المُسنَدة فعلياً في استعمال الزمن؛ الفرق الموجب = ساعات إضافية، السالب = ساعات فائضة."""
    si = SI(db)
    out = []
    for t in db.query(Teacher).filter(Teacher.is_active == True).order_by(Teacher.last_name, Teacher.first_name).all():
        assigned = db.query(ScheduleEntry).filter(_tq(t.id), ScheduleEntry.academic_year == si.academic_year).count()
        if not assigned:
            continue
        contractual = t.weekly_hours or 0
        diff = assigned - contractual
        out.append({"id": t.id, "name": f"{t.last_name} {t.first_name}", "specialty": t.specialty or "",
                    "contractual_hours": contractual, "assigned_hours": assigned,
                    "extra_hours": max(0, diff), "surplus_hours": max(0, -diff)})
    return out

@app.get("/api/reports/teacher-hours")
@gate_required("G12")
def report_teacher_hours():
    db = Session()
    try:
        return ok(_teacher_hours_data(db))
    finally:
        db.close()

@app.get("/api/reports/teacher-hours/print/<kind>")
@gate_required("G12")
def print_teacher_hours(kind):
    """kind='extra' → حوصلة الساعات الإضافية (المُدرَّسة زيادة عن النصاب)،
    kind='surplus' → حوصلة الساعات الفائضة (النصاب غير المُستكمَل)."""
    db = Session()
    try:
        si = SI(db)
        data = _teacher_hours_data(db)
        if kind == "extra":
            rows_data = [d for d in data if d["extra_hours"] > 0]
            title = "حوصلة الساعات الإضافية"
            col_label, col_key = "الساعات الإضافية", "extra_hours"
        else:
            rows_data = [d for d in data if d["surplus_hours"] > 0]
            title = "حوصلة الساعات الفائضة"
            col_label, col_key = "الساعات الفائضة", "surplus_hours"
        rows = "".join(f"<tr><td>{i+1}</td><td>{d['name']}</td><td>{d['specialty']}</td>"
                       f"<td>{d['contractual_hours']}</td><td>{d['assigned_hours']}</td><td>{d[col_key]}</td></tr>"
                       for i, d in enumerate(rows_data)) or "<tr><td colspan='6'>لا توجد حالات</td></tr>"
        body = f"""
        <div class="title">{title} — {si.academic_year}</div>
        <table><thead><tr><th>ر.ت</th><th>الاسم واللقب</th><th>التخصص</th>
        <th>النصاب القانوني</th><th>الحجم المُسنَد</th><th>{col_label}</th></tr></thead>
        <tbody>{rows}</tbody></table>
        <div class="sign"><div>مقتصد<br>{si.bursar_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page(title, body, si=si), mimetype="text/html")
    finally:
        db.close()

# ── الكشف المفصل للعمال الإداريين والمهنيين ──
@app.get("/api/reports/staff-roster/print")
@gate_required("G12")
def print_staff_roster():
    db = Session()
    try:
        si = SI(db)
        role_labels = {"director": "مدير(ة) المؤسسة", "nazir": "ناظر(ة)", "counselor": "مستشار(ة) التربية", "supervisor_general": "مشرف(ة) عام(ة)",
                       "admin": "عون إدارة", "accountant": "مقتصد(ة)", "supervisor": "مشرف(ة) تربية",
                       "teacher": "أستاذ(ة)", "worker": "عامل مهني"}
        users = db.query(User).filter(User.is_active == True,
                                      User.role.in_(list(role_labels.keys()))).order_by(User.role).all()
        rows = "".join(
            f"<tr><td>{i+1}</td><td>{role_labels.get(u.role, u.role)}</td><td>{u.full_name}</td>"
            f"<td>{u.birth_date or ''}</td><td>{u.degree or ''}</td><td>{u.employment_status or ''}</td>"
            f"<td>{u.first_appointment_date or ''}</td><td>{u.hire_date or ''}</td><td>{u.hr_notes or ''}</td></tr>"
            for i, u in enumerate(users)) or "<tr><td colspan='9'>لا يوجد</td></tr>"
        body = f"""
        <div class="title">الكشف المفصل للعمال الإداريين والمهنيين</div>
        <p style="text-align:center;font-size:12.5px">السنة الدراسية: {si.academic_year}</p>
        <table><thead><tr><th>ر.ت</th><th>المنصب</th><th>الاسم واللقب</th><th>تاريخ الميلاد</th>
        <th>أقصى درجة جامعية</th><th>الصفة</th><th>تاريخ أول تعيين بهذه الصفة</th>
        <th>تاريخ التعيين بالمؤسسة</th><th>ملاحظات</th></tr></thead><tbody>{rows}</tbody></table>
        <div class="sign" style="justify-content:flex-end"><div>المدير(ة)<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("الكشف المفصل للعمال الإداريين والمهنيين", body, landscape=True, si=si), mimetype="text/html")
    finally:
        db.close()

# ════════════════ توزيع الساعة الرسمية (مرجع قابل للتعديل — RGF) ════════════════
_LANGUAGE_SUBJECT_NAMES = ["الإنجليزية", "الألمانية", "الإسبانية", "الإيطالية", "الروسية", "الفرنسية"]

@app.get("/api/reports/rgf/hours-norm")
@gate_required("G12")
def list_hours_norm():
    db = Session()
    try:
        si = SI(db)
        rows = db.query(OfficialHoursNorm).filter(OfficialHoursNorm.academic_year == si.academic_year)\
                 .order_by(OfficialHoursNorm.subject_name, OfficialHoursNorm.level).all()
        return ok([{"id": r.id, "subject_name": r.subject_name, "level": r.level,
                    "weekly_hours": r.weekly_hours} for r in rows])
    finally:
        db.close()

@app.post("/api/reports/rgf/hours-norm")
@gate_required("G12")
def upsert_hours_norm():
    """إنشاء أو تحديث حجم ساعي رسمي لمادة × مستوى (مرجع تُعبّئه الإدارة يدوياً
    لأنه يعتمد على المنهاج الوزاري ولا مصدر آلي له داخل النظام)."""
    data = request.get_json() or {}
    subject_name = (data.get("subject_name") or "").strip()
    try:
        level = int(data.get("level"))
        hours = float(data.get("weekly_hours") or 0)
    except (TypeError, ValueError):
        return err("المستوى والحجم الساعي مطلوبان بصيغة رقمية")
    if not subject_name or level < 1 or level > 4:
        return err("اسم المادة مطلوب والمستوى يجب أن يكون بين 1 و 4")
    db = Session()
    try:
        si = SI(db)
        row = db.query(OfficialHoursNorm).filter(OfficialHoursNorm.subject_name == subject_name,
                                                  OfficialHoursNorm.level == level,
                                                  OfficialHoursNorm.academic_year == si.academic_year).first()
        if row:
            row.weekly_hours = hours
        else:
            row = OfficialHoursNorm(subject_name=subject_name, level=level, weekly_hours=hours,
                                    academic_year=si.academic_year)
            db.add(row)
        db.commit()
        return ok(msg="تم حفظ الحجم الساعي الرسمي")
    finally:
        db.close()

@app.delete("/api/reports/rgf/hours-norm/<int:nid>")
@gate_required("G12")
def delete_hours_norm(nid):
    db = Session()
    try:
        row = db.query(OfficialHoursNorm).filter(OfficialHoursNorm.id == nid).first()
        if not row: return err("غير موجود", 404)
        db.delete(row); db.commit()
        return ok(msg="تم الحذف")
    finally:
        db.close()

# ════════════════ التقرير العام RGF (9 وثائق رسمية مطابقة للنموذج المرجعي) ════════════════
def _rgf_divider(code, title):
    """صفحة فاصلة رسمية تسبق كل وثيقة من وثائق RGF التسع — تحاكي شكل النموذج
    المرجعي المعتمد: صندوق ختم المؤسسة + رمز الوثيقة (n.9.1) + صندوقا ملاحظات
    مدير المؤسسة ومدير التربية، تماماً كما في صفحات الفصل بالملف المرجعي."""
    return f"""
    <div style="page-break-before:always;display:flex;gap:24px;padding-top:10px">
      <div style="flex:1">
        <div style="border:1px solid #333;padding:8px;text-align:center;font-weight:bold;margin-bottom:14px">
          <u>خاتم المؤسسة</u><div style="height:150px"></div>
        </div>
        <div style="text-align:center;border:1px solid #333;width:90px;margin:0 auto 14px;padding:4px;font-weight:bold">{code}</div>
        <div style="border:2px solid #333;padding:40px 10px;text-align:center;font-size:22px;font-weight:bold">{title}</div>
      </div>
      <div style="flex:1">
        <div style="border:1px solid #333;padding:8px;margin-bottom:16px">
          <u style="font-weight:bold">ملاحظات مدير المؤسسة</u><div style="height:150px"></div>
        </div>
        <div style="border:1px solid #333;padding:8px">
          <u style="font-weight:bold">ملاحظات مدير التربية</u><div style="height:150px"></div>
        </div>
      </div>
    </div>"""

def _rgf_cover_page(si):
    docs = ["الكشف المفصل للموظفين الإداريين والمهنيين", "كشف مفصل للتلاميذ الحاضرين",
            "استعمال المحلات المتخصصة", "استعمال المحلات العادية", "مواقيت الأقسام",
            "مواقيت الأساتذة", "تعليم اللغات الحية", "خدمات الأساتذة", "تطبيق المواقيت الرسمية"]
    rows = "".join(f"<tr><td>{i+1}</td><td>{d}</td></tr>" for i, d in enumerate(docs))
    return f"""
    <div style="text-align:center;margin-bottom:16px">
      <div style="font-size:22px;font-weight:bold;margin:22px 0;text-decoration:underline">تقرير سير المؤسسة (RGF)</div>
      <div style="font-size:15px;font-weight:600">{si.name_ar or cfg.SCHOOL_NAME}</div>
      <div style="font-size:13px">رمز المؤسسة: {si.school_code or ''}</div>
      <div style="font-size:13px">السنة الدراسية: {si.academic_year or cfg.ACADEMIC_YEAR}</div>
    </div>
    <table><thead><tr><th>ر.ت</th><th>الوثيقة</th></tr></thead><tbody>{rows}</tbody></table>
    <div class="sign" style="justify-content:flex-end;margin-top:60px">
      <div>تاريخ التحرير: {date.today().isoformat()}<br>مدير(ة) المؤسسة<br>{si.director_name or ''}</div>
    </div>"""

def _rgf_student_boarding_data(db, si):
    """كشف مفصل للتلاميذ الحاضرين: توزيع حسب القسم × الصفة (داخلي/نصف داخلي/
    خارجي) × الجنس × الإعادة — من بيانات Student.status/gender/is_repeating
    الموجودة فعلياً في النظام."""
    divs = _sort_divs(db.query(Division).filter(Division.is_active == True,
                                     Division.academic_year == si.academic_year).all())
    rows = []
    tot = dict(in_m=0, in_f=0, half_m=0, half_f=0, out_m=0, out_f=0, rep_m=0, rep_f=0, total=0)
    for d in divs:
        studs = db.query(Student).filter(Student.division_id == d.id,
                                         Student.academic_year == si.academic_year).all()
        c = dict(in_m=0, in_f=0, half_m=0, half_f=0, out_m=0, out_f=0, rep_m=0, rep_f=0)
        for s in studs:
            sex = "m" if s.gender == "ذكر" else "f"
            key = "in" if s.status == "داخلي" else ("half" if s.status == "نصف داخلي" else "out")
            c[f"{key}_{sex}"] += 1
            if s.is_repeating:
                c[f"rep_{sex}"] += 1
        for k in tot:
            if k != "total": tot[k] += c[k]
        tot["total"] += len(studs)
        c["division"] = d.name; c["level"] = d.level; c["total"] = len(studs)
        rows.append(c)
    return rows, tot

def _rgf_subject_names_with_schedule(db, si):
    q = db.query(Subject.name_ar).join(ScheduleEntry, ScheduleEntry.subject_id == Subject.id)\
          .filter(ScheduleEntry.academic_year == si.academic_year).distinct().all()
    return sorted({r[0] for r in q if r[0]})

def _rgf_teacher_service_rows(db, si, subject_name):
    """خدمات الأساتذة لمادة معيّنة: لكل أستاذ درَّس هذه المادة فعلياً حسب
    استعمال الزمن — الأقسام المُسنَدة، مجموع الحصص، النصاب الأقصى (Teacher.
    weekly_hours)، تعديل الخدمة (تخفيضات — تبقى صفراً افتراضياً، لا مصدر بيانات
    لها بعد في النظام)، الخدمة الصافية، والفروق (زيادة/نقص)."""
    tids = [r[0] for r in db.query(ScheduleEntry.teacher_id)
            .join(Subject, Subject.id == ScheduleEntry.subject_id)
            .filter(Subject.name_ar == subject_name, ScheduleEntry.academic_year == si.academic_year,
                    ScheduleEntry.teacher_id.isnot(None)).distinct().all()]
    teachers = db.query(Teacher).filter(Teacher.id.in_(tids)).all() if tids else []
    out = []
    for t in teachers:
        entries = db.query(ScheduleEntry).join(Subject, Subject.id == ScheduleEntry.subject_id)\
                    .filter(_tq(t.id), Subject.name_ar == subject_name,
                            ScheduleEntry.academic_year == si.academic_year).all()
        by_div = {}
        for e in entries:
            by_div.setdefault(e.division_id, 0)
            by_div[e.division_id] += 1
        divs = _sort_divs(db.query(Division).filter(Division.id.in_(list(by_div.keys()))).all()) if by_div else []
        dmap = {d.id: d for d in divs}
        assigned = len(entries)
        u = db.query(User).filter(User.id == t.user_id).first() if t.user_id else None
        max_service = t.weekly_hours or 0
        reduction = 0  # تعديل الخدمة (تنسيق/صيانة العتاد/فرق الـ35/أسباب أخرى) — صفر افتراضياً حالياً
        net_service = max(0, max_service - reduction)
        diff = assigned - net_service
        out.append({
            "name": f"{t.last_name} {t.first_name}", "birth_date": (u.birth_date if u else None) or "",
            "grade_rank": t.grade_rank or "", "degree": (u.degree if u else "") or "",
            "status": (u.employment_status if u else "") or "",
            "hire_date": (u.hire_date if u else t.start_date) or "",
            "divisions": [{"name": dmap[did].name if did in dmap else "", "hours": h} for did, h in by_div.items()],
            "assigned": assigned, "max_service": max_service, "reduction": reduction,
            "net_service": net_service, "diff": diff,
        })
    return out

def _rgf_official_hours_actual(db, si):
    """الحجم الساعي المُطبَّق فعلياً لكل مادة × كل مستوى (1-4)، محسوب من
    استعمال الزمن الحقيقي — يُقارَن بالمرجع الرسمي القابل للتعديل
    (OfficialHoursNorm) في وثيقة «تطبيق المواقيت الرسمية»."""
    rows = db.query(Subject.name_ar, Division.level, sa_func.count(ScheduleEntry.id))\
             .join(ScheduleEntry, ScheduleEntry.subject_id == Subject.id)\
             .join(Division, Division.id == ScheduleEntry.division_id)\
             .filter(ScheduleEntry.academic_year == si.academic_year)\
             .group_by(Subject.name_ar, Division.level).all()
    data = {}
    for name, level, cnt in rows:
        data.setdefault(name, {1: 0, 2: 0, 3: 0, 4: 0})
        if level in data[name]:
            data[name][level] = cnt
    ndivs = db.query(Division.level, sa_func.count(Division.id)).filter(
        Division.is_active == True, Division.academic_year == si.academic_year).group_by(Division.level).all()
    ndiv_map = {lvl: c for lvl, c in ndivs}
    return data, ndiv_map

@app.get("/api/reports/rgf/print")
@gate_required("G12")
def print_rgf_report():
    """التقرير العام لسير المؤسسة RGF — تجميع الوثائق التسع الرسمية دفعة واحدة
    بنفس بنية وترتيب النموذج المرجعي المعتمد من مديرية التربية (غلاف + 9
    وثائق، كل وثيقة تسبقها صفحة فاصلة بختم المؤسسة وصندوقي الملاحظات)."""
    db = Session()
    try:
        si = SI(db)
        periods = _period_labels(si); _ttc = _tt_ctx(db, si)
        sections = [_rgf_cover_page(si)]

        # 1) الكشف المفصل للموظفين الإداريين والمهنيين (+ مناصب مالية)
        role_labels = {"director": "مدير(ة) المؤسسة", "nazir": "ناظر(ة)", "counselor": "مستشار(ة) التربية", "supervisor_general": "مشرف(ة) عام(ة)",
                       "admin": "عون إدارة", "accountant": "مقتصد(ة)", "supervisor": "مشرف(ة) تربية",
                       "teacher": "أستاذ(ة)", "worker": "عامل مهني"}
        users = db.query(User).filter(User.is_active == True, User.role.in_(list(role_labels.keys())))\
                  .order_by(User.role).all()
        rows1 = "".join(
            f"<tr><td>{i+1}</td><td>{u.full_name}<br><small>{u.birth_date or ''}</small></td>"
            f"<td>{role_labels.get(u.role, u.role)}</td><td>{u.degree or ''}</td>"
            f"<td>{u.employment_status or ''}</td><td>{u.first_appointment_date or ''}</td>"
            f"<td>{u.hire_date or ''}</td><td>{u.financial_position or ''}</td></tr>"
            for i, u in enumerate(users)) or "<tr><td colspan='8'>لا يوجد</td></tr>"
        sections.append(_rgf_divider("1.9.1", "الكشف المفصل للموظفين الإداريين والمهنيين") +
            "<div class='title'>الكشف المفصل للموظفين الإداريين والمهنيين</div>"
            "<table><thead><tr><th>ر.ت</th><th>اللقب والاسم وتاريخ الميلاد</th><th>الوظيفة</th>"
            "<th>الشهادة</th><th>مرسم/متربص</th><th>تاريخ أول تعيين بهذه الصفة</th>"
            f"<th>تاريخ التعيين بالمؤسسة</th><th>مناصب مالية</th></tr></thead><tbody>{rows1}</tbody></table>")

        # 2) كشف مفصل للتلاميذ الحاضرين
        brows, btot = _rgf_student_boarding_data(db, si)
        rows2 = "".join(
            f"<tr><td>{r['division']}</td><td>{r['in_m']}</td><td>{r['in_f']}</td><td>{r['in_m']+r['in_f']}</td>"
            f"<td>{r['half_m']}</td><td>{r['half_f']}</td><td>{r['half_m']+r['half_f']}</td>"
            f"<td>{r['out_m']}</td><td>{r['out_f']}</td><td>{r['out_m']+r['out_f']}</td>"
            f"<td>{r['total']}</td><td>{r['rep_m']}</td><td>{r['rep_f']}</td><td>{r['rep_m']+r['rep_f']}</td></tr>"
            for r in brows) or "<tr><td colspan='14'>لا يوجد</td></tr>"
        rows2 += (f"<tr style='font-weight:bold;background:#f0f0f0'><td>المجموع</td>"
                  f"<td>{btot['in_m']}</td><td>{btot['in_f']}</td><td>{btot['in_m']+btot['in_f']}</td>"
                  f"<td>{btot['half_m']}</td><td>{btot['half_f']}</td><td>{btot['half_m']+btot['half_f']}</td>"
                  f"<td>{btot['out_m']}</td><td>{btot['out_f']}</td><td>{btot['out_m']+btot['out_f']}</td>"
                  f"<td>{btot['total']}</td><td>{btot['rep_m']}</td><td>{btot['rep_f']}</td>"
                  f"<td>{btot['rep_m']+btot['rep_f']}</td></tr>")
        sections.append(_rgf_divider("2.9.1", "كشف مفصل للتلاميذ الحاضرين") +
            "<div class='title'>كشف مفصل للتلاميذ الحاضرين</div>"
            "<table><thead><tr><th rowspan='2'>القسم</th><th colspan='3'>داخلي</th>"
            "<th colspan='3'>نصف داخلي</th><th colspan='3'>خارجي</th><th rowspan='2'>المجموع</th>"
            "<th colspan='3'>معيدون</th></tr><tr><th>ذكور</th><th>إناث</th><th>مج</th>"
            "<th>ذكور</th><th>إناث</th><th>مج</th><th>ذكور</th><th>إناث</th><th>مج</th>"
            f"<th>ذكور</th><th>إناث</th><th>مج</th></tr></thead><tbody>{rows2}</tbody></table>")

        # 3-4) استعمال المحلات (متخصصة / عادية)
        for rtype, code in (("متخصص", "3.9.1"), ("عادي", "4.9.1")):
            title = f"استعمال المحلات {'المتخصصة' if rtype=='متخصص' else 'العادية'}"
            sections.append(_rgf_divider(code, title))
            rooms = db.query(Room).filter(Room.is_active == True, Room.room_type == rtype)\
                      .order_by(Room.name).all()
            for room in rooms:
                entries = db.query(ScheduleEntry).filter(ScheduleEntry.room_id == room.id,
                                                          ScheduleEntry.academic_year == si.academic_year).all()
                if not entries: continue
                sections.append(_tt_body(db, _ttc, "room", room, page_break=True))

        # 5) مواقيت الأقسام
        sections.append(_rgf_divider("5.9.1", "مواقيت الأقسام"))
        divs = _sort_divs(db.query(Division).filter(Division.is_active == True).all())
        for div in divs:
            entries = db.query(ScheduleEntry).filter(ScheduleEntry.division_id == div.id,
                                                      ScheduleEntry.academic_year == si.academic_year).all()
            sections.append(_tt_body(db, _ttc, "division", div, page_break=True))

        # 6) مواقيت الأساتذة
        sections.append(_rgf_divider("6.9.1", "مواقيت الأساتذة"))
        teachers = db.query(Teacher).filter(Teacher.is_active == True)\
                     .order_by(Teacher.last_name, Teacher.first_name).all()
        for t in teachers:
            entries = db.query(ScheduleEntry).filter(_tq(t.id),
                                                      ScheduleEntry.academic_year == si.academic_year).all()
            if not entries: continue
            sections.append(_tt_body(db, _ttc, "teacher", t, page_break=True))

        # 7) تعليم اللغات الحية
        sections.append(_rgf_divider("7.9.1", "تعليم اللغات الحية"))
        lang_rows = ""
        lvl_totals = {1: 0, 2: 0, 3: 0, 4: 0}
        for lang in _LANGUAGE_SUBJECT_NAMES:
            per_level = {}
            for lvl in (1, 2, 3, 4):
                q = db.query(ScheduleEntry).join(Subject, Subject.id == ScheduleEntry.subject_id)\
                      .join(Division, Division.id == ScheduleEntry.division_id)\
                      .filter(Subject.name_ar.like(f"%{lang}%"), Division.level == lvl,
                              ScheduleEntry.academic_year == si.academic_year)
                hours = q.count()
                groups = q.with_entities(ScheduleEntry.division_id).distinct().count()
                per_level[lvl] = (groups, hours)
                lvl_totals[lvl] += hours
            if not any(h for _, h in per_level.values()):
                continue
            lang_rows += f"<tr><td>{lang}</td>" + "".join(
                f"<td>{per_level[lvl][0]}</td><td>{per_level[lvl][1]}</td>" for lvl in (1, 2, 3, 4)) + "</tr>"
        sections.append(
            "<div class='title'>تعليم اللغات الحية — الموسم الدراسي الحالي</div>"
            "<table><thead><tr><th rowspan='2'>اللغة</th><th colspan='2'>سنة أولى</th>"
            "<th colspan='2'>سنة ثانية</th><th colspan='2'>سنة ثالثة</th><th colspan='2'>سنة رابعة</th></tr>"
            "<tr><th>عدد الأفواج</th><th>عدد الساعات</th><th>عدد الأفواج</th><th>عدد الساعات</th>"
            "<th>عدد الأفواج</th><th>عدد الساعات</th><th>عدد الأفواج</th><th>عدد الساعات</th></tr></thead>"
            f"<tbody>{lang_rows or '<tr><td colspan=9>لا يوجد</td></tr>'}</tbody></table>"
            "<div style='font-size:12px;color:#555;margin-top:6px'>* أرقام الموسم الحالي مُستخرجة آلياً من استعمال "
            "الزمن الفعلي؛ توقعات الموسم المقبل تُدخَل يدوياً في نسخة لاحقة عند توفّر بيانات التسجيل المسبق.</div>")

        # 8) خدمات الأساتذة (وثيقة مستقلة لكل مادة)
        subj_names = _rgf_subject_names_with_schedule(db, si)
        for idx, sname in enumerate(subj_names):
            teacher_rows = _rgf_teacher_service_rows(db, si, sname)
            if not teacher_rows: continue
            sections.append(_rgf_divider("8.9.1", f"خدمات الأساتذة — المادة: {sname}"))
            body_rows = ""
            tmax = tnet = tassigned = tdiff = 0
            for i, r in enumerate(teacher_rows):
                divs_html = "<br>".join(f"{d['name']} ({d['hours']})" for d in r["divisions"]) or "—"
                body_rows += (f"<tr><td>{i+1}</td><td>{r['name']}<br><small>{r['birth_date']}</small></td>"
                             f"<td>{r['grade_rank']}</td><td>{r['degree']}</td><td>{r['status']}</td>"
                             f"<td>{r['hire_date']}</td><td style='font-size:10.5px'>{divs_html}</td>"
                             f"<td>{r['max_service']}</td><td>{r['max_service']}</td>"
                             f"<td>0</td><td>0</td><td>0</td><td>0</td>"
                             f"<td>{r['reduction']}</td><td>{r['net_service']}</td>"
                             f"<td>{r['assigned']}</td><td>{r['diff']}</td></tr>")
                tmax += r["max_service"]; tnet += r["net_service"]; tassigned += r["assigned"]; tdiff += r["diff"]
            body_rows += (f"<tr style='font-weight:bold;background:#f0f0f0'><td colspan='7'>المجموع</td>"
                         f"<td>{tmax}</td><td>{tmax}</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td>"
                         f"<td>{tnet}</td><td>{tassigned}</td><td>{tdiff}</td></tr>")
            sections.append(
                f"<div class='title'>{sname}</div>"
                "<table style='font-size:10.5px'><thead><tr><th>المناصب</th><th>اللقب والاسم وتاريخ الميلاد</th>"
                "<th>الرتبة</th><th>أقصى درجة جامعية</th><th>الصفة</th><th>تاريخ التعيين بالمؤسسة</th>"
                "<th>الأقسام (حصص)</th><th>أقصى خدمة واجبة</th><th>مجموع التوقيت الواجب</th>"
                "<th>تنسيق</th><th>صيانة العتاد</th><th>فرق الـ35 تلميذ</th><th>أسباب أخرى</th>"
                f"<th>مجموع التخفيض</th><th>أقصى خدمة صافية</th><th>الخدمة المؤداة</th><th>الفروق</th></tr></thead>"
                f"<tbody>{body_rows}</tbody></table>")

        # 9) تطبيق المواقيت الرسمية
        sections.append(_rgf_divider("9.9.1", "تطبيق المواقيت الرسمية"))
        actual, ndiv_map = _rgf_official_hours_actual(db, si)
        norms = db.query(OfficialHoursNorm).filter(OfficialHoursNorm.academic_year == si.academic_year).all()
        norm_map = {}
        for n in norms:
            norm_map.setdefault(n.subject_name, {1: 0, 2: 0, 3: 0, 4: 0})[n.level] = n.weekly_hours
        all_subjects = sorted(set(list(actual.keys()) + list(norm_map.keys())))
        rows9 = ""
        gtot_actual = {1: 0, 2: 0, 3: 0, 4: 0}; gtot_norm = {1: 0, 2: 0, 3: 0, 4: 0}
        for sname in all_subjects:
            a = actual.get(sname, {1: 0, 2: 0, 3: 0, 4: 0})
            n = norm_map.get(sname, {1: 0, 2: 0, 3: 0, 4: 0})
            for lvl in (1, 2, 3, 4):
                gtot_actual[lvl] += a[lvl]; gtot_norm[lvl] += n[lvl]
            rows9 += (f"<tr><td>{sname}</td>" +
                     "".join(f"<td>{a[lvl]}</td>" for lvl in (1, 2, 3, 4)) +
                     f"<td>{sum(a.values())}</td>" +
                     "".join(f"<td>{n[lvl]}</td>" for lvl in (1, 2, 3, 4)) +
                     f"<td>{sum(n.values())}</td></tr>")
        rows9 += (f"<tr style='font-weight:bold;background:#f0f0f0'><td>عدد الأقسام</td>" +
                 "".join(f"<td>{ndiv_map.get(lvl,0)}</td>" for lvl in (1, 2, 3, 4)) +
                 f"<td>{sum(ndiv_map.values())}</td><td colspan='5'></td></tr>")
        sections.append(
            "<div class='title'>تطبيق المواقيت الرسمية</div>"
            "<table><thead><tr><th rowspan='2'>المادة</th><th colspan='5'>الحجم المُطبَّق فعلياً (من استعمال الزمن)</th>"
            "<th colspan='5'>الحجم المقرَّر رسمياً (مرجع قابل للتعديل)</th></tr>"
            "<tr><th>سنة 1</th><th>سنة 2</th><th>سنة 3</th><th>سنة 4</th><th>المجموع</th>"
            "<th>سنة 1</th><th>سنة 2</th><th>سنة 3</th><th>سنة 4</th><th>المجموع</th></tr></thead>"
            f"<tbody>{rows9}</tbody></table>"
            "<div style='font-size:12px;color:#555;margin-top:6px'>* عمود «المقرَّر رسمياً» يُعدَّل من صفحة "
            "«التقرير العام RGF ⚙️ توزيع الساعة الرسمية» في الواجهة.</div>")

        full_body = "".join(sections)
        return Response(_doc_page("التقرير العام لسير المؤسسة RGF", full_body, landscape=True, si=si),
                        mimetype="text/html")
    finally:
        db.close()

# ── الملف الكامل: التقرير العام للتسيير (12 وثيقة رسمية مجمّعة) ──
@app.get("/api/reports/general-management/full/print")
@gate_required("G12")
def print_general_management_full():
    """يُجمِّع كل وثائق التقرير العام للتسيير الرسمية في ملف واحد قابل للطباعة
    دفعة واحدة (حسب البرنامج المرجعي المعتمد من طرف مفتشية إدارة المتوسطات:
    الكشف المفصل للموظفين، مواقيت كل قسم، مواقيت كل أستاذ، مواقيت كل محل،
    حوصلة الساعات الإضافية والفائضة)، كل وثيقة تسبقها صفحة غلاف بتوقيع
    وختم رئيس المؤسسة، تماماً كما في النموذج الرسمي المُعتمَد."""
    db = Session()
    try:
        si = SI(db)
        def cover(title):
            return (f'<div style="page-break-before:always;text-align:center;padding-top:220px">'
                    f'<div style="font-size:22px;font-weight:bold;margin-bottom:60px">{title}</div>'
                    f'<div style="font-size:13px">السنة الدراسية: {si.academic_year}</div>'
                    f'<div style="margin-top:120px;font-size:13px">ختم وتوقيع رئيس المؤسسة</div></div>')

        sections = []
        sections.append(cover("التقرير العام لسير المؤسسة التربوية"))

        # 1) الكشف المفصل للموظفين
        role_labels = {"director": "مدير(ة) المؤسسة", "nazir": "ناظر(ة)", "counselor": "مستشار(ة) التربية", "supervisor_general": "مشرف(ة) عام(ة)",
                       "admin": "عون إدارة", "accountant": "مقتصد(ة)", "supervisor": "مشرف(ة) تربية",
                       "teacher": "أستاذ(ة)", "worker": "عامل مهني"}
        users = db.query(User).filter(User.is_active == True, User.role.in_(list(role_labels.keys()))).order_by(User.role).all()
        rows = "".join(f"<tr><td>{i+1}</td><td>{role_labels.get(u.role,u.role)}</td><td>{u.full_name}</td>"
                       f"<td>{u.birth_date or ''}</td><td>{u.degree or ''}</td><td>{u.employment_status or ''}</td></tr>"
                       for i, u in enumerate(users)) or "<tr><td colspan='6'>لا يوجد</td></tr>"
        sections.append(cover("الكشف المفصل للعمال الإداريين والمهنيين") +
                        f"<div class='title'>الكشف المفصل للعمال الإداريين والمهنيين</div>"
                        f"<table><thead><tr><th>ر.ت</th><th>المنصب</th><th>الاسم واللقب</th><th>تاريخ الميلاد</th>"
                        f"<th>الدرجة</th><th>الصفة</th></tr></thead><tbody>{rows}</tbody></table>")

        # 2) مواقيت الأقسام
        periods = _period_labels(si); _ttc = _tt_ctx(db, si)
        divs = _sort_divs(db.query(Division).filter(Division.is_active == True).all())
        sections.append(cover("مواقيت الأقسام"))
        for div in divs:
            entries = db.query(ScheduleEntry).filter(ScheduleEntry.division_id == div.id,
                                                      ScheduleEntry.academic_year == si.academic_year).all()
            sections.append(_tt_body(db, _ttc, "division", div, page_break=True))

        # 3) مواقيت الأساتذة
        sections.append(cover("مواقيت الأساتذة"))
        teachers = db.query(Teacher).filter(Teacher.is_active == True).all()
        for t in teachers:
            entries = db.query(ScheduleEntry).filter(_tq(t.id),
                                                      ScheduleEntry.academic_year == si.academic_year).all()
            if not entries: continue
            sections.append(_tt_body(db, _ttc, "teacher", t, page_break=True))

        # 4) مواقيت المحلات (عادية / متخصصة)
        sections.append(cover("مواقيت المحلات"))
        rooms = db.query(Room).filter(Room.is_active == True).order_by(Room.room_type, Room.name).all()
        for room in rooms:
            entries = db.query(ScheduleEntry).filter(ScheduleEntry.room_id == room.id,
                                                      ScheduleEntry.academic_year == si.academic_year).all()
            if not entries: continue
            sections.append(_tt_body(db, _ttc, "room", room, page_break=True))

        # 5) حوصلة الساعات الإضافية والفائضة
        hdata = _teacher_hours_data(db)
        extra_rows = "".join(f"<tr><td>{i+1}</td><td>{d['name']}</td><td>{d['contractual_hours']}</td>"
                             f"<td>{d['assigned_hours']}</td><td>{d['extra_hours']}</td></tr>"
                             for i, d in enumerate(hdata) if d["extra_hours"] > 0) or "<tr><td colspan='5'>لا توجد حالات</td></tr>"
        surplus_rows = "".join(f"<tr><td>{i+1}</td><td>{d['name']}</td><td>{d['contractual_hours']}</td>"
                               f"<td>{d['assigned_hours']}</td><td>{d['surplus_hours']}</td></tr>"
                               for i, d in enumerate(hdata) if d["surplus_hours"] > 0) or "<tr><td colspan='5'>لا توجد حالات</td></tr>"
        sections.append(cover("حوصلة الساعات الإضافية والفائضة") +
                        "<div class='title'>حوصلة الساعات الإضافية</div>"
                        "<table><thead><tr><th>ر.ت</th><th>الاسم واللقب</th><th>النصاب</th><th>المُسنَد</th><th>إضافية</th></tr></thead>"
                        f"<tbody>{extra_rows}</tbody></table>"
                        "<div class='title' style='margin-top:30px'>حوصلة الساعات الفائضة</div>"
                        "<table><thead><tr><th>ر.ت</th><th>الاسم واللقب</th><th>النصاب</th><th>المُسنَد</th><th>فائضة</th></tr></thead>"
                        f"<tbody>{surplus_rows}</tbody></table>"
                        f"<div class='sign'><div>مقتصد<br>{si.bursar_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>")

        full_body = "".join(sections)
        return Response(_doc_page("التقرير العام للتسيير", full_body, landscape=True, si=si), mimetype="text/html")
    finally:
        db.close()

# ════════════════ GRADES ════════════════
@app.get("/api/grades/<int:div_id>/<term>")
@gate_required("G04")
def get_grades(div_id, term):
    db = Session()
    try:
        grades = db.query(Grade).filter(Grade.division_id==div_id,Grade.term==term).all()
        return ok([_grade(g) for g in grades])
    finally:
        db.close()

@app.post("/api/grades")
@gate_required("G04")
def save_grade():
    data = request.get_json() or {}
    db = Session()
    try:
        subj = db.query(Subject).filter(Subject.id==data.get("subject_id")).first()
        calc = GradeService.calc(
            fard1=data.get("fard1"), fard2=data.get("fard2"),
            activity=data.get("activity"), exam_raw=data.get("exam_raw"),
            has_fard2=subj.has_fard2 if subj else True,
            has_exam=subj.has_exam if subj else True,
            is_exempt=subj.is_exempt if subj else False,
        )
        existing = db.query(Grade).filter(
            Grade.student_id==data["student_id"], Grade.subject_id==data["subject_id"], Grade.term==data["term"]
        ).first()
        if existing:
            for k,v in data.items():
                if hasattr(existing,k) and k not in ("id","entered_at"): setattr(existing,k,v)
            existing.exam_20=calc["exam_20"]; existing.term_average=calc["term_average"]
            existing.comment=calc["comment"]; existing.entered_by=g.user_id
        else:
            db.add(Grade(**{k:v for k,v in data.items() if hasattr(Grade,k) and k!="id"},
                          exam_20=calc["exam_20"],term_average=calc["term_average"],
                          comment=calc["comment"],entered_by=g.user_id))
        db.commit()
        return ok(calc,"تم حفظ النقطة")
    finally:
        db.close()

@app.post("/api/grades/compute/<int:div_id>/<term>")
@gate_required("G05")
def compute_results(div_id, term):
    db = Session()
    try:
        students = db.query(Student).filter(Student.division_id==div_id,Student.is_active==True).all()
        results = []
        for s in students:
            grades = db.query(Grade).filter(Grade.student_id==s.id,Grade.term==term).all()
            subj_data = []
            for gr in grades:
                subj = db.query(Subject).filter(Subject.id==gr.subject_id).first()
                subj_data.append({"term_average":gr.term_average,"coefficient":subj.coefficient if subj else 1,"is_exempt":gr.term_average is None})
            calc = GradeService.calc_general(subj_data)
            abs_count = db.query(Absence).filter(Absence.student_id==s.id).count()
            tr = db.query(TermResult).filter(TermResult.student_id==s.id,TermResult.term==term).first()
            if tr:
                tr.term_average=calc["average"]; tr.total_coeff=calc["total_coeff"]
                tr.total_points=calc["total_points"]; tr.absence_hours=abs_count
            else:
                db.add(TermResult(student_id=s.id,division_id=div_id,term=term,
                                  term_average=calc["average"],total_coeff=calc["total_coeff"],
                                  total_points=calc["total_points"],absence_hours=abs_count))
            results.append({"student_id":s.id,"name":s.full_name,**calc})
        db.commit()
        ranked = GradeService.rank(results)
        for rk in ranked:
            tr = db.query(TermResult).filter(TermResult.student_id==rk["student_id"],TermResult.term==term).first()
            if tr: tr.rank=rk["rank"]
        db.commit()
        return ok({"computed":len(results)},"تم حساب المعدلات")
    finally:
        db.close()

@app.post("/api/grades/import-xls")
@gate_required("G04")
def import_grades_xls():
    """استيراد نقاط مادة معينة (فرض1/فرض2/نشاط/اختبار/معدل) من ملف حجز
    أستاذ أو ملف رقمنة. المطابقة تتم عبر رقم القيد أو الرقم الوطني، وعند
    غيابهما عبر اللقب والاسم داخل نفس القسم. ⚠ محلل تجريبي: إن لم يتطابق
    مع صيغة ملفاتكم الفعلية أرسلوا نموذجاً لضبطه بدقة."""
    from app.utils.xls_parser import parse_grades_xls, is_frameset
    f = request.files.get("file")
    subject_id = request.form.get("subject_id")
    division_id = request.form.get("division_id")
    term = request.form.get("term", "1")
    if not f or not subject_id:
        return err("الملف والمادة مطلوبان")
    content = f.read()
    if is_frameset(content):
        return err("هذا الملف إطار فارغ (frameset) — ارفع ملف الجدول الفعلي بداخله")
    rows = parse_grades_xls(content)
    if not rows:
        return err("لم يتم التعرف على بيانات نقاط في هذا الملف — يرجى إرسال نموذج للتحقق من الصيغة")

    db = Session()
    updated = not_found = errors = 0
    try:
        subj = db.query(Subject).filter(Subject.id==int(subject_id)).first()
        if not subj: return err("المادة غير موجودة")
        for row in rows:
            try:
                q = db.query(Student)
                s = None
                if row.get("national_id"):
                    s = q.filter(Student.national_id==row["national_id"]).first()
                if not s and row.get("registration_num"):
                    s = q.filter(Student.registration_num==row["registration_num"]).first()
                if not s and row.get("last_name_ar"):
                    qq = db.query(Student).filter(Student.last_name_ar==row["last_name_ar"],
                                                   Student.first_name_ar==row.get("first_name_ar",""))
                    if division_id: qq = qq.filter(Student.division_id==int(division_id))
                    s = qq.first()
                if not s:
                    not_found += 1; continue
                gr = db.query(Grade).filter(Grade.student_id==s.id, Grade.subject_id==subj.id,
                                            Grade.term==term).first()
                if not gr:
                    gr = Grade(student_id=s.id, subject_id=subj.id,
                              division_id=s.division_id or (int(division_id) if division_id else None),
                              term=term, entered_by=g.user_id)
                    db.add(gr)
                for f_ in ("fard1","fard2","activity","exam_raw","term_average"):
                    if row.get(f_) is not None:
                        setattr(gr, f_, row[f_])
                updated += 1
            except Exception:
                errors += 1
                continue
        db.commit()
        write_audit(g.user_id, "IMPORT_GRADES", new=f"updated:{updated},not_found:{not_found}")
        return ok({"updated":updated,"not_found":not_found,"errors":errors,"total_in_file":len(rows)})
    finally:
        db.close()

# ════════════════ ABSENCES ════════════════
@app.post("/api/absences")
@gate_required("G02")
def record_absence():
    data = request.get_json() or {}
    db = Session()
    try:
        clean = {k: (_parse_date_field(v) if k=="date" else v)
                 for k,v in data.items() if hasattr(Absence,k) and k!="id"}
        ab = Absence(**clean, entered_by=g.user_id)
        db.add(ab); db.commit()
        _check_milestone(data["student_id"],db,g.user_id)
        stu = db.query(Student).filter(Student.id == data["student_id"]).first()
        if stu:
            notify_absence(stu, SI(db), str(ab.date), ab.period or "", db=db)
        return ok(msg="تم تسجيل الغياب",code=201)
    except Exception as ex:
        db.rollback()
        return err(f"خطأ في تسجيل الغياب: {str(ex)}")
    finally:
        db.close()

@app.get("/api/absences/<int:sid>")
@gate_required("G02")
def student_absences(sid):
    db = Session()
    try:
        rows = db.query(Absence).filter(Absence.student_id==sid).order_by(Absence.date.desc()).all()
        return ok([{"id":a.id,"date":str(a.date),"hours":a.hours,"status":a.status} for a in rows])
    finally:
        db.close()

@app.put("/api/absences/<int:abs_id>/justify")
@gate_required("G02")
def justify(abs_id):
    data = request.get_json() or {}
    db = Session()
    try:
        ab = db.query(Absence).filter(Absence.id==abs_id).first()
        if not ab: return err("غير موجود",404)
        ab.status="مبرر"; ab.justification=data.get("justification","")
        db.commit()
        return ok(msg="تم تبرير الغياب")
    finally:
        db.close()

@app.post("/api/absences/notice/<int:sid>")
@gate_required("G03")
def generate_notice(sid):
    data = request.get_json() or {}
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id==sid).first()
        if not s: return err("غير موجود",404)
        notice_type = data.get("notice_type","إشعار_أول")
        notices = db.query(AbsenceNotice).filter(AbsenceNotice.student_id==sid).order_by(AbsenceNotice.issued_date).all()
        ref1 = next((n.issued_date for n in notices if n.notice_type=="إشعار_أول"),None)
        ref2 = next((n.issued_date for n in notices if n.notice_type=="إشعار_ثاني"),None)
        ref3 = next((n.issued_date for n in notices if n.notice_type=="إعذار"),None)
        unexcused = db.query(Absence).filter(Absence.student_id==sid,Absence.status=="غير مبرر").all()
        days = len(set(a.date for a in unexcused))
        div = db.query(Division).filter(Division.id==s.division_id).first()
        content = AbsenceService.build_notice(
            notice_type,{"last_name_ar":s.last_name_ar,"first_name_ar":s.first_name_ar,"division":div.name if div else ""},
            {"name_ar":si.name_ar,"wilaya":si.wilaya,"academic_year":si.academic_year},
            days, date.today(), ref1, ref2, ref3
        )
        n = AbsenceNotice(student_id=sid,notice_type=notice_type,issued_date=date.today(),
                          absence_days=days,ref_notice1_date=ref1,ref_notice2_date=ref2,created_by=g.user_id)
        db.add(n)
        if notice_type == "شطب":
            s.is_expelled = True
            s.expelled_date = date.today()
        db.commit(); db.refresh(n)
        write_audit(g.user_id,f"NOTICE_{notice_type}","notice",n.id)
        return ok({"notice_id":n.id,"document":content})
    finally:
        db.close()

# ════════════════ DAILY ════════════════
@app.post("/api/daily")
@gate_required("G07")
def create_daily():
    data = request.get_json() or {}
    db = Session()
    try:
        if db.query(DailyReport).filter(DailyReport.report_date==_parse_date_field(data.get("report_date"))).first():
            return err("تقرير هذا اليوم موجود بالفعل")
        clean = {k: (_parse_date_field(v) if k=="report_date" else v)
                 for k,v in data.items() if hasattr(DailyReport,k) and k!="id"}
        r = DailyReport(**clean)
        db.add(r); db.commit(); db.refresh(r)
        return ok({"id":r.id},"تم إنشاء التقرير",201)
    except Exception as ex:
        db.rollback()
        return err(f"خطأ في إنشاء التقرير: {str(ex)}")
    finally:
        db.close()

@app.get("/api/daily")
@gate_required("G07")
def list_daily():
    db = Session()
    try:
        rows = db.query(DailyReport).order_by(DailyReport.report_date.desc()).limit(30).all()
        return ok([{"id":r.id,"date":str(r.report_date),"absent":r.total_absent,"pct":r.absence_percentage} for r in rows])
    finally:
        db.close()

@app.get("/api/daily/<report_date>")
@gate_required("G07")
def get_daily(report_date):
    db = Session()
    try:
        r = db.query(DailyReport).filter(DailyReport.report_date==report_date).first()
        if not r: return err("غير موجود",404)
        return ok({"id":r.id,"date":str(r.report_date),"total_registered":r.total_registered,
                   "total_present":r.total_present,"total_absent":r.total_absent,
                   "absence_percentage":r.absence_percentage,"counselor_notes":r.counselor_notes})
    finally:
        db.close()

@app.get("/api/daily/compose/<report_date>")
@gate_required("G07")
def compose_daily(report_date):
    """التقرير اليومي مركَّباً من البيانات الحيّة (بنفس أقسام النموذج الورقي) + مدخلات المستشار المحفوظة."""
    d = _parse_date_field(report_date)
    if not isinstance(d, date):
        return err("تاريخ غير صالح")
    db = Session()
    try:
        return ok(DR.compose(db, SI(db), d))
    finally:
        db.close()

@app.put("/api/daily/<report_date>")
@gate_required("G07")
def save_daily(report_date):
    d = _parse_date_field(report_date)
    if not isinstance(d, date):
        return err("تاريخ غير صالح")
    db = Session()
    try:
        out = DR.save(db, SI(db), d, request.get_json() or {}, g.role, g.user_id)
        write_audit(g.user_id, "DAILY_REPORT_SAVE", "daily_report", out["number"], new=str(d))
        return ok(out, "تم حفظ التقرير اليومي")
    except Exception as ex:
        db.rollback()
        return err(f"تعذّر حفظ التقرير: {ex}")
    finally:
        db.close()

@app.get("/api/calendar/holidays")
@gate_required("G07")
def list_holidays():
    db = Session()
    try:
        return ok([{"id": h.id, "from": str(h.date_from), "to": str(h.date_to), "label": h.label}
                   for h in db.query(SchoolHoliday).order_by(SchoolHoliday.date_from).all()])
    finally:
        db.close()

@app.post("/api/calendar/holidays")
@gate_required("G07")
def add_holiday():
    data = request.get_json() or {}
    a, b = _parse_date_field(data.get("from")), _parse_date_field(data.get("to") or data.get("from"))
    if not isinstance(a, date) or not isinstance(b, date) or b < a:
        return err("تواريخ العطلة غير صالحة")
    db = Session()
    try:
        h = SchoolHoliday(date_from=a, date_to=b, label=str(data.get("label") or "عطلة")[:100])
        db.add(h); db.commit()
        return ok({"id": h.id}, "تمت إضافة العطلة", 201)
    finally:
        db.close()

@app.delete("/api/calendar/holidays/<int:hid>")
@gate_required("G07")
def del_holiday(hid):
    db = Session()
    try:
        db.query(SchoolHoliday).filter(SchoolHoliday.id == hid).delete()
        db.commit()
        return ok(None, "تم الحذف")
    finally:
        db.close()

# ════════════════ DOCUMENTS ════════════════
def _doc_page(title, body_html, landscape=False, si=None):
    """قالب HTML موحّد للوثائق الإدارية القابلة للطباعة (A4 عمودي) بترويسة الجمهورية / وزارة التربية الوطنية /
    المديرية / المؤسسة، مع «الرقم» و«المكان والتاريخ». إن طُلب ?layout=a5x2 (ولم تكن الوثيقة أفقية)
    تُطبع نسختان بمقاس A5 جنباً إلى جنب في ورقة A4 واحدة (أفقية) تُقصّ إلى نصفين."""
    wilaya = si.wilaya if si else cfg.WILAYA
    school_name = si.name_ar if si else cfg.SCHOOL_NAME
    academic_year = si.academic_year if si else cfg.ACADEMIC_YEAR
    commune = (getattr(si, "commune", "") or wilaya or "") if si else (wilaya or "")
    today = date.today().strftime("%Y/%m/%d")
    x2 = (request.args.get("layout", "") == "a5x2") and not landscape
    orient = "landscape" if (landscape or x2) else "portrait"
    margin = "8mm" if x2 else "14mm"
    head = f"""<div class="hdr"><div>الجمهورية الجزائرية الديمقراطية الشعبية<br>وزارة التربية الوطنية</div></div>
<div class="hdr2">
  <div>مديرية التربية لولاية {wilaya}<br>{school_name}<br><span class="doc-no">الرقم: ........ / {academic_year.split('/')[-1] if academic_year else ''}</span></div>
  <div style="text-align:left">{commune} في: {today}<br><span class="doc-no">السنة الدراسية: {academic_year}</span></div>
</div>"""
    page = f"{head}{body_html}"
    if x2:
        page = f'<div class="x2"><div class="cp">{page}</div><div class="cp">{page}</div></div>'
    return f"""<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8">
<title>{title}</title>
<style>
  @page {{ size: A4 {orient}; margin: {margin}; }}
  * {{ box-sizing: border-box; }}
  body {{ font-family: 'Traditional Arabic','Arial',sans-serif; font-size: 14px; color:#111; direction: rtl; }}
  .hdr {{ display:flex; justify-content:space-between; text-align:center; font-weight:bold; margin-bottom: 6px; }}
  .hdr div {{ flex:1; font-size: 13px; line-height:1.6; }}
  .hdr2 {{ display:flex; justify-content:space-between; margin: 10px 0 16px; font-size:13px; line-height:1.7; }}
  .title {{ text-align:center; font-size:20px; font-weight:bold; margin: 14px 0; text-decoration: underline; }}
  table {{ width:100%; border-collapse: collapse; margin: 10px 0; }}
  th, td {{ border: 1px solid #333; padding: 5px 8px; text-align:center; font-size:12.5px; }}
  th {{ background:#f0f0f0; }}
  .sign {{ display:flex; justify-content:space-between; margin-top: 40px; }}
  .doc-no {{ font-size:11px; color:#555; }}
  .btnbar {{ text-align:center; margin-bottom:10px; }}
  .x2 {{ display:flex; align-items:stretch; }}
  .x2 .cp {{ width:50%; padding:0 5mm; zoom:.8; }}
  .x2 .cp + .cp {{ border-right:.3mm dashed #777; }}
  @media print {{ .btnbar {{ display:none; }} }}
</style></head>
<body>
<div class="btnbar"><button onclick="window.print()">🖨️ طباعة</button></div>
{page}
</body></html>"""

@app.get("/api/documents/certificate/<int:sid>")
@gate_required("G06")
def print_certificate(sid):
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id==sid).first()
        if not s: return Response("التلميذ غير موجود", mimetype="text/html")
        div = db.query(Division).filter(Division.id==s.division_id).first()
        level_director = level_label(si, "director")
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type=="school_cert").count()+1
        doc_num = DocNumberService.gen("school_cert", si.school_code or "00000", seq)
        db.add(OfficialDocument(doc_type="school_cert", doc_number=doc_num, student_id=sid,
                                issued_date=date.today(),
                                content_json=json.dumps({"last":s.last_name_ar,"first":s.first_name_ar}, ensure_ascii=False),
                                issued_by=g.user_id))
        db.commit()
        body = f"""
        <div class="doc-no">رقم: {doc_num}</div>
        <div class="title">شهادة مدرسية</div>
        <p style="line-height:2.4; font-size:15px; margin-top:30px">
        يشهد السيد(ة) {level_director} أن التلميذ(ة):<br>
        <b>اللقب:</b> {s.last_name_ar} &nbsp;&nbsp; <b>الاسم:</b> {s.first_name_ar}<br>
        <b>تاريخ ومكان الازدياد:</b> {s.birth_date or ''} بـ: {s.birth_place or ''}<br><br>
        <b>يتابع دراسته</b><br><br>
        <b>السنة الدراسية:</b> {si.academic_year} &nbsp;&nbsp; <b>القسم:</b> {div.name if div else ''}<br>
        <b>رقم التسجيل:</b> {s.registration_num or ''}<br><br>
        حرر بـ {si.commune or si.wilaya} في: {date.today().strftime('%Y-%m-%d')}
        </p>
        <div class="sign" style="justify-content:flex-end"><div>{level_director}<br>{si.director_name or ''}</div></div>
        <p style="font-size:11px;margin-top:40px">لا تسلم إلا نسخة واحدة من هذه الشهادة</p>
        """
        return Response(_doc_page("شهادة مدرسية", body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/documents/absence-notice/<int:sid>")
@gate_required("G03")
def print_absence_notice(sid):
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id==sid).first()
        if not s: return Response("التلميذ غير موجود", mimetype="text/html")
        div = db.query(Division).filter(Division.id==s.division_id).first()
        level_director = level_label(si, "director")
        n = db.query(AbsenceNotice).filter(AbsenceNotice.student_id==sid).order_by(AbsenceNotice.issued_date.desc()).first()
        if not n:
            return Response(_doc_page("إشعار", "<p style='text-align:center'>لا يوجد إشعار مسجّل لهذا التلميذ بعد.</p>", si=si), mimetype="text/html")
        ref1 = next((x.issued_date for x in db.query(AbsenceNotice).filter(AbsenceNotice.student_id==sid,AbsenceNotice.notice_type=="إشعار_أول")),None)
        ref2 = next((x.issued_date for x in db.query(AbsenceNotice).filter(AbsenceNotice.student_id==sid,AbsenceNotice.notice_type=="إشعار_ثاني")),None)
        ref3 = next((x.issued_date for x in db.query(AbsenceNotice).filter(AbsenceNotice.student_id==sid,AbsenceNotice.notice_type=="إعذار")),None)
        content = AbsenceService.build_notice(
            n.notice_type, {"last_name_ar":s.last_name_ar,"first_name_ar":s.first_name_ar,"division":div.name if div else ""},
            {"name_ar":si.name_ar,"wilaya":si.wilaya,"academic_year":si.academic_year},
            n.absence_days or 0, n.issued_date, ref1, ref2, ref3)
        body = f"""
        <div class="title">{content.get('subject','إشعار')}</div>
        <p style="line-height:2.2; font-size:14px; white-space:pre-line">{content.get('body','')}</p>
        <p style="font-size:11px;color:#444;line-height:1.8;margin-top:14px">{content.get('legal_ref','')}</p>
        <div class="sign" style="justify-content:flex-end"><div>{level_director}<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page(content.get('subject','إشعار'), body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/documents/daily-report/<rdate>")
@gate_required("G07")
def print_daily_report(rdate):
    """طباعة التقرير اليومي لمستشار التربية بنفس شكل النموذج المعتمد (صفحتان A4):
    الدراسة، المواظبة بالأفواج، حركة التلاميذ، الإطعام، الحوصلة، الغائبون، الملاحظات."""
    db = Session()
    try:
        si = SI(db)
        d = _parse_date_field(rdate)
        if not isinstance(d, date):
            return Response("تاريخ غير صالح", status=400, mimetype="text/html")
        return Response(DR.render_html(DR.compose(db, si, d), si), mimetype="text/html")
    finally:
        db.close()

def _simple_table_page(title, si, body):
    return Response(_doc_page(title, body, landscape=True, si=si), mimetype="text/html")

@app.get("/api/documents/movement-register")
@gate_required("G07")
def print_movement_register():
    """سجل الوافدين والمغادرين (تلاميذ دخلوا المؤسسة / غادروها) خلال فترة (افتراضياً السنة الدراسية الجارية)."""
    db = Session()
    try:
        si = SI(db)
        today = date.today()
        y = today.year if today.month >= 9 else today.year - 1
        a = _parse_date_field(request.args.get("from")) or date(y, 9, 1)
        b = _parse_date_field(request.args.get("to")) or today
        divs = {d.id: d.name for d in db.query(Division).all()}
        lv = {1: "أولى", 2: "ثانية", 3: "ثالثة", 4: "رابعة"}
        def row(i, s, extra):
            dv = db.query(Division).filter(Division.id == s.division_id).first()
            return (f"<tr><td>{i}</td><td>{s.registration_num or ''}</td><td>{s.last_name_ar}</td><td>{s.first_name_ar}</td>"
                    f"<td>{s.birth_date or ''}</td><td>{s.father_name or ''}</td><td>{lv.get(dv.level, '') if dv else ''}</td>"
                    f"<td>{divs.get(s.division_id, '')}</td>{extra}</tr>")
        arr = (db.query(Student).filter(Student.entry_date >= a, Student.entry_date <= b)
               .order_by(Student.entry_date, Student.last_name_ar).all())
        lea = (db.query(Student).filter(Student.is_expelled == True, Student.expelled_date >= a, Student.expelled_date <= b)
               .order_by(Student.expelled_date, Student.last_name_ar).all())
        r1 = "".join(row(i, s, f"<td>{s.entry_date}</td><td>{s.origin_school or ''}</td>") for i, s in enumerate(arr, 1)) \
            or "<tr><td colspan='10'>لا وافدون في هذه الفترة</td></tr>"
        r2 = "".join(row(i, s, f"<td>{s.expelled_date}</td><td>{s.exit_note or ''}</td>") for i, s in enumerate(lea, 1)) \
            or "<tr><td colspan='10'>لا مغادرون في هذه الفترة</td></tr>"
        head = "<th>الرقم</th><th>رقم التسجيل</th><th>اللقب</th><th>الاسم</th><th>تاريخ الميلاد</th><th>الأب</th><th>المستوى</th><th>القسم</th>"
        body = f"""<div class="title">سجل الوافدين والمغادرين</div>
        <p style="text-align:center">من {a} إلى {b} — السنة الدراسية {si.academic_year}</p>
        <h3>التلاميذ الوافدون ({len(arr)})</h3>
        <table><thead><tr>{head}<th>تاريخ الدخول</th><th>المؤسسة الأصلية</th></tr></thead><tbody>{r1}</tbody></table>
        <h3>التلاميذ المغادرون ({len(lea)})</h3>
        <table><thead><tr>{head}<th>تاريخ الخروج</th><th>الوجهة / السبب</th></tr></thead><tbody>{r2}</tbody></table>
        <div class="sign"><div>مستشار التربية<br>{si.counselor_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>"""
        return _simple_table_page("سجل الوافدين والمغادرين", si, body)
    finally:
        db.close()

@app.get("/api/documents/daily-summary/<ym>")
@gate_required("G07")
def print_daily_summary(ym):
    """الملخص الشهري للتقارير اليومية المحفوظة (YYYY-MM): غياب التلاميذ، ساعات غياب الأساتذة، الإطعام."""
    db = Session()
    try:
        si = SI(db)
        try:
            y, m = [int(x) for x in ym.split("-")[:2]]
            a = date(y, m, 1)
            b = date(y + (m == 12), (m % 12) + 1, 1)
        except Exception:
            return Response("الشهر غير صالح (YYYY-MM)", status=400, mimetype="text/html")
        reps = (db.query(DailyReport).filter(DailyReport.report_date >= a, DailyReport.report_date < b)
                .order_by(DailyReport.report_date).all())
        wd = ["الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"]
        rows = ""
        for r in reps:
            rows += (f"<tr><td>{str(r.report_number or '').zfill(3)}</td><td>{wd[r.report_date.weekday()]} {r.report_date}</td>"
                     f"<td>{r.total_registered or 0}</td><td>{r.total_absent or 0}</td><td>{r.absence_percentage or 0}%</td>"
                     f"<td>{r.total_absence_hours or 0}</td><td>{(r.canteen_pres_m or 0) + (r.canteen_pres_f or 0)}</td></tr>")
        n = len(reps) or 1
        avg_abs = round(sum((r.total_absent or 0) for r in reps) / n, 1)
        avg_pct = round(sum((r.absence_percentage or 0) for r in reps) / n, 2)
        tot_h = sum((r.total_absence_hours or 0) for r in reps)
        rows = rows or "<tr><td colspan='7'>لا تقارير محفوظة في هذا الشهر</td></tr>"
        body = f"""<div class="title">الملخص الشهري للتقارير اليومية — {ym}</div>
        <table><thead><tr><th>رقم التقرير</th><th>اليوم</th><th>المسجلون</th><th>غياب التلاميذ</th><th>النسبة</th>
        <th>ساعات غياب الأساتذة</th><th>حاضرو المطعم</th></tr></thead><tbody>{rows}
        <tr><td colspan="3"><b>المتوسط اليومي ({len(reps)} تقرير)</b></td><td><b>{avg_abs}</b></td><td><b>{avg_pct}%</b></td><td><b>{tot_h}</b></td><td></td></tr></tbody></table>
        <div class="sign"><div>مستشار التربية<br>{si.counselor_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>"""
        return Response(_doc_page("الملخص الشهري للتقارير اليومية", body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/documents/list/<int:div_id>")
@gate_required("G06")
def print_class_list(div_id):
    db = Session()
    try:
        si = SI(db)
        div = db.query(Division).filter(Division.id==div_id).first()
        if not div: return Response("القسم غير موجود", mimetype="text/html")
        students = db.query(Student).filter(Student.division_id==div_id, Student.is_active==True).order_by(Student.last_name_ar, Student.first_name_ar).all()
        rows = "".join(
            f"<tr><td>{i+1}</td><td>{s.registration_num or ''}</td><td>{s.national_id or ''}</td>"
            f"<td>{s.last_name_ar} {s.first_name_ar}</td><td>{s.birth_date or ''}</td><td>{s.gender}</td>"
            f"<td>{'نعم' if s.is_repeating else 'لا'}</td><td>{s.status}</td></tr>"
            for i, s in enumerate(students)
        ) or "<tr><td colspan='8'>لا يوجد تلاميذ في هذا القسم</td></tr>"
        def _c(pred):
            m_ = sum(1 for x in students if pred(x) and x.gender == "ذكر")
            t_ = sum(1 for x in students if pred(x))
            return m_, t_ - m_, t_
        n_m, n_f, n_t = _c(lambda x: not x.is_repeating)
        r_m, r_f, r_t = _c(lambda x: bool(x.is_repeating))
        a_m, a_f, a_t = _c(lambda x: True)
        e_m, e_f, e_t = _c(lambda x: x.status not in ("داخلي", "نصف داخلي"))
        h_m, h_f, h_t = _c(lambda x: x.status == "نصف داخلي")
        i_m, i_f, i_t = _c(lambda x: x.status == "داخلي")
        body = f"""
        <div class="title">قوائم تلاميذ قسم: {div.name}</div>
        <table><thead><tr><th>الرقم</th><th>ر.ت</th><th>الرقم الوطني</th><th>اللقب و الاسم</th>
        <th>تاريخ الميلاد</th><th>الجنس</th><th>الإعادة</th><th>الصفة</th></tr></thead>
        <tbody>{rows}</tbody></table>
        <table style="margin-top:18px;page-break-inside:avoid"><thead>
        <tr><th rowspan="2">الإحصاء</th><th colspan="3">جدد</th><th colspan="3">معيدون</th><th colspan="3">المجموع</th>
        <th colspan="3">خارجي</th><th colspan="3">نصف داخلي</th><th colspan="3">داخلي</th></tr>
        <tr>{"<th>ذكور</th><th>إناث</th><th>مج</th>"*6}</tr></thead>
        <tbody><tr><td><b>{div.name}</b></td>
        <td>{n_m}</td><td>{n_f}</td><td>{n_t}</td><td>{r_m}</td><td>{r_f}</td><td>{r_t}</td>
        <td>{a_m}</td><td>{a_f}</td><td><b>{a_t}</b></td>
        <td>{e_m}</td><td>{e_f}</td><td>{e_t}</td><td>{h_m}</td><td>{h_f}</td><td>{h_t}</td><td>{i_m}</td><td>{i_f}</td><td>{i_t}</td></tr></tbody></table>
        <div class="sign"><div>مستشار التربية<br>{si.counselor_name or ''}</div><div>الناظر<br>{si.nazir_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page(f"قائمة {div.name}", body, landscape=True, si=si), mimetype="text/html")
    finally:
        db.close()

@app.post("/api/documents/school-certificate/<int:sid>")
@gate_required("G06")
def school_certificate(sid):
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id==sid).first()
        if not s: return err("غير موجود",404)
        div = db.query(Division).filter(Division.id==s.division_id).first()
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type=="school_cert").count()+1
        doc_num = DocNumberService.gen("school_cert", si.school_code or "00000", seq)
        content = {"doc_number":doc_num,"school_name":si.name_ar,"wilaya":si.wilaya,
                   "academic_year":si.academic_year,"student_last":s.last_name_ar,
                   "student_first":s.first_name_ar,"birth_date":str(s.birth_date) if s.birth_date else "",
                   "birth_place":s.birth_place or "","division":div.name if div else "",
                   "registration_num":s.registration_num or "","issued_date":str(date.today()),
                   "text":(f"يشهد السيد(ة) {level_label(si,'director')} {si.name_ar} أن التلميذ(ة):\n"
                           f"اللقب: {s.last_name_ar}    الاسم: {s.first_name_ar}\n"
                           f"تاريخ ومكان الازدياد: {s.birth_date or ''} بـ: {s.birth_place or ''}\n"
                           f"يتابع دراسته — السنة الدراسية: {si.academic_year}\n"
                           f"القسم: {div.name if div else ''}    رقم التسجيل: {s.registration_num or ''}\nإلى يومنا هذا")}
        doc = OfficialDocument(doc_type="school_cert",doc_number=doc_num,student_id=sid,
                               issued_date=date.today(),content_json=json.dumps(content,ensure_ascii=False),issued_by=g.user_id)
        db.add(doc); db.commit()
        return ok({"doc_number":doc_num,"content":content})
    finally:
        db.close()

@app.get("/api/documents/student/<int:sid>")
@gate_required("G06")
def student_docs(sid):
    db = Session()
    try:
        docs = db.query(OfficialDocument).filter(OfficialDocument.student_id==sid).order_by(OfficialDocument.issued_date.desc()).all()
        return ok([{"id":d.id,"type":d.doc_type,"number":d.doc_number,"date":str(d.issued_date)} for d in docs])
    finally:
        db.close()

@app.post("/api/documents/id-card/<int:sid>")
@gate_required("G06")
def generate_id_card(sid):
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id==sid).first()
        if not s: return err("غير موجود",404)
        if not s.registration_num:
            return err("لا يملك التلميذ رقم تسجيل — يرجى إدخاله أولاً")
        div = db.query(Division).filter(Division.id==s.division_id).first()
        qr_b64 = ""
        try:
            import qrcode, io, base64
            img = qrcode.make(s.registration_num)
            buf = io.BytesIO(); img.save(buf, format="PNG")
            qr_b64 = base64.b64encode(buf.getvalue()).decode()
        except Exception:
            pass
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type=="id_card").count()+1
        doc_num = DocNumberService.gen("id_card",si.school_code or "00000",seq)
        content = {"doc_number":doc_num,"school_name":si.name_ar,"academic_year":si.academic_year,
                   "last_name":s.last_name_ar,"first_name":s.first_name_ar,
                   "birth_date":str(s.birth_date) if s.birth_date else "","birth_place":s.birth_place or "",
                   "division":div.name if div else "","registration_num":s.registration_num,
                   "photo_path":s.photo_path or "",
                   "qr_base64":qr_b64}
        stored = {k:v for k,v in content.items() if k != "qr_base64"}
        doc = OfficialDocument(doc_type="id_card",doc_number=doc_num,student_id=sid,
                               issued_date=date.today(),content_json=json.dumps(stored,ensure_ascii=False),
                               issued_by=g.user_id)
        db.add(doc); db.commit()
        write_audit(g.user_id,"ID_CARD","student",sid)
        return ok({"doc_number":doc_num,"content":content})
    finally:
        db.close()

@app.post("/api/documents/parent-summon/<int:sid>")
@gate_required("G13")
def parent_summon(sid):
    data = request.get_json() or {}
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id==sid).first()
        if not s: return err("غير موجود",404)
        div = db.query(Division).filter(Division.id==s.division_id).first()
        content = DisciplineService.build_summon(
            {"last_name_ar":s.last_name_ar,"first_name_ar":s.first_name_ar,"division":div.name if div else ""},
            {"name_ar":si.name_ar,"wilaya":si.wilaya,"academic_year":si.academic_year},
            date.today(), data.get("reason",""), data.get("meeting_time","")
        )
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type=="parent_invite").count()+1
        doc_num = DocNumberService.gen("parent_invite",si.school_code or "00000",seq)
        content["doc_number"]=doc_num
        doc = OfficialDocument(doc_type="parent_invite",doc_number=doc_num,student_id=sid,
                               issued_date=date.today(),content_json=json.dumps(content,ensure_ascii=False),
                               issued_by=g.user_id)
        db.add(doc); db.commit()
        write_audit(g.user_id,"PARENT_SUMMON","student",sid)
        return ok({"doc_number":doc_num,"content":content})
    finally:
        db.close()

# ════════════════ DISCIPLINE ════════════════
@app.post("/api/discipline")
@gate_required("G14")
def create_discipline():
    data = request.get_json() or {}
    db = Session()
    try:
        sid = data.get("student_id")
        s = db.query(Student).filter(Student.id==sid).first()
        if not s: return err("التلميذ غير موجود",404)
        rec = DisciplineRecord(student_id=sid, date=_parse_date_field(data.get("date")) or date.today(),
                                violation_type=data.get("violation_type",""),
                                description=data.get("description",""),
                                sanction_type=data.get("sanction_type",""),
                                reported_by=g.user_id)
        db.add(rec); db.commit(); db.refresh(rec)
        write_audit(g.user_id,"CREATE_DISCIPLINE","discipline",rec.id)
        return ok({"id":rec.id},"تم تسجيل المخالفة",201)
    finally:
        db.close()

@app.get("/api/discipline/<int:sid>")
@gate_required("G14")
def list_discipline(sid):
    db = Session()
    try:
        rows = db.query(DisciplineRecord).filter(DisciplineRecord.student_id==sid).order_by(DisciplineRecord.date.desc()).all()
        return ok([{"id":r.id,"date":str(r.date),"violation":r.violation_type,
                     "description":r.description,"sanction":r.sanction_type,
                     "parent_notified":r.parent_notified} for r in rows])
    finally:
        db.close()

@app.post("/api/discipline/<int:rec_id>/notice")
@gate_required("G14")
def discipline_notice(rec_id):
    db = Session()
    try:
        si = SI(db)
        rec = db.query(DisciplineRecord).filter(DisciplineRecord.id==rec_id).first()
        if not rec: return err("غير موجود",404)
        s = db.query(Student).filter(Student.id==rec.student_id).first()
        div = db.query(Division).filter(Division.id==s.division_id).first()
        violation_readable = "، ".join(
            VIOLATION_LABELS.get(v.strip(), v.strip()) for v in (rec.violation_type or "").split(",") if v.strip()
        ) or rec.violation_type
        content = DisciplineService.build_sanction_notice(
            {"last_name_ar":s.last_name_ar,"first_name_ar":s.first_name_ar,"division":div.name if div else ""},
            {"name_ar":si.name_ar,"wilaya":si.wilaya,"academic_year":si.academic_year},
            date.today(), violation_readable, rec.sanction_type
        )
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type=="discipline").count()+1
        doc_num = DocNumberService.gen("discipline",si.school_code or "00000",seq)
        content["doc_number"]=doc_num
        doc = OfficialDocument(doc_type="discipline",doc_number=doc_num,student_id=s.id,
                               issued_date=date.today(),content_json=json.dumps(content,ensure_ascii=False),
                               issued_by=g.user_id)
        rec.parent_notified = True
        db.add(doc); db.commit(); db.refresh(doc)
        write_audit(g.user_id,"DISCIPLINE_NOTICE","discipline",rec_id)
        return ok({"doc_number":doc_num,"content":content,"doc_id":doc.id})
    finally:
        db.close()

VIOLATION_LABELS = {
    "تهجم_استاذ": "تهجم على أستاذ", "اعتداء_زملاء": "الاعتداء على زملائه",
    "فوضى_قسم": "إثارة الفوضى داخل القسم", "عدم_كتابة_دروس": "عدم كتابة الدروس",
    "استعمال_هاتف": "استعمال الهاتف النقال", "ملابس_غير_لائقة": "ارتداء ملابس غير لائقة",
    "غيابات_متكررة": "غيابات متكررة غير مبررة", "تأخرات_متكررة": "تأخرات متكررة غير مبررة",
}

@app.get("/api/documents/discipline-report/print/<int:rec_id>")
@gate_required("G14")
def print_discipline_report(rec_id):
    """طباعة نموذج «تقرير بتلميذ» الرسمي — يطابق نموذج الوزارة (القرار 65 لسنة 2018، المادتان 39 و85)."""
    db = Session()
    try:
        si = SI(db)
        rec = db.query(DisciplineRecord).filter(DisciplineRecord.id == rec_id).first()
        if not rec: return Response("غير موجود", mimetype="text/html")
        s = db.query(Student).filter(Student.id == rec.student_id).first()
        div = db.query(Division).filter(Division.id == s.division_id).first() if s else None
        violations = [v.strip() for v in (rec.violation_type or "").split(",") if v.strip()]
        boxes = "".join(
            f"<label style='display:flex;gap:6px;align-items:center;font-size:12px;margin:4px 0'>"
            f"<input type='checkbox' {'checked' if code in violations or label in violations else ''} disabled> {label}</label>"
            for code, label in VIOLATION_LABELS.items()
        )
        body = f"""
        <div class="title">تقرير بتلميذ</div>
        <p style="font-size:12px;line-height:1.9">
        طبقاً للقرار الوزاري 65 المؤرخ في 2018/07/12 الصادر عن وزارة التربية الخاص بالأحكام الخاصة بالتلميذ:<br>
        المادة 39: يمنع إخراج التلميذ من حجرة الدراسة إلا في الحالات الضرورية القصوى والمبررة.<br>
        المادة 85: يمنع إخراج التلميذ من القسم أو حرمانه من الدرس إلا في الحالات القصوى إلا بتقرير مكتوب ومبرر يقدمه الأستاذ المعني للمدير.
        </p>
        <p><b>أصرح بأنني قدمت هذا التقرير بالتلميذ(ة):</b> {s.last_name_ar if s else ''} {s.first_name_ar if s else ''}
        &nbsp;&nbsp; <b>القسم:</b> {div.name if div else ''} &nbsp;&nbsp; <b>التاريخ:</b> {rec.date}</p>
        <div style="margin:14px 0"><b>لقيامه بالمخالفات التالية:</b><br>{boxes}</div>
        <p><b>ملاحظات أخرى:</b> {rec.description or '—'}</p>
        <p><b>العقوبة المقترحة:</b> {rec.sanction_type or '—'}</p>
        <div class="sign"><div>مستشار التربية<br>{si.counselor_name or ''}</div><div>الناظر<br>{si.nazir_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("تقرير بتلميذ", body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/documents/discipline-notice/print/<int:doc_id>")
@gate_required("G14")
def print_discipline_notice(doc_id):
    db = Session()
    try:
        si = SI(db)
        d = db.query(OfficialDocument).filter(OfficialDocument.id == doc_id, OfficialDocument.doc_type == "discipline").first()
        if not d: return Response("غير موجود", mimetype="text/html")
        c = json.loads(d.content_json or "{}")
        body = f"""
        <div class="doc-no">رقم: {c.get('doc_number','')}</div>
        <div class="title">{c.get('subject','')}</div>
        <p style="font-size:11px;line-height:1.9">{c.get('legal_ref','')}</p>
        <p style="margin-top:16px">إلى ولي التلميذ(ة): <b>{c.get('student_name','')}</b> — القسم: {c.get('division','')}</p>
        <p style="line-height:2.2;white-space:pre-line;margin-top:10px">{c.get('body','')}</p>
        <p style="font-size:11px;margin-top:16px">وفي حالة تكرار مثل هذه السلوكيات سوف يتعرض ابنتكم/ابنكم إلى المثول أمام مجلس التأديب لاتخاذ الإجراءات الأشد صرامة.</p>
        <div class="sign" style="justify-content:flex-end"><div>{level_label(si,'director')}<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page(c.get('subject','إشعار عقوبة'), body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/documents/info-form/<int:sid>")
@gate_required("G06")
def print_info_form(sid):
    """استمارة معلومات التلميذ — تطابق نموذج الوزارة."""
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id == sid).first()
        if not s: return Response("غير موجود", mimetype="text/html")
        div = db.query(Division).filter(Division.id == s.division_id).first()
        def yn(v): return "نعم" if v else "لا"
        body = f"""
        <div class="title">استمارة معلومات التلميذ</div>
        <table style="width:100%"><tbody>
        <tr><td><b>اللقب:</b> {s.last_name_ar}</td><td><b>الاسم:</b> {s.first_name_ar}</td></tr>
        <tr><td><b>nom:</b> {s.last_name_fr or ''}</td><td><b>prenom:</b> {s.first_name_fr or ''}</td></tr>
        <tr><td colspan="2"><b>تاريخ ومكان الازدياد:</b> {s.birth_date or ''} بـ: {s.birth_place or ''}</td></tr>
        <tr><td><b>الجنس:</b> {s.gender}</td><td><b>القسم:</b> {div.name if div else ''}</td></tr>
        <tr><td><b>الصفة:</b> {s.status}</td><td><b>معيد:</b> {yn(s.is_repeating)}</td></tr>
        <tr><td><b>اسم الأب:</b> {s.father_name or ''}</td><td><b>لقب واسم الأم:</b> {s.mother_name or ''}</td></tr>
        <tr><td><b>عدد الإخوة:</b> {s.siblings_count or 0}</td><td><b>منهم إناث:</b> {s.siblings_female or 0}</td></tr>
        <tr><td><b>يتيم(ة):</b> {yn(s.is_orphan)}</td><td><b>حالة انفصال الوالدين:</b> {yn(s.parents_separated)}</td></tr>
        <tr><td colspan="2"><b>العنوان الشخصي للولي:</b> {s.guardian_address or ''}</td></tr>
        <tr><td><b>رقم هاتف الولي:</b> {s.guardian_phone or ''}</td><td><b>Email:</b> {s.guardian_email or ''}</td></tr>
        <tr><td><b>الإعاقة:</b> {yn(s.has_disability)}</td><td><b>نوع الإعاقة:</b> {s.disability_type or 'لا شيء'}</td></tr>
        </tbody></table>
        <p style="font-size:11px;margin-top:20px">لا تسلم إلا نسخة واحدة من هذه الاستمارة</p>
        <div class="sign" style="justify-content:flex-end"><div>{level_label(si,'director')}<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("استمارة معلومات التلميذ", body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/documents/parent-pledge/<int:sid>")
@gate_required("G06")
def print_parent_pledge(sid):
    """تعهد ولي التلميذ — نموذج شبه فارغ يُملأ يدوياً بعد الطباعة (كما هو معمول به فعلياً)."""
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id == sid).first()
        if not s: return Response("غير موجود", mimetype="text/html")
        div = db.query(Division).filter(Division.id == s.division_id).first()
        body = f"""
        <div class="title">تعهد ولي التلميذ(ة)</div>
        <p style="line-height:2.4;font-size:13px">
        أنا الممضي أسفله السيد(ة): .............................................. ولد(ة) بتاريخ: ..................<br>
        صاحب(ة) بطاقة التعريف الوطنية / رخصة السياقة رقم: .............................. الصادرة بتاريخ: ..................<br>
        عن: .......................................... الساكن(ة) بـ: ..........................................................<br><br>
        أب - أم - وصي التلميذ(ة): <b>{s.last_name_ar} {s.first_name_ar}</b> المولود(ة) بتاريخ: {s.birth_date or '..................'}<br>
        المسجل(ة) بالقسم: <b>{div.name if div else ''}</b> للموسم الدراسي: {si.academic_year}<br><br>
        أعترف أنني حضرت إلى المؤسسة يوم: .................................................... واطلعت على مخالفة ابني:<br>
        ..........................................................................................................................<br>
        ..........................................................................................................................<br><br>
        وأتعهد من جهتي بالإلزام على إبني/إبنتي باحترام القانون الداخلي للمؤسسة (القرار رقم 65 المؤرخ في 12 جويلية 2018)
        ومن جهة أتقبل أي قرار يُتخذ ضده(ها) في إطار القوانين السارية المفعول في حالة تكرار المخالفة.
        </p>
        <div class="sign"><div>توقيع الولي</div><div>توقيع التلميذ(ة)</div></div>
        <div class="sign" style="justify-content:flex-end;margin-top:20px"><div>{level_label(si,'director')}<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("تعهد ولي التلميذ", body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/documents/parent-permission/<int:sid>")
@gate_required("G06")
def print_parent_permission(sid):
    """رخصة أبوية — تسمح لولي الأمر بالتوقيع للسماح لابنه بالمشاركة في نشاط/خرجة معيّنة."""
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id == sid).first()
        if not s: return Response("غير موجود", mimetype="text/html")
        div = db.query(Division).filter(Division.id == s.division_id).first()
        activity = request.args.get("activity", "")
        body = f"""
        <div class="title">رخصة أبوية</div>
        <p style="line-height:2.4;font-size:13px">
        أنا الممضي أسفله السيد: .................................................... المولود بتاريخ: ..................<br>
        الحامل لبطاقة التعريف الوطنية رقم: ................................ الصادرة بتاريخ: ....................<br>
        عن: ................................................<br><br>
        أرخص لابنتي/لابني: <b>{s.last_name_ar} {s.first_name_ar}</b> المولود(ة) بتاريخ: {s.birth_date or '..................'}<br>
        القسم: {div.name if div else ''} &nbsp;&nbsp; ر.ت: {s.registration_num or ''}<br>
        للمشاركة في: {activity or '..............................................................'}<br>
        تحت إشراف: ..............................................................<br>
        </p>
        <div class="sign" style="justify-content:flex-end"><div>إمضاء الولي</div></div>
        <p style="font-size:11px;margin-top:14px">مصادقة مصالح البلدية: ....................................</p>
        """
        return Response(_doc_page("رخصة أبوية", body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/reports/division-representatives")
@gate_required("G12")
def report_division_representatives():
    """قائمة مسؤولي ومندوبي الأقسام — تُطبع فارغة لتعبأتها يدوياً في اجتماع بداية السنة."""
    db = Session()
    try:
        si = SI(db)
        divs = _sort_divs(db.query(Division).filter(Division.is_active == True).all())
        rows = "".join(
            f"<tr><td>{d.name}</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>"
            for d in divs
        ) or "<tr><td colspan='4'>لا توجد أقسام</td></tr>"
        body = f"""
        <div class="title">قائمة مسؤولي ومندوبي الأقسام — {si.academic_year}</div>
        <table><thead><tr><th>القسم</th><th>الأستاذ المسؤول</th><th>مندوب القسم</th><th>النائب الأول</th></tr></thead>
        <tbody>{rows}</tbody></table>
        <div class="sign" style="justify-content:flex-end;margin-top:24px"><div>{level_label(si,'director')}<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("قائمة مسؤولي الأقسام", body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/reports/october-status")
@gate_required("G12")
def report_october_status():
    """حالة أول أكتوبر — قائمة التلاميذ الذين غادروا/شُطبوا من القوائم منذ 1 أكتوبر من الموسم الحالي."""
    db = Session()
    try:
        si = SI(db)
        try:
            oct1 = date(int(si.academic_year.split("/")[0]), 10, 1)
        except Exception:
            oct1 = date(date.today().year, 10, 1)
        left = (db.query(Student)
                .filter(Student.is_active == False, Student.updated_at >= datetime.combine(oct1, datetime.min.time()))
                .order_by(Student.last_name_ar).all())
        rows = "".join(
            f"<tr><td>{i+1}</td><td>{s.registration_num or ''}</td><td>{s.last_name_ar} {s.first_name_ar}</td>"
            f"<td>{s.birth_date or ''}</td><td>{s.birth_place or ''}</td>"
            f"<td>{(s.division.name if s.division else '')}</td></tr>"
            for i, s in enumerate(left)
        )
        closed_note = (f"أُغلقت هذه الحالة عند التلميذ من قسم تحت رقم تسجيل: {left[-1].registration_num or 0}"
                        if left else "أُغلقت هذه الحالة عند التلميذ من قسم تحت رقم تسجيل: 0")
        table = (f"<table><thead><tr><th>الرقم</th><th>ر.التسجيل</th><th>اللقب والاسم</th>"
                 f"<th>تاريخ الميلاد</th><th>مكان الميلاد</th><th>القسم</th></tr></thead><tbody>{rows}</tbody></table>"
                 if left else f"<table><thead><tr><th>العنوان</th><th>الولي</th><th>الجنس</th><th>الصفة</th>"
                 f"<th>القسم</th><th>مكان الميلاد</th><th>تاريخ الميلاد</th><th>اللقب والاسم</th><th>ر.التسجيل</th></tr></thead>"
                 f"<tbody><tr><td colspan='9'>{closed_note}</td></tr></tbody></table>")
        body = f"""
        <div class="title">حالة أول أكتوبر — {si.academic_year}</div>
        {table}
        <div class="sign"><div>المسير المالي<br>{si.bursar_name or ''}</div><div>الناظر<br>{si.nazir_name or ''}</div>
        <div>مستشار التربية<br>{si.counselor_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("حالة أول أكتوبر", body, si=si), mimetype="text/html")
    finally:
        db.close()

# ════════════════ LOCATION TRACKING (مبدأ تتبع الحجاج) ════════════════
def _scan_out(scan, db):
    s = db.query(Student).filter(Student.id==scan.student_id).first()
    cp = db.query(CheckPoint).filter(CheckPoint.id==scan.checkpoint_id).first()
    div = db.query(Division).filter(Division.id==s.division_id).first() if s else None
    return {
        "scan_id": scan.id,
        "student_id": s.id if s else None,
        "student_name": s.full_name if s else "—",
        "registration_num": s.registration_num if s else "",
        "division": div.name if div else "",
        "checkpoint_id": cp.id if cp else None,
        "checkpoint_name": cp.name if cp else "—",
        "checkpoint_type": cp.point_type if cp else "",
        "lat": cp.latitude if cp else None,
        "lng": cp.longitude if cp else None,
        "direction": scan.direction,
        "time": scan.scanned_at.isoformat() if scan.scanned_at else None,
    }

@app.get("/api/tracking/checkpoints")
@gate_required("G23")
def list_checkpoints():
    db = Session()
    try:
        rows = db.query(CheckPoint).filter(CheckPoint.is_active==True).all()
        return ok([{"id":c.id,"name":c.name,"code":c.code,"type":c.point_type,
                     "lat":c.latitude,"lng":c.longitude} for c in rows])
    finally:
        db.close()

@app.post("/api/tracking/checkpoints")
@gate_required("G23")
def create_checkpoint():
    data = request.get_json() or {}
    db = Session()
    try:
        if not data.get("name") or not data.get("code"):
            return err("الاسم والرمز مطلوبان")
        if db.query(CheckPoint).filter(CheckPoint.code==data["code"].upper()).first():
            return err("الرمز مستخدم بالفعل")
        c = CheckPoint(name=data["name"], code=data["code"].upper(),
                        point_type=data.get("type","بوابة"),
                        latitude=data.get("lat"), longitude=data.get("lng"))
        db.add(c); db.commit(); db.refresh(c)
        write_audit(g.user_id,"CREATE_CHECKPOINT","checkpoint",c.id)
        return ok({"id":c.id},"تم إنشاء نقطة التتبع",201)
    finally:
        db.close()

@app.post("/api/tracking/scan")
@gate_required("G23")
def scan_student():
    data = request.get_json() or {}
    reg = (data.get("registration_num") or "").strip()
    cp_id = data.get("checkpoint_id")
    direction = data.get("direction","دخول")
    db = Session()
    try:
        if not reg or not cp_id:
            return err("رقم التسجيل ونقطة التتبع مطلوبان")
        s = db.query(Student).filter(Student.registration_num==reg).first()
        if not s:
            return err("لا يوجد تلميذ بهذا الرقم",404)
        cp = db.query(CheckPoint).filter(CheckPoint.id==cp_id, CheckPoint.is_active==True).first()
        if not cp:
            return err("نقطة التتبع غير موجودة",404)
        scan = LocationScan(scanned_at=datetime.now(), student_id=s.id, checkpoint_id=cp.id,
                             direction=direction, scanned_by=g.user_id)
        db.add(scan); db.commit(); db.refresh(scan)
        write_audit(g.user_id,"LOCATION_SCAN","student",s.id,new=f"{cp.name}/{direction}")
        return ok(_scan_out(scan, db), "تم تسجيل الموقع", 201)
    finally:
        db.close()

@app.get("/api/tracking/student/<registration_num>")
@gate_required("G23")
def student_location(registration_num):
    db = Session()
    try:
        s = db.query(Student).filter(Student.registration_num==registration_num).first()
        if not s: return err("لا يوجد تلميذ بهذا الرقم",404)
        last = db.query(LocationScan).filter(LocationScan.student_id==s.id)\
                 .order_by(LocationScan.scanned_at.desc()).first()
        history = db.query(LocationScan).filter(LocationScan.student_id==s.id)\
                    .order_by(LocationScan.scanned_at.desc()).limit(20).all()
        return ok({
            "last_location": _scan_out(last, db) if last else None,
            "history": [_scan_out(h, db) for h in history]
        })
    finally:
        db.close()

@app.get("/api/tracking/live")
@gate_required("G23")
def live_tracking():
    """آخر موقع معروف لكل تلميذ. نعتمد على أكبر id وليس أكبر توقيت
    لتفادي ظهور تكرار عند تطابق الثانية بين مسحين متتاليين لنفس التلميذ."""
    db = Session()
    try:
        sub = db.query(
            LocationScan.student_id.label("sid"),
            sa_func.max(LocationScan.id).label("last_id")
        ).group_by(LocationScan.student_id).subquery()
        rows = db.query(LocationScan).join(
            sub, LocationScan.id==sub.c.last_id
        ).all()
        return ok([_scan_out(r, db) for r in rows])
    finally:
        db.close()

# ════════════════ الحضور بمسح البطاقة/البصمة (دخول وانصراف حقيقي) ════════════════
# يعتمد على قارئ بطاقات USB يعمل كلوحة مفاتيح (يكتب رقم التسجيل تلقائياً عند
# التمرير) أو جهاز بصمة يُخرج نفس الرقم — الحقل في الواجهة يبقى مُركَّزاً دوماً
# لالتقاط أي مسح فوري بلا تدخّل يدوي.

def _get_or_create_attendance_checkpoint(db):
    cp = db.query(CheckPoint).filter(CheckPoint.code == "ATTEND").first()
    if not cp:
        cp = CheckPoint(name="بوابة الحضور", code="ATTEND", point_type="بوابة")
        db.add(cp); db.commit(); db.refresh(cp)
    return cp

@app.post("/api/attendance/scan")
@gate_required("G23")
def attendance_scan():
    """مسح بطاقة/بصمة تلميذ عند الدخول. period_start هو توقيت بدء الحصة (يُرسل
    من الواجهة عند الضغط على «بدء الحصة») — يُستعمل لتحديد التأخر مقارنة بدقائق
    السماح المضبوطة في إعدادات المؤسسة."""
    data = request.get_json() or {}
    reg = (data.get("registration_num") or "").strip()
    period = (data.get("period") or "").strip()
    period_start_raw = data.get("period_start")
    if not reg or not period:
        return err("رقم التسجيل والحصة مطلوبان")
    db = Session()
    try:
        si = SI(db)
        s = CARDS.find_student(db, Student, reg)
        if not s:
            return err("بطاقة غير معروفة — لا يوجد تلميذ نشط بهذا الرمز", 404)
        today = date.today()
        already = db.query(LocationScan).join(
            CheckPoint, LocationScan.checkpoint_id == CheckPoint.id
        ).filter(
            LocationScan.student_id == s.id, CheckPoint.code == "ATTEND",
            LocationScan.note == period,
            sa_func.date(LocationScan.scanned_at) == today
        ).first()
        if already:
            div = db.query(Division).filter(Division.id == s.division_id).first()
            return ok({"student_id": s.id, "student_name": s.full_name, "division": div.name if div else "",
                       "photo": s.photo_path or "", "status": "مُسجَّل مسبقاً", "late_minutes": 0, "already": True})

        late_minutes = 0
        status = "حاضر"
        if period_start_raw:
            try:
                p_start = datetime.fromisoformat(period_start_raw.replace("Z", "+00:00")).replace(tzinfo=None)
                elapsed = (datetime.now() - p_start).total_seconds() / 60.0
                if elapsed > (si.late_grace_minutes or 10):
                    late_minutes = round(elapsed)
                    status = "متأخر"
            except Exception:
                pass

        cp = _get_or_create_attendance_checkpoint(db)
        scan = LocationScan(scanned_at=datetime.now(), student_id=s.id, checkpoint_id=cp.id, direction="دخول",
                            scanned_by=g.user_id, note=period)
        db.add(scan)
        # إن كان مسجَّلاً غائباً مسبقاً لهذه الحصة، امسح تسجيل الغياب لأنه حضر فعلياً (ولو متأخراً)
        db.query(Absence).filter(Absence.student_id == s.id, Absence.date == today,
                                 Absence.period == period).delete()
        db.commit()
        write_audit(g.user_id, "ATTENDANCE_SCAN", "student", s.id, new=f"{period}/{status}/{late_minutes}m")
        div = db.query(Division).filter(Division.id == s.division_id).first()
        return ok({"student_id": s.id, "student_name": s.full_name, "division": div.name if div else "",
                   "photo": s.photo_path or "", "status": status, "late_minutes": late_minutes, "already": False})
    finally:
        db.close()

@app.get("/api/attendance/today-log")
@gate_required("G23")
def attendance_today_log():
    period = request.args.get("period", "")
    db = Session()
    try:
        today = date.today()
        q = db.query(LocationScan).join(CheckPoint, LocationScan.checkpoint_id == CheckPoint.id).filter(
            CheckPoint.code == "ATTEND", sa_func.date(LocationScan.scanned_at) == today
        )
        if period:
            q = q.filter(LocationScan.note == period)
        rows = q.order_by(LocationScan.scanned_at.desc()).limit(100).all()
        out = []
        for r in rows:
            s = db.query(Student).filter(Student.id == r.student_id).first()
            div = db.query(Division).filter(Division.id == s.division_id).first() if s else None
            out.append({"scan_id": r.id, "student_id": s.id if s else None,
                        "student_name": s.full_name if s else "—", "division": div.name if div else "",
                        "period": r.note, "time": r.scanned_at.isoformat() if r.scanned_at else None})
        return ok(out)
    finally:
        db.close()

@app.post("/api/attendance/entry-permit/<int:sid>")
@gate_required("G23")
def attendance_entry_permit(sid):
    """رخصة دخول للتلميذ المتأخر — تُمنح عند مسح متأخر ليقدّمها للأستاذ للسماح له بدخول الحصة."""
    data = request.get_json() or {}
    period = data.get("period", "")
    late_minutes = data.get("late_minutes", 0)
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id == sid).first()
        if not s: return err("التلميذ غير موجود", 404)
        div = db.query(Division).filter(Division.id == s.division_id).first()
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type == "entry_permit").count() + 1
        doc_num = DocNumberService.gen("entry_permit", si.school_code or "00000", seq)
        content = {
            "doc_number": doc_num, "student_name": s.full_name, "division": div.name if div else "",
            "period": period, "late_minutes": late_minutes, "time": datetime.now().strftime("%H:%M"),
            "date": str(date.today()),
        }
        doc = OfficialDocument(doc_type="entry_permit", doc_number=doc_num, student_id=sid,
                               issued_date=date.today(), content_json=json.dumps(content, ensure_ascii=False),
                               issued_by=g.user_id)
        db.add(doc); db.commit(); db.refresh(doc)
        write_audit(g.user_id, "ENTRY_PERMIT", "student", sid, new=period)
        return ok({"doc_id": doc.id, "doc_number": doc_num})
    finally:
        db.close()

@app.get("/api/documents/entry-permit/print/<int:doc_id>")
@gate_required("G23")
def print_entry_permit(doc_id):
    db = Session()
    try:
        si = SI(db)
        d = db.query(OfficialDocument).filter(OfficialDocument.id == doc_id, OfficialDocument.doc_type == "entry_permit").first()
        if not d: return Response("غير موجود", mimetype="text/html")
        c = json.loads(d.content_json or "{}")
        body = f"""
        <div style="width:380px;border:2px solid #333;border-radius:10px;padding:16px;text-align:center;margin:0 auto">
          <div style="font-size:12px;font-weight:600">{si.name_ar}</div>
          <h3 style="margin:8px 0">رخصة دخول (تأخر)</h3>
          <p style="font-size:14px;margin:6px 0"><b>{c.get('student_name','')}</b></p>
          <p style="font-size:12.5px">القسم: {c.get('division','')}</p>
          <p style="font-size:12.5px">الحصة: {c.get('period','')} &nbsp;|&nbsp; التاريخ: {c.get('date','')} &nbsp;|&nbsp; الساعة: {c.get('time','')}</p>
          <p style="font-size:12.5px;color:#c0392b">مدة التأخر: {c.get('late_minutes',0)} دقيقة</p>
          <p style="font-size:11px;margin-top:14px">يُرجى من الأستاذ(ة) السماح للتلميذ(ة) بدخول الحصة</p>
          <div style="margin-top:16px;font-size:11px">رقم: {c.get('doc_number','')}</div>
        </div>"""
        return Response(_doc_page("رخصة دخول", body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.post("/api/attendance/close-period")
@gate_required("G02")
def attendance_close_period():
    """إنهاء الحصة: يُسجَّل غياب تلقائي لكل تلميذ نشط في القسم لم يُسجِّل حضوره
    (لا بطاقة ولا مسح) لهذه الحصة، دون التأثير على من حضر أو حضر متأخراً."""
    data = request.get_json() or {}
    div_id = data.get("division_id")
    period = (data.get("period") or "").strip()
    d = _parse_date_field(data.get("date")) or date.today()
    if not div_id or not period:
        return err("حدد القسم والحصة")
    db = Session()
    try:
        students = db.query(Student).filter(Student.division_id == div_id, Student.is_active == True).all()
        scanned_ids = {r[0] for r in db.query(LocationScan.student_id).join(
            CheckPoint, LocationScan.checkpoint_id == CheckPoint.id
        ).filter(CheckPoint.code == "ATTEND", LocationScan.note == period,
                 sa_func.date(LocationScan.scanned_at) == d).all()}
        marked = 0
        newly_absent = []
        for s in students:
            if s.id in scanned_ids:
                continue
            exists = db.query(Absence).filter(Absence.student_id == s.id, Absence.date == d,
                                              Absence.period == period).first()
            if exists:
                continue
            db.add(Absence(student_id=s.id, division_id=div_id, date=d, period=period,
                           hours=1.0, status="غير مبرر", entered_by=g.user_id))
            marked += 1
            newly_absent.append(s)
        db.commit()
        for s in students:
            if s.id not in scanned_ids:
                _check_milestone(s.id, db, g.user_id)
        si = SI(db)
        for s in newly_absent:
            notify_absence(s, si, str(d), period, db=db)
        write_audit(g.user_id, "CLOSE_PERIOD", "division", div_id, new=f"{period}/{d}/absent:{marked}")
        return ok({"marked_absent": marked, "total": len(students), "present": len(scanned_ids)},
                  f"تم إنهاء الحصة: {marked} تلميذ غائب من أصل {len(students)}")
    finally:
        db.close()

# ════════════════ بطاقات التلاميذ + بوابة الدخول والخروج اليومية ════════════════
# قارئ USB (RFID 13.56MHz / 125kHz أو ماسح باركود/QR) يعمل «كلوحة مفاتيح»: يكتب رمز البطاقة ثم Enter.
# الرمز المخزَّن في Student.card_uid؛ وإن لم تُربط بطاقة يُقبل رقم التسجيل (بطاقات الباركود/QR المطبوعة).

def _get_or_create_gate_checkpoint(db):
    cp = db.query(CheckPoint).filter(CheckPoint.code == "GATE").first()
    if not cp:
        cp = CheckPoint(name="بوابة المؤسسة (دخول/خروج)", code="GATE", point_type="بوابة")
        db.add(cp); db.commit(); db.refresh(cp)
    return cp

def _hhmm_minutes(s, default=480):
    try:
        h, m = str(s).split(":"); return int(h) * 60 + int(m)
    except Exception:
        return default

def _gate_scans_for(db, d, student_ids=None):
    q = db.query(LocationScan).join(CheckPoint, LocationScan.checkpoint_id == CheckPoint.id).filter(
        CheckPoint.code == "GATE", sa_func.date(LocationScan.scanned_at) == d)
    if student_ids is not None:
        q = q.filter(LocationScan.student_id.in_(student_ids))
    return q

GATE_TAG = "غياب البوابة"

@app.post("/api/gate/scan")
@gate_required("G23")
def gate_scan():
    """مسح عند بوابة المؤسسة: المسح الأول في اليوم = دخول، ثم خروج، ثم دخول... بالتناوب."""
    data = request.get_json() or {}
    raw = data.get("code") or data.get("registration_num") or ""
    if not CARDS.normalize_code(raw):
        return err("لم يصل أي رمز")
    db = Session()
    try:
        s = CARDS.find_student(db, Student, raw)
        if not s:
            return err("بطاقة غير معروفة — لم تُربط بتلميذ", 404)
        si = SI(db)
        now = datetime.now()
        today = now.date()
        mine = _gate_scans_for(db, today, [s.id]).order_by(LocationScan.scanned_at.asc()).all()
        div = db.query(Division).filter(Division.id == s.division_id).first()
        base = {"student_id": s.id, "student_name": s.full_name, "division": div.name if div else "",
                "photo": s.photo_path or "", "time": now.strftime("%H:%M:%S")}
        if mine and mine[-1].scanned_at and (now - mine[-1].scanned_at).total_seconds() < 8:
            base.update({"direction": mine[-1].direction, "status": "مسح مكرر", "late_minutes": 0, "duplicate": True})
            return ok(base)
        direction = "دخول" if len(mine) % 2 == 0 else "خروج"
        status, late = ("حاضر" if direction == "دخول" else "خرج"), 0
        first_entry = direction == "دخول" and not any(x.direction == "دخول" for x in mine)
        if first_entry:
            start = _hhmm_minutes(getattr(si, "gate_start_time", None) or "08:00")
            elapsed = now.hour * 60 + now.minute - start
            if elapsed > (si.late_grace_minutes or 10):
                status, late = "متأخر", elapsed
        cp = _get_or_create_gate_checkpoint(db)
        db.add(LocationScan(scanned_at=now, student_id=s.id, checkpoint_id=cp.id, direction=direction,
                            scanned_by=g.user_id, note=status))
        # إن كان قد سُجِّل غائباً تلقائياً عند إغلاق البوابة ثم وصل متأخراً: تُلغى غياباته الآلية لهذا اليوم
        cleared = 0
        if first_entry:
            cleared = db.query(Absence).filter(Absence.student_id == s.id, Absence.date == today,
                                               Absence.justification == GATE_TAG).delete()
        db.commit()
        base.update({"direction": direction, "status": status, "late_minutes": late, "duplicate": False,
                     "absence_cleared": cleared, "scans_today": len(mine) + 1})
        return ok(base)
    finally:
        db.close()

@app.get("/api/gate/today")
@gate_required("G23")
def gate_today():
    """ملخص اليوم: كم دخل، من لم يدخل بعد، المتأخرون، وآخر المسحات."""
    d = DR.to_date(request.args.get("date") or date.today())
    db = Session()
    try:
        students = DR._enrolled_students(db, d)
        ids = {s.id for s in students}
        scans = _gate_scans_for(db, d).order_by(LocationScan.scanned_at.asc()).all()
        entered, late, last_dir = set(), set(), {}
        for r in scans:
            if r.student_id not in ids:
                continue
            last_dir[r.student_id] = r.direction
            if r.direction == "دخول":
                if r.student_id not in entered and r.note == "متأخر":
                    late.add(r.student_id)
                entered.add(r.student_id)
        inside = sum(1 for sid, dr in last_dir.items() if dr == "دخول")
        divs = {x.id: x for x in db.query(Division).all()}
        per = {}
        for s in students:
            r = per.setdefault(s.division_id, {"id": s.division_id, "name": divs[s.division_id].name if s.division_id in divs else "—",
                                               "total": 0, "entered": 0})
            r["total"] += 1
            r["entered"] += 1 if s.id in entered else 0
        by_id = {s.id: s for s in students}
        log = []
        for r in reversed(scans[-60:]):
            s = by_id.get(r.student_id)
            if not s:
                continue
            log.append({"time": r.scanned_at.strftime("%H:%M:%S") if r.scanned_at else "", "student_name": s.full_name,
                        "division": divs[s.division_id].name if s.division_id in divs else "",
                        "direction": r.direction, "status": r.note})
        cards = sum(1 for s in students if s.card_uid)
        return ok({"date": str(d), "total": len(ids), "entered": len(entered), "not_entered": len(ids) - len(entered),
                   "late": len(late), "inside": inside, "with_card": cards,
                   "divisions": sorted(per.values(), key=lambda x: x["name"]), "log": log})
    finally:
        db.close()

@app.post("/api/gate/close")
@gate_required("G23")
def gate_close():
    """إغلاق البوابة: كل تلميذ نشط لم يدخل (لا مسح دخول اليوم) يُسجَّل غائباً في كل حصص يومه
    حسب استعمال الزمن. الغياب الآلي موسوم لكي يُلغى تلقائياً إن وصل التلميذ متأخراً ومسح بطاقته."""
    data = request.get_json() or {}
    d = DR.to_date(data.get("date") or date.today())
    div_id = data.get("division_id")
    db = Session()
    try:
        si = SI(db)
        cal = DR._Cal(db, si)
        if not cal.is_school_day(d):
            return err("هذا اليوم ليس يوم دراسة (راحة أسبوعية أو عطلة مسجّلة)")
        students = [s for s in DR._enrolled_students(db, d) if s.is_active and (not div_id or s.division_id == int(div_id))]
        entered = {r[0] for r in _gate_scans_for(db, d).filter(LocationScan.direction == "دخول").with_entities(LocationScan.student_id).all()}
        di = DR.day_idx(d)
        sched = {}
        for e in db.query(ScheduleEntry).filter(ScheduleEntry.day_of_week == di).all():
            sched.setdefault(e.division_id, set()).add(e.period)
        marked = no_sched = 0
        newly = []
        for s in students:
            if s.id in entered:
                continue
            periods = sorted(sched.get(s.division_id, [])) or None
            if not periods:
                periods = ["ص1"]; no_sched += 1
            added = False
            for p in periods:
                if db.query(Absence).filter(Absence.student_id == s.id, Absence.date == d, Absence.period == p).first():
                    continue
                db.add(Absence(student_id=s.id, division_id=s.division_id, date=d, period=p, hours=1.0,
                               status="غير مبرر", justification=GATE_TAG, entered_by=g.user_id))
                added = True
            if added:
                marked += 1; newly.append(s)
        db.commit()
        for s in newly:
            _check_milestone(s.id, db, g.user_id)
        for s in newly:
            notify_absence(s, si, str(d), "", db=db)
        write_audit(g.user_id, "GATE_CLOSE", "date", 0, new=f"{d}/absent:{marked}")
        return ok({"marked_absent": marked, "present": len(entered & {s.id for s in students}), "total": len(students),
                   "no_schedule": no_sched},
                  f"أُغلقت البوابة: {marked} تلميذ غائب من أصل {len(students)}")
    finally:
        db.close()

@app.get("/api/cards/status")
@gate_any("G23", "G06", "G28")
def cards_status():
    div_id = request.args.get("division_id")
    db = Session()
    try:
        q = db.query(Student).filter(Student.is_active == True)
        if div_id:
            q = q.filter(Student.division_id == int(div_id))
        rows = q.all()
        rows.sort(key=lambda s: (s.last_name_ar or "", s.first_name_ar or ""))
        return ok({"total": len(rows), "linked": sum(1 for s in rows if s.card_uid),
                   "students": [{"id": s.id, "name": s.full_name, "registration_num": s.registration_num or "",
                                 "card_uid": s.card_uid or ""} for s in rows]})
    finally:
        db.close()

@app.post("/api/cards/assign")
@gate_any("G23", "G06")
def cards_assign():
    data = request.get_json() or {}
    sid = data.get("student_id")
    code = CARDS.normalize_code(data.get("card_uid"))
    force = bool(data.get("force"))
    if not sid or not code:
        return err("التلميذ ورمز البطاقة مطلوبان")
    if len(code) > 40:
        return err("رمز البطاقة طويل جداً")
    db = Session()
    try:
        s = db.query(Student).filter(Student.id == sid).first()
        if not s:
            return err("التلميذ غير موجود", 404)
        other = db.query(Student).filter(sa_func.upper(Student.card_uid) == code, Student.id != s.id).first()
        if other and not force:
            return err(f"هذه البطاقة مربوطة مسبقاً بالتلميذ: {other.full_name}", 409)
        clash = db.query(Student).filter(Student.id != s.id, Student.is_active == True,
                                         (Student.registration_num == code) | (Student.national_id == code)).first()
        if clash and not force:
            return err(f"هذا الرمز يطابق رقم التسجيل/التعريف للتلميذ: {clash.full_name}", 409)
        if other:
            other.card_uid = None
        s.card_uid = code
        db.commit()
        write_audit(g.user_id, "CARD_ASSIGN", "student", s.id, new=code)
        return ok({"student_id": s.id, "card_uid": code}, "تم ربط البطاقة")
    finally:
        db.close()

@app.post("/api/cards/clear/<int:sid>")
@gate_any("G23", "G06")
def cards_clear(sid):
    db = Session()
    try:
        s = db.query(Student).filter(Student.id == sid).first()
        if not s:
            return err("غير موجود", 404)
        s.card_uid = None
        db.commit()
        write_audit(g.user_id, "CARD_CLEAR", "student", sid)
        return ok(msg="أُلغي ربط البطاقة")
    finally:
        db.close()

CANTEEN_STATUSES = ("نصف داخلي", "داخلي")

@app.get("/api/documents/card-sheet")
@gate_any("G23", "G06", "G11", "G15", "G28")
def card_sheet():
    """ورقة بطاقات مطبوعة (8 في كل صفحة A4، مقاس CR80): QR + باركود Code128. الأنواع:
    student (افتراضي) / canteen (ملعقة وشوكة، لنصف الداخليين والداخليين) / library / club (يلزم club_id، لأعضاء النادي).
    كلها تحمل الرمز نفسه، فبطاقة RFID واحدة تكفي لكل البوابات. بلا شعار DONIA."""
    from app.services import cardsheet as CS
    div_id = request.args.get("division_id")
    only = request.args.get("student_id")
    kind = request.args.get("type", "student")
    if kind not in ("student", "canteen", "library", "club"):
        return err("نوع بطاقة غير معروف")
    db = Session()
    try:
        si = SI(db)
        club = None
        q = db.query(Student).filter(Student.is_active == True)
        if kind == "club":
            club = db.query(Club).filter(Club.id == int(request.args.get("club_id") or 0)).first()
            if not club:
                return err("اختر النادي", 404)
            ids = [m.student_id for m in db.query(ClubMember).filter(ClubMember.club_id == club.id).all()]
            q = q.filter(Student.id.in_(ids or [0]))
        if kind == "canteen":
            q = q.filter(Student.status.in_(CANTEEN_STATUSES))
        if only:
            q = q.filter(Student.id == int(only))
        elif div_id:
            q = q.filter(Student.division_id == int(div_id))
        studs = [s for s in q.all() if s.registration_num or s.card_uid]
        studs.sort(key=lambda s: (s.division_id or 0, s.last_name_ar or "", s.first_name_ar or ""))
        divs = {x.id: x.name for x in db.query(Division).all()}
        html = CS.build(studs, kind, si, divs, request.host_url.rstrip('/'), club)
        return Response(html, mimetype="text/html")
    finally:
        db.close()

# ════════════════ الإحصاء الشامل ════════════════
def _census_data(db):
    from app.services import census as CN
    si = SI(db)
    labels = dict(ROLE_LABELS_AR)
    return si, CN.compute(db, si, {"Student": Student, "Division": Division, "Teacher": Teacher,
                                   "User": User, "Room": Room}, labels)

@app.get("/api/census")
@gate_required("G12")
def census_get():
    """الإحصاء الشامل: أرقام محسوبة آلياً من التلاميذ والأقسام والأساتذة والموظفين + حقول يدوية للمرافق."""
    db = Session()
    try:
        return ok(_census_data(db)[1])
    finally:
        db.close()

@app.put("/api/census/extras")
@gate_required("G12")
def census_save_extras():
    from app.services import census as CN
    data = request.get_json() or {}
    try:
        clean = CN.clean_extras(data.get("extras") or {})
    except (ValueError, TypeError):
        return err("قيمة غير صالحة (أعداد صحيحة موجبة فقط)")
    db = Session()
    try:
        si = SI(db)
        si.census_json = json.dumps(clean, ensure_ascii=False)
        db.commit()
        write_audit(g.user_id, "UPDATE_CENSUS", "school_info", si.id)
        return ok(msg="تم حفظ بيانات الإحصاء الشامل")
    finally:
        db.close()

@app.get("/api/census/print")
@gate_required("G12")
def census_print():
    from app.services import census as CN
    db = Session()
    try:
        return Response(CN.build_html(_census_data(db)[1]), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/census/xlsx")
@gate_required("G12")
def census_xlsx():
    from app.services import census as CN
    db = Session()
    try:
        si, c = _census_data(db)
        fn = "census_" + str(si.academic_year or "").replace("/", "-") + ".xlsx"
        return Response(CN.build_xlsx(c), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        headers={"Content-Disposition": f'attachment; filename="{fn}"'})
    finally:
        db.close()

# ════════════════ النوادي المدرسية + مسح الخدمات (المطعم / المكتبة / النوادي) ════════════════
CLUB_CATS = ("رياضي", "ثقافي", "علمي", "فني", "أخرى")

def _club_dict(c, n):
    return {"id": c.id, "name": c.name, "category": c.category, "supervisor": c.supervisor or "",
            "description": c.description or "", "capacity": c.capacity or 0, "reg_open": bool(c.reg_open),
            "members": n, "full": bool(c.capacity and n >= c.capacity)}

@app.get("/api/clubs")
@gate_any("G28", "G18")
def clubs_list():
    db = Session()
    try:
        counts = dict(db.query(ClubMember.club_id, sa_func.count(ClubMember.id)).group_by(ClubMember.club_id).all())
        rows = db.query(Club).filter(Club.is_active == True).order_by(Club.category, Club.name).all()
        return ok({"clubs": [_club_dict(c, counts.get(c.id, 0)) for c in rows], "categories": list(CLUB_CATS)})
    finally:
        db.close()

def _club_fields(c, d):
    if "name" in d:
        nm = (d.get("name") or "").strip()
        if not nm: return "اسم النادي مطلوب"
        c.name = nm[:120]
    if "category" in d: c.category = d["category"] if d["category"] in CLUB_CATS else "أخرى"
    if "supervisor" in d: c.supervisor = (d.get("supervisor") or "")[:120]
    if "description" in d: c.description = (d.get("description") or "")[:2000]
    if "capacity" in d:
        try: c.capacity = max(0, int(d.get("capacity") or 0))
        except (TypeError, ValueError): return "السعة غير صالحة"
    return None

@app.post("/api/clubs")
@gate_required("G28")
def clubs_create():
    d = request.get_json() or {}
    db = Session()
    try:
        c = Club(name="", reg_open=True)
        e = _club_fields(c, dict({"name": ""}, **d))
        if e: return err(e)
        if db.query(Club).filter(Club.name == c.name, Club.is_active == True).first():
            return err("يوجد نادٍ بهذا الاسم")
        db.add(c); db.commit()
        write_audit(g.user_id, "CLUB_CREATE", "club", c.id)
        return ok(_club_dict(c, 0), msg="تمت إضافة النادي")
    finally:
        db.close()

@app.put("/api/clubs/<int:cid>")
@gate_required("G28")
def clubs_update(cid):
    d = request.get_json() or {}
    db = Session()
    try:
        c = db.query(Club).filter(Club.id == cid, Club.is_active == True).first()
        if not c: return err("النادي غير موجود", 404)
        e = _club_fields(c, d)
        if e: return err(e)
        if "reg_open" in d: c.reg_open = bool(d["reg_open"])
        db.commit()
        n = db.query(ClubMember).filter(ClubMember.club_id == cid).count()
        return ok(_club_dict(c, n), msg="تم الحفظ")
    finally:
        db.close()

@app.delete("/api/clubs/<int:cid>")
@gate_required("G28")
def clubs_delete(cid):
    db = Session()
    try:
        c = db.query(Club).filter(Club.id == cid).first()
        if not c: return err("النادي غير موجود", 404)
        c.is_active = False; c.reg_open = False; db.commit()
        write_audit(g.user_id, "CLUB_DELETE", "club", cid)
        return ok(msg="حُذف النادي (يبقى سجل الحضور)")
    finally:
        db.close()

@app.get("/api/clubs/<int:cid>/members")
@gate_required("G28")
def club_members(cid):
    db = Session()
    try:
        divs = {x.id: x.name for x in db.query(Division).all()}
        rows = (db.query(ClubMember, Student).join(Student, Student.id == ClubMember.student_id)
                .filter(ClubMember.club_id == cid, Student.is_active == True).all())
        out = [{"student_id": s.id, "name": s.full_name, "division": divs.get(s.division_id, ""),
                "joined": m.joined_at.strftime("%Y-%m-%d") if m.joined_at else ""} for m, s in rows]
        out.sort(key=lambda x: (x["division"], x["name"]))
        return ok(out)
    finally:
        db.close()

@app.post("/api/clubs/<int:cid>/members")
@gate_required("G28")
def club_join(cid):
    """اشتراك تلميذ في نادٍ (برمز البطاقة/رقم التسجيل أو student_id). يُرفض إن كانت بوابة الاشتراك مغلقة أو اكتملت السعة."""
    d = request.get_json() or {}
    db = Session()
    try:
        c = db.query(Club).filter(Club.id == cid, Club.is_active == True).first()
        if not c: return err("النادي غير موجود", 404)
        if not c.reg_open: return err("بوابة الاشتراك في هذا النادي مغلقة")
        s = (db.query(Student).filter(Student.id == int(d["student_id"]), Student.is_active == True).first()
             if d.get("student_id") else CARDS.find_student(db, Student, d.get("code") or ""))
        if not s: return err("لم يُعثر على التلميذ")
        if db.query(ClubMember).filter(ClubMember.club_id == cid, ClubMember.student_id == s.id).first():
            return err("%s مشترك في النادي من قبل" % s.full_name)
        n = db.query(ClubMember).filter(ClubMember.club_id == cid).count()
        if c.capacity and n >= c.capacity: return err("اكتملت أماكن النادي (%d)" % c.capacity)
        db.add(ClubMember(club_id=cid, student_id=s.id)); db.commit()
        div = db.query(Division).filter(Division.id == s.division_id).first()
        return ok({"student_id": s.id, "name": s.full_name, "division": div.name if div else "", "members": n + 1},
                  msg="اشتُرك %s في %s" % (s.full_name, c.name))
    finally:
        db.close()

@app.delete("/api/clubs/<int:cid>/members/<int:sid>")
@gate_required("G28")
def club_leave(cid, sid):
    db = Session()
    try:
        db.query(ClubMember).filter(ClubMember.club_id == cid, ClubMember.student_id == sid).delete()
        db.commit()
        return ok(msg="أُلغي الاشتراك")
    finally:
        db.close()

_SERVICE_GATE = {"canteen": "G11", "library": "G15", "club": "G28"}

@app.post("/api/service/scan")
@login_required
def service_scan():
    """مسح بطاقة عند: المطعم (وجبة واحدة لكل تلميذ في اليوم)، المكتبة (زيارة)، النادي (حضور اليوم، للأعضاء فقط)."""
    d = request.get_json() or {}
    svc = d.get("service")
    gcode = _SERVICE_GATE.get(svc)
    if not gcode: return err("خدمة غير معروفة")
    if gcode not in g.gates:
        return err("ليس لديك صلاحية هذه الخدمة", 403)
    raw = (d.get("code") or "").strip()
    if not raw: return err("لا يوجد رمز")
    db = Session()
    try:
        s = CARDS.find_student(db, Student, raw)
        if not s: return err("بطاقة غير معروفة: %s" % raw[:30])
        now = datetime.now(); today = now.date()
        div = db.query(Division).filter(Division.id == s.division_id).first()
        base = {"student_id": s.id, "student_name": s.full_name, "division": div.name if div else "",
                "photo": s.photo_path or "", "time": now.strftime("%H:%M:%S"), "status": s.status or ""}
        club = None; note = ""
        if svc == "canteen":
            note = (d.get("meal") or "غداء")[:20]
            if s.status not in CANTEEN_STATUSES:
                return ok(dict(base, state="denied", message="غير مسجَّل في المطعم (%s)" % (s.status or "خارجي")))
        elif svc == "club":
            club = db.query(Club).filter(Club.id == int(d.get("club_id") or 0), Club.is_active == True).first()
            if not club: return err("اختر النادي")
            note = club.name[:40]
            if not db.query(ClubMember).filter(ClubMember.club_id == club.id, ClubMember.student_id == s.id).first():
                return ok(dict(base, state="denied", message="غير مشترك في «%s»" % club.name))
        q = db.query(ServiceScan).filter(ServiceScan.service == svc, ServiceScan.student_id == s.id, ServiceScan.day == today)
        if svc == "canteen": q = q.filter(ServiceScan.note == note)
        if svc == "club": q = q.filter(ServiceScan.club_id == club.id)
        last = q.order_by(ServiceScan.scanned_at.desc()).first()
        if last and (svc != "library" or (now - last.scanned_at).total_seconds() < 300):
            msg = {"canteen": "سبق تسجيل وجبة «%s» اليوم" % note, "club": "سبق تسجيل حضوره اليوم",
                   "library": "سُجّلت زيارته للتو"}[svc]
            return ok(dict(base, state="dup", message=msg, at=last.scanned_at.strftime("%H:%M")))
        db.add(ServiceScan(service=svc, student_id=s.id, club_id=club.id if club else None, day=today,
                           scanned_at=now, note=note, scanned_by=g.user_id))
        db.commit()
        msg = {"canteen": "وجبة «%s» ✓" % note, "library": "تم تسجيل الزيارة ✓", "club": "حاضر في %s ✓" % (club.name if club else "")}[svc]
        return ok(dict(base, state="ok", message=msg))
    finally:
        db.close()

@app.get("/api/service/today")
@login_required
def service_today():
    svc = request.args.get("service")
    gcode = _SERVICE_GATE.get(svc)
    if not gcode or gcode not in g.gates:
        return err("ليس لديك صلاحية هذه الخدمة", 403)
    db = Session()
    try:
        today = date.today()
        q = db.query(ServiceScan).filter(ServiceScan.service == svc, ServiceScan.day == today)
        if svc == "club":
            q = q.filter(ServiceScan.club_id == int(request.args.get("club_id") or 0))
        if svc == "canteen":
            q = q.filter(ServiceScan.note == (request.args.get("meal") or "غداء"))
        rows = q.order_by(ServiceScan.scanned_at.desc()).all()
        ids = {r.student_id for r in rows}
        studs = {s.id: s for s in db.query(Student).filter(Student.id.in_(ids or [0])).all()}
        divs = {x.id: x.name for x in db.query(Division).all()}
        log = [{"time": r.scanned_at.strftime("%H:%M"), "name": studs[r.student_id].full_name if r.student_id in studs else "",
                "division": divs.get(studs[r.student_id].division_id, "") if r.student_id in studs else ""} for r in rows[:40]]
        out = {"count": len(ids), "log": log}
        if svc == "canteen":
            out["eligible"] = db.query(Student).filter(Student.is_active == True, Student.status.in_(CANTEEN_STATUSES)).count()
        if svc == "club":
            out["members"] = db.query(ClubMember).filter(ClubMember.club_id == int(request.args.get("club_id") or 0)).count()
        return ok(out)
    finally:
        db.close()

# ════════════════ دليل الاستخدام + المساعد المدمج (بحث عربي محلي بلا إنترنت) ════════════════
@app.get("/api/help/guide")
@login_required
def help_guide():
    return ok({"sections": [GUIDE.public(s) for s in GUIDE.SECTIONS], "quick": GUIDE.QUICK})

@app.post("/api/help/ask")
@login_required
def help_ask():
    q = ((request.get_json() or {}).get("q") or "").strip()[:300]
    if not q:
        return err("اكتب سؤالك")
    hits = GUIDE.search(q, 3)
    return ok({"matches": [GUIDE.public(s) for s in hits], "answered": bool(hits)})

@app.get("/api/help/guide/print")
@login_required
def help_guide_print():
    db = Session()
    try:
        si = SI(db)
        return Response(GUIDE.render_html(school_name=si.name_ar or ""), mimetype="text/html")
    finally:
        db.close()

# ════════════════ USERS ════════════════
@app.get("/api/users")
@gate_required("G21")
def list_users():
    db = Session()
    try:
        users = db.query(User).filter(User.is_active==True).all()
        return ok([{"id":u.id,"username":u.username,"full_name":u.full_name,"role":u.role,"gates":u.get_gates()} for u in users])
    finally:
        db.close()

@app.post("/api/users")
@gate_required("G21")
def create_user():
    """إنشاء حساب. إن تُرك اسم المستخدم أو كلمة المرور فارغَين يُولَّدان تلقائياً (وتُعاد كلمة المرور مرة واحدة)."""
    from app.services import accounts as AC
    data = request.get_json() or {}
    db = Session()
    try:
        full = (data.get("full_name") or "").strip()
        if not full:
            return err("أدخل الاسم الكامل")
        role = data.get("role", "teacher")
        username = (data.get("username") or "").strip()
        if not username:
            parts = full.split()
            username = AC.unique_username(db, User, role, parts[0] if parts else "", " ".join(parts[1:]))
        elif db.query(User).filter(User.username == username).first():
            return err("اسم المستخدم موجود مسبقاً")
        generated = not data.get("password")
        password = data.get("password") or AC.gen_password()
        gates = data.get("gates") or ROLE_GATES.get(role, [])
        u = User(username=username, full_name=full, password_hash=hash_pw(password),
                 role=role, gates=json.dumps(gates), must_change=bool(generated or data.get("must_change")),
                 phone=data.get("phone", ""), email=data.get("email", ""), created_by=g.user_id)
        db.add(u); db.commit()
        write_audit(g.user_id, "CREATE_USER", "user", u.id)
        return ok({"id": u.id, "username": username, "password": password,
                   "role_label": AC.ROLE_AR.get(role, role), "full_name": full}, "تم إنشاء الحساب", 201)
    finally:
        db.close()

# ════════════════ توليد الحسابات تلقائياً (حسب الفئة أو الفرد) ════════════════
def _site_url():
    """رابط الدخول الذي يُطبع على بطاقة الحساب: عنوان النفق إن كان مفتوحاً، وإلا عنوان هذا الخادم."""
    try:
        st = REMOTE.status()
        if st.get("connected") and st.get("url"):
            return st["url"]
        if st.get("enabled") and st.get("hostname"):
            return "https://" + st["hostname"]
    except Exception:
        pass
    return request.host_url.rstrip("/")

@app.get("/api/accounts/suggest")
@gate_required("G21")
def accounts_suggest():
    """اقتراح اسم مستخدم + كلمة مرور لفرد (للنموذج): ?role=teacher&name=بن علي أحمد"""
    from app.services import accounts as AC
    role = request.args.get("role", "teacher")
    parts = (request.args.get("name") or "").split()
    db = Session()
    try:
        return ok({"username": AC.unique_username(db, User, role, parts[0] if parts else "", " ".join(parts[1:])),
                   "password": AC.gen_password()})
    finally:
        db.close()

@app.post("/api/accounts/generate")
@gate_required("G21")
def accounts_generate():
    """توليد حسابات جماعي. kind = teachers (أساتذة بلا حساب) | parents (تلاميذ بلا ولي؛ يمكن تحديد division_id)
    | reset (إعادة تعيين كلمات مرور user_ids أو كل مستخدمي role). تُعاد كلمات المرور مرة واحدة فقط."""
    from app.services import accounts as AC
    data = request.get_json() or {}
    kind = data.get("kind")
    out, taken = [], set()
    db = Session()
    try:
        if kind == "teachers":
            for t in db.query(Teacher).filter(Teacher.is_active == True, Teacher.user_id.is_(None)).order_by(Teacher.last_name).all():
                full = f"{t.last_name} {t.first_name}".strip()
                if not full:
                    continue
                pw = AC.gen_password()
                un = AC.unique_username(db, User, "teacher", t.last_name, t.first_name, taken=taken)
                u = User(username=un, full_name=full, password_hash=hash_pw(pw), role="teacher", must_change=True,
                         gates=json.dumps(ROLE_GATES.get("teacher", [])), is_active=True, created_by=g.user_id,
                         phone=t.phone or "", email=t.email or "")
                db.add(u); db.flush()
                t.user_id = u.id       # يربط حساب الأستاذ بسجله في استعمال الزمن تلقائياً
                out.append({"user_id": u.id, "full_name": full, "role": "teacher", "role_label": AC.ROLE_AR["teacher"],
                            "username": un, "password": pw, "extra": t.specialty or ""})
        elif kind == "parents":
            q = db.query(Student).filter(Student.is_active == True)
            if data.get("division_id"):
                q = q.filter(Student.division_id == int(data["division_id"]))
            linked = {r[0] for r in db.query(ParentLink.student_id).all()}
            divs = {d.id: d.name for d in db.query(Division).all()}
            by_phone = {}
            for s_ in q.order_by(Student.division_id, Student.last_name_ar).all():
                if s_.id in linked:
                    continue
                key = (s_.guardian_phone or "").strip() or None
                if key and key in by_phone:     # إخوة بنفس هاتف الولي → حساب واحد
                    db.add(ParentLink(parent_id=by_phone[key]["user_id"], student_id=s_.id, relation="ولي"))
                    by_phone[key]["extra"] += " + " + s_.full_name
                    continue
                pw = AC.gen_password()
                un = AC.unique_username(db, User, "parent", seed=s_.registration_num or s_.id, taken=taken)
                u = User(username=un, full_name=(s_.guardian_name or f"ولي {s_.full_name}"), password_hash=hash_pw(pw),
                         role="parent", must_change=True, gates=json.dumps(ROLE_GATES.get("parent", [])),
                         is_active=True, created_by=g.user_id, phone=s_.guardian_phone or "")
                db.add(u); db.flush()
                db.add(ParentLink(parent_id=u.id, student_id=s_.id, relation="ولي"))
                row = {"user_id": u.id, "full_name": u.full_name, "role": "parent", "role_label": AC.ROLE_AR["parent"],
                       "username": un, "password": pw, "extra": f"{s_.full_name} — {divs.get(s_.division_id, '')}"}
                out.append(row)
                if key:
                    by_phone[key] = row
        elif kind == "reset":
            q = db.query(User).filter(User.is_active == True)
            if data.get("user_ids"):
                q = q.filter(User.id.in_([int(x) for x in data["user_ids"]]))
            elif data.get("role"):
                q = q.filter(User.role == data["role"])
            else:
                return err("حدّد المستخدمين أو الفئة")
            for u in q.order_by(User.full_name).all():
                if u.id == g.user_id:
                    continue       # لا نعيد تعيين كلمة مرور الحساب الذي يعمل الآن
                pw = AC.gen_password()
                u.password_hash = hash_pw(pw); u.must_change = True; u.login_attempts = 0; u.locked_until = None
                out.append({"user_id": u.id, "full_name": u.full_name, "role": u.role,
                            "role_label": AC.ROLE_AR.get(u.role, u.role), "username": u.username, "password": pw, "extra": ""})
        else:
            return err("نوع غير معروف")
        db.commit()
        write_audit(g.user_id, "GENERATE_ACCOUNTS", "user", None, new=f"{kind}:{len(out)}")
        return ok({"accounts": out, "count": len(out)}, f"تم توليد {len(out)} حساب" if out else "لا توجد حسابات جديدة لتوليدها")
    finally:
        db.close()

@app.post("/api/accounts/sheet")
@gate_required("G21")
def accounts_sheet():
    """يبني صفحة بطاقات الدخول (للطباعة) من الصفوف المرسَلة؛ لا يُخزَّن شيء من كلمات المرور على الخادم."""
    from app.services import accounts as AC
    rows = (request.get_json() or {}).get("rows") or []
    if not rows or len(rows) > 600:
        return err("لا توجد حسابات للطباعة")
    db = Session()
    try:
        return Response(AC.sheet_html(rows, SI(db), _site_url()), mimetype="text/html")
    finally:
        db.close()

@app.put("/api/users/<int:uid>/gates")
@gate_required("G21")
def update_gates(uid):
    data = request.get_json() or {}
    db = Session()
    try:
        u = db.query(User).filter(User.id==uid).first()
        if not u: return err("غير موجود",404)
        u.gates = json.dumps(data.get("gates",[]))
        db.commit()
        return ok(msg="تم تحديث الصلاحيات")
    finally:
        db.close()

# ════════════════ STATS ════════════════
@app.get("/api/stats/dashboard")
@gate_required("G18")
def dashboard():
    db = Session()
    try:
        total_stu = db.query(Student).filter(Student.is_active==True).count()
        total_users = db.query(User).filter(User.is_active==True).count()
        today_rep = db.query(DailyReport).filter(DailyReport.report_date==date.today()).first()
        pending = db.query(AbsenceNotice).filter(AbsenceNotice.notice_type=="إشعار_أول").count()
        cnt = _div_counts(db)
        lv = {}
        for d in db.query(Division).filter(Division.is_active == True).all():
            c = cnt.get(d.id, _EMPTY_CNT)
            L = lv.setdefault(d.level, dict(level=d.level, divisions=0, m=0, f=0, total=0, new=0, rep_m=0, rep_f=0, rep=0))
            L["divisions"] += 1
            for k in ("m", "f", "total", "new", "rep_m", "rep_f", "rep"):
                L[k] += c[k]
        levels = [lv[k] for k in sorted(lv)]
        return ok({"total_students":total_stu,"total_users":total_users,"levels":levels,
                   "total_divisions": sum(L["divisions"] for L in levels),
                   "today_absent_pct":today_rep.absence_percentage if today_rep else None,
                   "pending_notices":pending,"date":str(date.today()),
                   "school":cfg.SCHOOL_NAME,"academic_year":cfg.ACADEMIC_YEAR})
    finally:
        db.close()

@app.get("/api/stats/subjects")
@gate_any("G12","G04","G09","G05")
def list_subjects():
    db = Session()
    try:
        subjs = db.query(Subject).order_by(Subject.sort_order).all()
        return ok([{"id":s.id,"name_ar":s.name_ar,"name_fr":s.name_fr,"coefficient":s.coefficient,
                    "has_fard2":s.has_fard2,"has_exam":s.has_exam,"is_exempt":s.is_exempt} for s in subjs])
    finally:
        db.close()

# ════════════════ LICENSE ════════════════
@app.get("/api/license/status")
def lic_status():
    from app.core.license import verify_license
    if os.getenv("DSS_TRIAL_MODE") == "1":
        return ok({"valid": True, "days_remaining": 0, "message": "وضع تجريبي — بلا ترخيص"})
    return ok(verify_license(cfg.LICENSE_FILE))

@app.post("/api/license/activate")
def lic_activate():
    from app.core.license import activate_license
    data = request.get_json() or {}
    return ok(activate_license(data.get("license_key","")))

@app.post("/api/license/install")
def lic_install():
    """تثبيت ملف dss.lic مرفوع (بديل التفعيل عبر الإنترنت)."""
    from app.core.license import install_license_file
    f = request.files.get("file")
    if not f: return ok({"success": False, "message": "لم يُرفع ملف"})
    res = install_license_file(f.read())
    _LICENSE_CACHE["ts"] = 0.0
    return ok(res)

@app.get("/api/license/fingerprint")
def fingerprint():
    from app.core.license import get_fp
    fp = get_fp()
    return ok({"fingerprint":fp,"short":fp[:16]+"..."})

# ════════════════ SETTINGS ════════════════
@app.get("/api/settings")
@login_required
def get_settings():
    db = Session()
    try:
        si = SI(db)
        return ok({"school_name":si.name_ar,"school_code":si.school_code,
                   "wilaya":si.wilaya,"academic_year":si.academic_year,
                   "ai_provider":cfg.AI_PROVIDER,"has_groq":bool(cfg.GROQ_KEY),
                   "has_anthropic":bool(cfg.ANTHROPIC_KEY),"has_gemini":bool(cfg.GEMINI_KEY),
                   "gates_list":GATES})
    finally:
        db.close()

@app.get("/api/config/education-meta")
@login_required
def education_meta():
    """يُعيد أطوار التعليم المتاحة (ابتدائية/متوسطة/ثانوية) وقائمة الشعب الرسمية
    للتعليم الثانوي الجزائري وطور المؤسسة الحالي — تُستعمل لملء القوائم
    المنسدلة في الواجهة (متاحة لكل الأدوار وليس فقط G20)."""
    db = Session()
    try:
        si = SI(db)
        return ok({
            "levels": list(LEVEL_LABELS.keys()),
            "secondary_streams": SECONDARY_STREAMS,
            "secondary_streams_flat": SECONDARY_STREAMS_FLAT,
            "institution_level": si.level_type or "متوسطة",
            "periods_morning": si.periods_morning or 4,
            "periods_evening": si.periods_evening or 4,
            "late_grace_minutes": si.late_grace_minutes or 10,
            "gate_start_time": getattr(si, "gate_start_time", None) or "08:00",
        })
    finally:
        db.close()

@app.get("/api/school-info")
@gate_required("G20")
def get_school_info():
    db = Session()
    try:
        si = SI(db)
        return ok({"name_ar":si.name_ar,"name_fr":si.name_fr,"school_code":si.school_code,
                   "wilaya":si.wilaya,"commune":si.commune,"address":si.address,"phone":si.phone,
                   "director_name":si.director_name,"nazir_name":si.nazir_name,
                   "counselor_name":si.counselor_name,"guidance_counselor_name":si.guidance_counselor_name,
                   "general_supervisor_name":si.general_supervisor_name,"bursar_name":si.bursar_name,
                   "academic_year":si.academic_year,"level_type":si.level_type,
                   "is_configured":si.is_configured,
                   "logo_path":si.logo_path or "","motto":si.motto or "",
                   "brand_color":si.brand_color or "#1B7F4B","email":si.email or "",
                   "periods_morning":si.periods_morning,"periods_evening":si.periods_evening,
                   "late_grace_minutes":si.late_grace_minutes,
                   "abs_first":ABSENCE_RULES["first_notice"],"abs_second":ABSENCE_RULES["second_notice"],
                   "abs_warning":ABSENCE_RULES["warning"],"abs_evict_days":ABSENCE_RULES["eviction_days"],
                   "legal_basis":LEGAL_BASIS,
                   "gate_start_time":getattr(si,"gate_start_time",None) or "08:00",
                   "tt_morning_start":si.tt_morning_start or "08:00","tt_evening_start":si.tt_evening_start or "13:30",
                   "tt_period_minutes":si.tt_period_minutes or 60,
                   "notify_absence_enabled":si.notify_absence_enabled,
                   "notify_channel_email":si.notify_channel_email,
                   "notify_channel_whatsapp":si.notify_channel_whatsapp,
                   "smtp_configured": bool(cfg.SMTP_HOST and cfg.SMTP_USER and cfg.SMTP_PASSWORD),
                   "ai_gateway_url": getattr(si, "ai_gateway_url", "") or "",
                   "mail_mode": si.mail_mode or "", "mail_script_url": si.mail_script_url or "",
                   "mail_script_key_set": bool(si.mail_script_key),
                   "mail_configured": ((si.mail_mode or "") == "script" and bool(si.mail_script_url and si.mail_script_key))
                                      or bool(cfg.SMTP_HOST and cfg.SMTP_USER and cfg.SMTP_PASSWORD),
                   "whatsapp_configured": bool(
                       (cfg.WHATSAPP_PROVIDER == "twilio" and cfg.TWILIO_SID and cfg.TWILIO_AUTH_TOKEN and cfg.TWILIO_WHATSAPP_FROM)
                       or (cfg.WHATSAPP_PROVIDER != "twilio" and cfg.WHATSAPP_TOKEN and cfg.WHATSAPP_PHONE_ID)
                   )})
    finally:
        db.close()

@app.put("/api/school-info")
@gate_required("G20")
def update_school_info():
    """تعديل معلومات المؤسسة (الاسم، الولاية، البلدية، وأسماء المدير/الناظر/
    مستشار التربية/مستشار التوجيه/المشرف العام/المقتصد، وعدد الحصص اليومية) —
    تظهر تلقائياً في كل الوثائق الرسمية المولّدة بعد ذلك."""
    data = request.get_json() or {}
    db = Session()
    try:
        si = SI(db)
        fields = ["name_ar","name_fr","school_code","wilaya","commune","address","phone",
                  "director_name","nazir_name","counselor_name","guidance_counselor_name",
                  "general_supervisor_name","bursar_name","academic_year","level_type",
                  "motto","brand_color","email"]
        import re as _re0
        if "brand_color" in data and not _re0.fullmatch(r"#[0-9a-fA-F]{6}", str(data["brand_color"] or "")):
            data = {k: v for k, v in data.items() if k != "brand_color"}
        for f in fields:
            if f in data:
                setattr(si, f, data[f])
        for nf in ("periods_morning", "periods_evening", "late_grace_minutes"):
            if nf in data:
                try:
                    v = int(data[nf])
                    if v < 0 or v > 12: raise ValueError()
                    setattr(si, nf, v)
                except (TypeError, ValueError):
                    return err(f"قيمة غير صالحة لـ {nf}")
        import re as _re
        for tf in ("tt_morning_start", "tt_evening_start", "gate_start_time"):
            if tf in data:
                if not _re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", str(data[tf])):
                    return err("توقيت غير صالح (الصيغة 08:00)")
                setattr(si, tf, str(data[tf]))
        if "tt_period_minutes" in data:
            try:
                v = int(data["tt_period_minutes"])
                if v < 20 or v > 120: raise ValueError()
                si.tt_period_minutes = v
            except (TypeError, ValueError):
                return err("مدة الحصة بين 20 و120 دقيقة")
        rl = {}
        for rf, lo, hi in (("abs_first", 1, 60), ("abs_second", 1, 60), ("abs_warning", 1, 90), ("abs_evict_days", 1, 90)):
            if rf in data:
                try:
                    v = int(data[rf])
                    if v < lo or v > hi: raise ValueError()
                    rl[rf] = v
                except (TypeError, ValueError):
                    return err(f"قيمة غير صالحة في قواعد المواظبة ({lo}–{hi})")
        if rl:
            f1 = rl.get("abs_first", si.abs_first or 1); f2 = rl.get("abs_second", si.abs_second or 3)
            f3 = rl.get("abs_warning", si.abs_warning or 8)
            if not (f1 <= f2 <= f3):
                return err("يجب أن يكون: الإشعار الأول ≤ الثاني ≤ الإعذار")
            for k, v in rl.items(): setattr(si, k, v)
        if "ai_gateway_url" in data:
            gu = str(data["ai_gateway_url"] or "").strip().rstrip("/")
            if gu and not _re.fullmatch(r"https://[A-Za-z0-9.\-]+(:\d+)?(/[A-Za-z0-9._~\-/]*)?", gu):
                return err("عنوان بوابة المساعد الذكي يجب أن يبدأ بـ https://")
            si.ai_gateway_url = gu
        if "mail_mode" in data:
            mm = str(data["mail_mode"] or "")
            if mm not in ("", "script", "smtp"): return err("نمط البريد غير صالح")
            si.mail_mode = mm
        if "mail_script_url" in data:
            u = str(data["mail_script_url"] or "").strip()
            if u and not _re.fullmatch(r"https://script\.google\.com/macros/s/[A-Za-z0-9_\-]+/exec", u):
                return err("رابط السكربت يجب أن يكون من الشكل https://script.google.com/macros/s/.../exec")
            si.mail_script_url = u
        if data.get("mail_script_key"):
            k = str(data["mail_script_key"]).strip()
            if len(k) < 8 or len(k) > 100: return err("المفتاح السرّي بين 8 و100 حرف")
            si.mail_script_key = k
        for bf in ("notify_absence_enabled", "notify_channel_email", "notify_channel_whatsapp"):
            if bf in data:
                setattr(si, bf, bool(data[bf]))
        if data.get("name_ar") and data.get("director_name"):
            si.is_configured = True
        db.commit()
        _sync_rules(si)
        write_audit(g.user_id, "UPDATE_SCHOOL_INFO", "school_info", si.id)
        return ok(msg="تم حفظ معلومات المؤسسة بنجاح")
    finally:
        db.close()

# ════════════════ إشعارات الغياب التلقائية (بريد/واتساب) ════════════════
@app.get("/api/notifications/log")
@gate_required("G02")
def notifications_log():
    """سجل آخر محاولات إرسال إشعارات الغياب (ناجحة/فاشلة/متخطّاة) — للتدقيق
    ومتابعة فعالية النظام، ويُستعمل أيضاً كمصدر رقم في التقرير العام للتسيير."""
    db = Session()
    try:
        student_id = request.args.get("student_id")
        q = db.query(NotificationLog).order_by(NotificationLog.created_at.desc())
        if student_id:
            q = q.filter(NotificationLog.student_id == int(student_id))
        rows = q.limit(200).all()
        out = []
        for r in rows:
            s = db.query(Student).filter(Student.id == r.student_id).first() if r.student_id else None
            out.append({"id": r.id, "student_id": r.student_id,
                        "student_name": s.full_name if s else "—", "event_type": r.event_type,
                        "channel": r.channel, "recipient": r.recipient, "status": r.status,
                        "error": r.error, "created_at": r.created_at.isoformat() if r.created_at else None})
        counts = {"sent": db.query(NotificationLog).filter(NotificationLog.status == "sent").count(),
                  "failed": db.query(NotificationLog).filter(NotificationLog.status == "failed").count(),
                  "skipped": db.query(NotificationLog).filter(NotificationLog.status == "skipped").count()}
        return ok({"logs": out, "counts": counts})
    finally:
        db.close()

@app.get("/api/mail/script-template")
@gate_required("G20")
def mail_script_template():
    from app.services.mailscript import TEMPLATE
    return ok({"code": TEMPLATE})


@app.post("/api/notifications/test")
@gate_required("G20")
def notifications_test():
    """يرسل رسالة اختبار فورية عبر البريد و/أو واتساب لعنوان/رقم يُدخله المدير
    يدوياً — للتحقق من صحة إعدادات .env قبل الاعتماد على الإشعار التلقائي."""
    data = request.get_json() or {}
    email = (data.get("email") or "").strip()
    phone = (data.get("phone") or "").strip()
    if not email and not phone:
        return err("أدخل بريداً إلكترونياً أو رقم هاتف للاختبار")
    db = Session()
    try:
        from app.services.notify import _send_email, _send_whatsapp
        si = SI(db)
        msg = f"رسالة اختبار من نظام {si.name_ar or 'DONIA SMART SCHOOL'} — إن وصلتك هذه الرسالة فإعدادات الإشعارات تعمل بنجاح."
        results = {}
        if email:
            ok_, error = _send_email(email, "رسالة اختبار — DONIA SMART SCHOOL", msg)
            _log_test = NotificationLog(student_id=None, event_type="test", channel="email",
                                        recipient=email, message=msg, status="sent" if ok_ else "failed", error=error)
            db.add(_log_test); db.commit()
            results["email"] = {"success": ok_, "error": error}
        if phone:
            ok_, error = _send_whatsapp(phone, msg)
            _log_test = NotificationLog(student_id=None, event_type="test", channel="whatsapp",
                                        recipient=phone, message=msg, status="sent" if ok_ else "failed", error=error)
            db.add(_log_test); db.commit()
            results["whatsapp"] = {"success": ok_, "error": error}
        return ok(results, "تم إرسال رسالة (رسائل) الاختبار")
    finally:
        db.close()

# ════════════════ قوالب الوثائق المتعلَّمة (RAG-lite) ════════════════
# فكرة النظام: عندما لا يوجد مولّد جاهز (hard-coded) لنوع وثيقة معيّن، يرفع
# المستخدم نموذجاً حقيقياً (نص/HTML أو نص ملصوق يدوياً)، فيُخزَّن كمرجع صياغة.
# عند طلب توليد وثيقة من ذلك النوع لاحقاً، يُستعمل أقرب قالب مخزّن + بيانات
# التلميذ/الموظف الحية عبر مساعد الذكاء الاصطناعي (Groq/Anthropic/Gemini —
# حسب المفتاح المُعدّ في .env) لإنتاج وثيقة تُحاكي شكل وصياغة القالب الأصلي.

KNOWN_DOC_TYPES = {
    "school_cert", "id_card", "parent_invite",
    "إشعار_أول", "إشعار_ثاني", "إعذار", "class_list", "daily_report",
}

def _extract_template_text(filename: str, content: bytes) -> str:
    """يستخرج نصاً قابلاً للاستعمال من ملف مرفوع (txt/htm/html فقط حالياً).
    لملفات PDF/الصور الممسوحة ضوئياً (مثل نماذج CamScanner)، لا يوجد استخراج
    نص موثوق بدون OCR — يُفضَّل لصق نص القالب يدوياً بدل رفع الملف مباشرة."""
    name = (filename or "").lower()
    if name.endswith((".htm", ".html")):
        try:
            from bs4 import BeautifulSoup
            return BeautifulSoup(content.decode("utf-8", errors="replace"), "html.parser").get_text("\n", strip=True)
        except Exception:
            pass
    try:
        return content.decode("utf-8", errors="replace")
    except Exception:
        return ""

@app.post("/api/templates/upload")
@gate_required("G06")
def upload_template():
    """رفع نموذج وثيقة حقيقي كقالب مرجعي. يقبل إمّا ملف (txt/htm) أو حقل
    نصي 'text' يحوي محتوى القالب ملصوقاً يدوياً (الأدق للوثائق الممسوحة ضوئياً)."""
    doc_type = (request.form.get("doc_type") or "").strip()
    title = (request.form.get("title") or "").strip()
    if not doc_type:
        return err("حدد نوع الوثيقة (doc_type)")
    text = (request.form.get("text") or "").strip()
    filename = ""
    f = request.files.get("file")
    if f and f.filename:
        filename = f.filename
        content = f.read()
        if content:
            extracted = _extract_template_text(filename, content)
            if extracted:
                text = (text + "\n" + extracted).strip() if text else extracted
    if not text:
        return err("لم يُعثر على نص قابل للاستخراج — الصق نص القالب يدوياً في حقل النص إن كان الملف صورة/PDF ممسوحاً ضوئياً")
    db = Session()
    try:
        t = DocTemplateSample(doc_type=doc_type, title=title or doc_type,
                               source_filename=filename, extracted_text=text[:20000],
                               uploaded_by=g.user_id)
        db.add(t); db.commit()
        write_audit(g.user_id, "UPLOAD_TEMPLATE", "doc_template", t.id, new=doc_type)
        return ok({"id": t.id}, "تم حفظ القالب — سيُستعمل تلقائياً عند توليد وثائق من هذا النوع", 201)
    finally:
        db.close()

@app.get("/api/templates")
@gate_required("G06")
def list_templates():
    db = Session()
    try:
        q = db.query(DocTemplateSample)
        dt = request.args.get("doc_type")
        if dt:
            q = q.filter(DocTemplateSample.doc_type == dt)
        rows = q.order_by(DocTemplateSample.uploaded_at.desc()).all()
        return ok([{
            "id": t.id, "doc_type": t.doc_type, "title": t.title,
            "source_filename": t.source_filename,
            "preview": (t.extracted_text or "")[:200],
            "uploaded_at": str(t.uploaded_at),
        } for t in rows])
    finally:
        db.close()

@app.delete("/api/templates/<int:tid>")
@gate_required("G06")
def delete_template(tid):
    db = Session()
    try:
        t = db.query(DocTemplateSample).filter(DocTemplateSample.id == tid).first()
        if not t: return err("غير موجود", 404)
        db.delete(t); db.commit()
        return ok(msg="تم حذف القالب")
    finally:
        db.close()

@app.post("/api/documents/generate/<doc_type>/<int:sid>")
@gate_required("G06")
def generate_from_template(doc_type, sid):
    """يولّد وثيقة لتلميذ من نوع لا يملك مولّداً جاهزاً في النظام، بالاعتماد على
    أقرب قالب مرفوع مسبقاً (نظام تعلّم القوالب) + بيانات التلميذ الحية،
    عبر مساعد الذكاء الاصطناعي المُعدّ في .env (Groq/Anthropic/Gemini)."""
    if doc_type in KNOWN_DOC_TYPES:
        return err("هذا النوع له مولّد رسمي جاهز في النظام — استعمل المسار المخصص له بدل هذا المسار العام")
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id == sid).first()
        if not s: return err("غير موجود", 404)
        div = db.query(Division).filter(Division.id == s.division_id).first()
        tpl = (db.query(DocTemplateSample)
               .filter(DocTemplateSample.doc_type == doc_type)
               .order_by(DocTemplateSample.uploaded_at.desc()).first())
        if not tpl:
            return err(
                "لا يوجد قالب مرجعي لهذا النوع من الوثائق بعد. "
                "ارفع نموذجاً حقيقياً واحداً عبر «إدارة القوالب» وسيتعلّم النظام شكله تلقائياً للمرات القادمة."
            )
        data = {
            "اللقب": s.last_name_ar, "الاسم": s.first_name_ar,
            "تاريخ الميلاد": str(s.birth_date or ""), "مكان الميلاد": s.birth_place or "",
            "القسم": div.name if div else "", "رقم التسجيل": s.registration_num or "",
            "الرقم الوطني": s.national_id or "", "المؤسسة": si.name_ar,
            "الولاية": si.wilaya, "السنة الدراسية": si.academic_year,
            "المدير": si.director_name, "الطور": level_label(si),
        }
        prompt = (
            f"فيما يلي نموذج حقيقي لوثيقة إدارية جزائرية من نوع '{tpl.title}' "
            f"(كما رُفع من مؤسسة تعليمية حقيقية). أعد إنتاج نفس البنية والصياغة والتنسيق الرسمي "
            f"حرفياً، لكن استبدل البيانات ببيانات التلميذ الجديدة المرفقة أدناه فقط. "
            f"لا تُضف حقولاً أو فقرات غير موجودة في النموذج الأصلي. أخرج النص جاهزاً للطباعة فقط "
            f"بدون أي تعليق إضافي.\n\n"
            f"— النموذج المرجعي —\n{tpl.extracted_text}\n\n"
            f"— بيانات التلميذ الجديد —\n" +
            "\n".join(f"{k}: {v}" for k, v in data.items())
        )
        from app.agents.agents import outreach
        generated = asyncio.run(outreach.answer(prompt))
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type == f"custom_{doc_type}").count() + 1
        doc_num = DocNumberService.gen(f"custom_{doc_type}", si.school_code or "00000", seq)
        db.add(OfficialDocument(doc_type=f"custom_{doc_type}", doc_number=doc_num, student_id=sid,
                                issued_date=date.today(),
                                content_json=json.dumps({"generated": True, "based_on_template": tpl.id}, ensure_ascii=False),
                                issued_by=g.user_id))
        db.commit()
        body = f"""
        <div class="doc-no">رقم: {doc_num}</div>
        <div class="title">{tpl.title}</div>
        <p style="line-height:2.2; font-size:14px; white-space:pre-line">{generated}</p>
        <p style="font-size:11px;margin-top:20px;color:#999">⚠ وثيقة مولَّدة تلقائياً استناداً إلى قالب مرفوع — راجعها قبل التسليم الرسمي.</p>
        """
        return Response(_doc_page(tpl.title, body, si=si), mimetype="text/html")
    finally:
        db.close()


@app.get("/api/ai/status")
@gate_required("G19")
def ai_status():
    from app.services import aigateway
    return ok(aigateway.status())

@app.post("/api/ai/chat")
@gate_required("G19")
def ai_chat():
    data = request.get_json() or {}
    from app.agents.agents import outreach
    result = asyncio.run(outreach.answer(data.get("message",""),data.get("context")))
    return ok({"response":result,"provider":cfg.AI_PROVIDER})

@app.post("/api/ai/generate-sms")
@gate_required("G19")
def ai_sms():
    data = request.get_json() or {}
    from app.agents.agents import outreach
    sms = asyncio.run(outreach.sms(data.get("student_name",""),data.get("issue_type",""),data.get("details",""),cfg.SCHOOL_NAME))
    return ok({"sms":sms})

@app.get("/api/ai/scan")
@gate_required("G19")
def ai_scan():
    from app.agents.agents import monitor, outreach
    results = asyncio.run(monitor.scan())
    from app.services import aigateway as _agw
    if _agw.own_key():
        try: results["ai_report"] = asyncio.run(outreach.answer("لخّص نتائج الفحص بإيجاز وقدّم توصيات",str(results)))
        except: pass
    return ok(results)

# ════════════════ HEALTH ════════════════
@app.get("/api/health")
def health():
    return jsonify({"status":"running","version":"3.0.0","system":"DONIA SMART SCHOOL",
                    "company":"DONIA LABS TECH","school":cfg.SCHOOL_NAME,"python_ok":True})

# ════════════════ HELPERS ════════════════
def _stu(s):
    return {"id":s.id,"national_id":s.national_id,"registration_num":s.registration_num,
            "last_name_ar":s.last_name_ar,"first_name_ar":s.first_name_ar,
            "full_name":s.full_name,"gender":s.gender,
            "birth_date":str(s.birth_date) if s.birth_date else None,
            "status":s.status,"is_repeating":s.is_repeating,"division_id":s.division_id,
            "photo_path":s.photo_path or ""}

def _stu_full(s):
    d = _stu(s)
    d.update({"birth_place":s.birth_place,"father_name":s.father_name,"mother_name":s.mother_name,
               "guardian_name":s.guardian_name,"guardian_phone":s.guardian_phone,
               "guardian_email":s.guardian_email,"guardian_address":s.guardian_address,
               "is_orphan":s.is_orphan,"siblings_count":s.siblings_count,
               "is_scholarship":s.is_scholarship,"pe_exempt":s.pe_exempt,
               "health_status":s.health_status,"orientation_wish":s.orientation_wish,
               "father_in_education":s.father_in_education,"mother_in_education":s.mother_in_education,
               "parents_separated":s.parents_separated,"photo_path":s.photo_path,
               "entry_date":str(s.entry_date) if s.entry_date else "","origin_school":s.origin_school or "",
               "exit_note":s.exit_note or "","expelled_date":str(s.expelled_date) if s.expelled_date else "",
               "is_expelled":bool(s.is_expelled),"card_uid":s.card_uid or ""})
    return d

def _grade(gr):
    return {"id":gr.id,"student_id":gr.student_id,"subject_id":gr.subject_id,"term":gr.term,
            "fard1":gr.fard1,"fard2":gr.fard2,"activity":gr.activity,"exam_raw":gr.exam_raw,
            "exam_20":gr.exam_20,"term_average":gr.term_average,"comment":gr.comment}

def _check_milestone(student_id,db,user_id):
    SI(db)
    unexcused = db.query(Absence).filter(Absence.student_id==student_id,Absence.status=="غير مبرر").all()
    dates = _countable_abs_dates([a.date for a in unexcused])
    consec = AbsenceService.consecutive(dates)
    issued = [n.notice_type for n in db.query(AbsenceNotice).filter(AbsenceNotice.student_id==student_id).all()]
    needed = AbsenceService.check_milestone(consec,issued)
    if needed:
        write_audit(user_id,f"NOTICE_NEEDED_{needed}","student",student_id,new=f"days:{consec}")

def _absence_status(consec, issued_types):
    """يحدد حالة التلميذ الحالية حسب قواعد المواظبة في «النظام الداخلي الموحد» (2026-2027).
    العتبات قابلة للتعديل من إعدادات المؤسسة (ABSENCE_RULES): إشعار/إنذار أول، ثانٍ، ثم إعذار،
    ثم اقتراح شطب بعد مهلة الرد من تاريخ الإعذار. لا تُحتسب إلا الأيام التي انقضى أجل تبريرها."""
    if consec == 0:
        return {"key": "present", "label": "لا غياب غير مبرر", "next_action": None}
    if consec < DECREE_833["first_notice"]:
        return {"key": "early", "label": f"{consec} أيام — مراقبة", "next_action": None}
    if consec < DECREE_833["second_notice"]:
        return {"key": "warn1", "label": "يستوجب إشعاراً أول", "next_action": "إشعار_أول" if "إشعار_أول" not in issued_types else None}
    if consec < DECREE_833["warning"]:
        return {"key": "warn2", "label": "يستوجب إشعاراً ثانياً", "next_action": "إشعار_ثاني" if "إشعار_ثاني" not in issued_types else None}
    return {"key": "notice", "label": "يستوجب إعذاراً", "next_action": "إعذار" if "إعذار" not in issued_types else None}

@app.get("/api/absences/dashboard")
@gate_required("G02")
def absences_dashboard():
    """لوحة قيادة حقيقية لمتابعة الغياب: تحسب لكل تلميذ عدد أيام غيابه غير المبرر
    المتتالية فعلياً من سجلات Absence الحقيقية (وليس رقماً تجريبياً)، وتحدد ما إذا
    كان يستوجب إجراءً قانونياً تالياً (إشعار أول/ثانٍ/إعذار) لم يُصدر بعد — هذا ما
    كان يُكتشف داخلياً في المدقّق (_check_milestone) بلا أي واجهة تُظهره من قبل."""
    db = Session()
    try:
        div_id = request.args.get("division_id")
        q = db.query(Student).filter(Student.is_active == True)
        if div_id:
            q = q.filter(Student.division_id == int(div_id))
        students = q.all()
        SI(db)
        out = []
        in_grace = 0
        for s in students:
            unexcused = db.query(Absence).filter(Absence.student_id == s.id, Absence.status == "غير مبرر").all()
            if not unexcused:
                continue
            all_dates = [a.date for a in unexcused]
            dates = _countable_abs_dates(all_dates)
            if not dates:
                in_grace += 1      # غياب حديث ما زال ضمن أجل التبرير (48 ساعة)
                continue
            consec = AbsenceService.consecutive(dates)
            if consec == 0:
                continue
            issued = [n.notice_type for n in db.query(AbsenceNotice).filter(AbsenceNotice.student_id == s.id).all()]
            st = _absence_status(consec, issued)
            div = db.query(Division).filter(Division.id == s.division_id).first()
            last_abs = max(dates)
            out.append({
                "student_id": s.id, "name": f"{s.last_name_ar} {s.first_name_ar}",
                "division": div.name if div else "", "registration_num": s.registration_num,
                "guardian_name": s.guardian_name, "guardian_phone": s.guardian_phone,
                "consecutive_days": consec, "total_unexcused_days": len(set(dates)),
                "last_absence_date": str(last_abs), "status": st,
                "notices_issued": issued,
            })
        out.sort(key=lambda x: x["consecutive_days"], reverse=True)
        return ok({
            "thresholds": DECREE_833,
            "students": out,
            "counts": {
                "early": sum(1 for x in out if x["status"]["key"] == "early"),
                "warn1": sum(1 for x in out if x["status"]["key"] == "warn1"),
                "warn2": sum(1 for x in out if x["status"]["key"] == "warn2"),
                "notice": sum(1 for x in out if x["status"]["key"] == "notice"),
                "action_needed": sum(1 for x in out if x["status"]["next_action"]),
                "in_grace": in_grace,
            }
        })
    finally:
        db.close()

@app.post("/api/absences/bulk")
@gate_required("G02")
def record_absences_bulk():
    """تسجيل غياب جماعي لقسم كامل في تاريخ واحد (وحصة معيّنة إن حُدِّدت) دفعة واحدة
    — بدل البحث عن كل تلميذ على حدة. الحصة اختيارية: تركها فارغة يعني غياب اليوم كاملاً."""
    data = request.get_json() or {}
    student_ids = data.get("student_ids") or []
    d = _parse_date_field(data.get("date"))
    div_id = data.get("division_id")
    period = (data.get("period") or "").strip()
    if not student_ids or not d:
        return err("حدد القسم والتاريخ والتلاميذ الغائبين")
    db = Session()
    try:
        added = 0
        newly_absent_ids = []
        for sid in student_ids:
            q = db.query(Absence).filter(Absence.student_id == sid, Absence.date == d)
            q = q.filter(Absence.period == period) if period else q.filter((Absence.period == "") | (Absence.period.is_(None)))
            if q.first():
                continue
            db.add(Absence(student_id=sid, division_id=div_id, date=d, period=period,
                           hours=data.get("hours", 1.0), status="غير مبرر", entered_by=g.user_id))
            added += 1
            newly_absent_ids.append(sid)
        db.commit()
        for sid in student_ids:
            _check_milestone(sid, db, g.user_id)
        si = SI(db)
        for sid in newly_absent_ids:
            stu = db.query(Student).filter(Student.id == sid).first()
            if stu:
                notify_absence(stu, si, str(d), period, db=db)
        write_audit(g.user_id, "BULK_ABSENCE", "division", div_id, new=f"date:{d},period:{period},count:{added}")
        return ok({"added": added, "skipped": len(student_ids) - added},
                  f"تم تسجيل غياب {added} تلميذ" + (f" (تم تجاوز {len(student_ids)-added} مسجَّل مسبقاً)" if len(student_ids) > added else ""))
    finally:
        db.close()

# ════════════════ ENTRY ════════════════




# ══ DELETE USER ══
@app.delete("/api/users/<int:uid>")
@login_required
def delete_user(uid):
    if g.role != 'director':
        return err("فقط المدير", 403)
    db = Session()
    try:
        from app.core.database import Teacher
        user = db.query(User).filter(User.id == uid).first()
        if not user:
            return err("المستخدم غير موجود", 404)
        if user.username == 'admin':
            return err("لا يمكن حذف حساب admin", 403)
        db.query(Teacher).filter(Teacher.user_id == uid).delete()
        db.delete(user)
        db.commit()
        write_audit(g.user_id, "DELETE_USER", entity_id=uid, new=user.full_name)
        return ok({"message": f"تم حذف {user.full_name}"})
    except Exception as e:
        db.rollback()
        return err(str(e))
    finally:
        db.close()


# ══ UPDATE USER ══
@app.put("/api/users/<int:uid>")
@login_required
def update_user(uid):
    if g.role != 'director':
        return err("فقط المدير", 403)
    data = request.get_json() or {}
    db = Session()
    try:
        user = db.query(User).filter(User.id == uid).first()
        if not user:
            return err("المستخدم غير موجود", 404)
        if 'full_name' in data: user.full_name = data['full_name']
        if 'role' in data: user.role = data['role']
        if 'is_active' in data: user.is_active = bool(data['is_active'])
        if 'phone' in data: user.phone = data['phone']
        if 'photo_path' in data: user.photo_path = data['photo_path']
        if 'degree' in data: user.degree = data['degree']
        if 'employment_status' in data: user.employment_status = data['employment_status']
        if 'position_title' in data: user.position_title = data['position_title']
        if 'hr_notes' in data: user.hr_notes = data['hr_notes']
        for df in ('birth_date', 'first_appointment_date', 'hire_date'):
            if df in data:
                setattr(user, df, _parse_date_field(data[df]))
        if 'password' in data and data['password']:
            from app.core.auth import hash_pw
            user.password_hash = hash_pw(data['password'])
            if uid != g.user_id:
                user.must_change = True
        db.commit()
        return ok({"message": f"تم تحديث {user.full_name}"})
    except Exception as e:
        db.rollback()
        return err(str(e))
    finally:
        db.close()


# ══ DELETE STUDENT ══
@app.delete("/api/students/<int:sid>")
@login_required
def delete_student(sid):
    if g.role not in ['director', 'counselor', 'supervisor_general']:
        return err("غير مصرح", 403)
    db = Session()
    try:
        student = db.query(Student).filter(Student.id == sid).first()
        if not student:
            return err("التلميذ غير موجود", 404)
        name = f"{student.last_name_ar} {student.first_name_ar}"
        db.delete(student)
        db.commit()
        write_audit(g.user_id, "DELETE_STUDENT", entity_id=sid, new=name)
        return ok({"message": f"تم حذف {name}"})
    except Exception as e:
        db.rollback()
        return err(str(e))
    finally:
        db.close()



@app.post("/api/admin/reset-students")
@login_required
def reset_students():
    if g.role != 'director':
        return err("فقط المدير", 403)
    db = Session()
    try:
        from app.core.database import (Student, Grade, TermResult, Absence, AbsenceNotice,
                                        OfficialDocument, DisciplineRecord, LocationScan, ParentLink, Message)
        count = db.query(Student).count()
        # حذف كل السجلات المرتبطة بالتلاميذ أولاً لتفادي خطأ قيد المفتاح الأجنبي
        for model in (Message, ParentLink, LocationScan, DisciplineRecord,
                     OfficialDocument, AbsenceNotice, Absence, TermResult, Grade):
            db.query(model).delete()
        db.query(Student).delete()
        db.commit()
        write_audit(g.user_id, "RESET_STUDENTS", new=f"deleted:{count}")
        return ok({"deleted_students": count, "message": f"تم حذف {count} تلميذ"})
    except Exception as e:
        db.rollback()
        return err(str(e))
    finally:
        db.close()

@app.post("/api/admin/sync-gates")
@login_required
def sync_gates():
    """يعيد ضبط صلاحيات (gates) كل المستخدمين حسب القائمة الافتراضية الحالية
    لأدوارهم في config.py. يُستعمل بعد كل تحديث يضيف بوابة صلاحية جديدة للنظام،
    لأن صلاحيات كل مستخدم تُحفظ كنسخة ثابتة عند إنشاء حسابه ولا تتحدث تلقائياً."""
    if g.role != 'director':
        return err("فقط المدير", 403)
    from app.core.config import ROLE_GATES
    db = Session()
    try:
        updated = 0
        for u in db.query(User).all():
            new_gates = ROLE_GATES.get(u.role, [])
            if json.loads(u.gates or "[]") != new_gates:
                u.gates = json.dumps(new_gates)
                updated += 1
        db.commit()
        write_audit(g.user_id, "SYNC_GATES", new=f"updated:{updated}")
        return ok({"updated_users": updated}, f"تم تحديث صلاحيات {updated} مستخدم")
    finally:
        db.close()

@app.post("/api/admin/reset-users")
@login_required
def reset_users():
    """حذف كل المستخدمين ما عدا admin وكل التلاميذ"""
    if g.role != 'director':
        return err("فقط المدير يمكنه تنفيذ هذه العملية", 403)
    
    db = Session()
    try:
        # Count before
        from app.core.database import Teacher, Student
        users_before = db.query(User).filter(User.username != 'admin').count()
        students_before = db.query(Student).count()
        
        # Delete all except admin
        db.query(Teacher).delete()
        db.query(User).filter(User.username != 'admin').delete()
        db.query(Student).delete()
        db.commit()
        
        write_audit(g.user_id, "RESET_DATABASE", 
                   new=f"deleted:{users_before} users, {students_before} students")
        
        return ok({
            "deleted_users": users_before,
            "deleted_students": students_before,
            "message": f"تم حذف {users_before} مستخدم و {students_before} تلميذ"
        })
    except Exception as e:
        db.rollback()
        return err(f"خطأ: {str(e)}")
    finally:
        db.close()


@app.get("/api/admin/db-path")
@login_required  
def db_path():
    """إظهار مسار قاعدة البيانات الحقيقي"""
    import os
    db_file = cfg.DB_PATH
    return ok({
        "db_path": db_file,
        "exists": os.path.exists(db_file),
        "size_kb": round(os.path.getsize(db_file)/1024, 1) if os.path.exists(db_file) else 0
    })

# ════════════════ بوابة الأولياء ════════════════
def _parent_owns(db, parent_id, student_id):
    return db.query(ParentLink).filter(
        ParentLink.parent_id==parent_id, ParentLink.student_id==student_id
    ).first() is not None

@app.get("/api/admin/parents")
@gate_required("G21")
def list_parent_accounts():
    """قائمة كل حسابات الأولياء المُنشأة فعلياً مع التلاميذ المرتبطين بكل حساب —
    الصفحة الإدارية المفقودة سابقاً لمتابعة بوابة الأولياء."""
    db = Session()
    try:
        parents = db.query(User).filter(User.role == "parent").order_by(User.created_at.desc()).all()
        out = []
        for p in parents:
            links = db.query(ParentLink).filter(ParentLink.parent_id == p.id).all()
            children = []
            for l in links:
                s = db.query(Student).filter(Student.id == l.student_id).first()
                if s:
                    children.append({"id": s.id, "name": s.full_name, "relation": l.relation})
            out.append({
                "id": p.id, "username": p.username, "full_name": p.full_name,
                "is_active": p.is_active, "last_login": str(p.last_login) if p.last_login else None,
                "children": children,
            })
        return ok(out)
    finally:
        db.close()

@app.post("/api/admin/parents/<int:pid>/reset-password")
@gate_required("G21")
def reset_parent_password(pid):
    data = request.get_json() or {}
    new_password = data.get("password") or "Parent@2026"
    db = Session()
    try:
        u = db.query(User).filter(User.id == pid, User.role == "parent").first()
        if not u: return err("حساب الولي غير موجود", 404)
        u.password_hash = hash_pw(new_password)
        u.login_attempts = 0
        u.locked_until = None
        db.commit()
        write_audit(g.user_id, "RESET_PARENT_PASSWORD", "user", u.id)
        return ok({"username": u.username, "password": new_password}, "تم إعادة تعيين كلمة المرور")
    finally:
        db.close()

@app.delete("/api/admin/parents/<int:pid>")
@gate_required("G21")
def delete_parent_account(pid):
    """رفض/حذف طلب حساب ولي (عادة يُستعمل لرفض طلب تسجيل ذاتي معلَّق أو حساب مكرر)."""
    db = Session()
    try:
        u = db.query(User).filter(User.id == pid, User.role == "parent").first()
        if not u: return err("حساب الولي غير موجود", 404)
        db.query(ParentLink).filter(ParentLink.parent_id == pid).delete()
        db.delete(u)
        db.commit()
        write_audit(g.user_id, "DELETE_PARENT_ACCOUNT", "user", pid)
        return ok(msg="تم حذف الحساب")
    finally:
        db.close()

@app.put("/api/admin/parents/<int:pid>/toggle")
@gate_required("G21")
def toggle_parent_account(pid):
    db = Session()
    try:
        u = db.query(User).filter(User.id == pid, User.role == "parent").first()
        if not u: return err("حساب الولي غير موجود", 404)
        u.is_active = not u.is_active
        db.commit()
        return ok({"is_active": u.is_active}, "تم التحديث")
    finally:
        db.close()

@app.post("/api/admin/parents/create")
@gate_required("G01")
def create_parent_account():
    """ينشئ حساب ولي أمر (أو يعيد استعمال حساب موجود بنفس اسم المستخدم)
    ويربطه مباشرة بالتلميذ المحدد."""
    data = request.get_json() or {}
    sid = data.get("student_id")
    username = (data.get("username") or "").strip()
    password = data.get("password") or "Parent@2026"
    relation = data.get("relation","ولي")
    db = Session()
    try:
        s = db.query(Student).filter(Student.id==sid).first()
        if not s: return err("التلميذ غير موجود",404)
        if not username:
            import re
            base = re.sub(r'[^a-zA-Z0-9]','', f"p_{s.registration_num or s.id}")
            username = base or f"parent{s.id}"
        u = db.query(User).filter(User.username==username).first()
        if not u:
            from app.core.config import ROLE_GATES
            u = User(username=username, password_hash=hash_pw(password),
                     full_name=data.get("full_name") or f"ولي {s.full_name}",
                     role="parent", gates=json.dumps(ROLE_GATES.get("parent",[])),
                     is_active=True)
            db.add(u); db.commit(); db.refresh(u)
        if not _parent_owns(db, u.id, sid):
            db.add(ParentLink(parent_id=u.id, student_id=sid, relation=relation))
            db.commit()
        write_audit(g.user_id,"CREATE_PARENT_ACCOUNT","user",u.id)
        return ok({"user_id":u.id,"username":username,
                   "password": password if data.get("username") is None else None},
                  "تم إنشاء/ربط حساب ولي الأمر", 201)
    finally:
        db.close()

@app.post("/api/admin/parents/link")
@gate_required("G01")
def link_parent():
    data = request.get_json() or {}
    db = Session()
    try:
        pid, sid = data.get("parent_id"), data.get("student_id")
        if not db.query(User).filter(User.id==pid, User.role=="parent").first():
            return err("حساب الولي غير موجود")
        if not db.query(Student).filter(Student.id==sid).first():
            return err("التلميذ غير موجود")
        if _parent_owns(db, pid, sid):
            return err("الربط موجود مسبقاً")
        db.add(ParentLink(parent_id=pid, student_id=sid, relation=data.get("relation","ولي")))
        db.commit()
        return ok(msg="تم الربط", code=201)
    finally:
        db.close()

@app.get("/api/parent/children")
@gate_required("G24")
def parent_children():
    db = Session()
    try:
        links = db.query(ParentLink).filter(ParentLink.parent_id==g.user_id).all()
        out = []
        for l in links:
            s = db.query(Student).filter(Student.id==l.student_id).first()
            if not s: continue
            div = db.query(Division).filter(Division.id==s.division_id).first()
            out.append({"id":s.id,"name":s.full_name,"division":div.name if div else "",
                       "registration_num":s.registration_num,"relation":l.relation})
        return ok(out)
    finally:
        db.close()

@app.get("/api/parent/child/<int:sid>/summary")
@gate_required("G24")
def parent_child_summary(sid):
    db = Session()
    try:
        if not _parent_owns(db, g.user_id, sid):
            return err("لا تملك صلاحية الاطلاع على بيانات هذا التلميذ", 403)
        s = db.query(Student).filter(Student.id==sid).first()
        if not s: return err("غير موجود",404)
        div = db.query(Division).filter(Division.id==s.division_id).first()

        grades = db.query(TermResult).filter(TermResult.student_id==sid).all()
        grades_out = [{"term":gr.term,"average":gr.term_average,"rank":gr.rank} for gr in grades]

        absences = db.query(Absence).filter(Absence.student_id==sid).order_by(Absence.date.desc()).limit(30).all()
        abs_out = [{"date":str(a.date),"status":a.status,"reason":a.justification or ""} for a in absences]
        unexcused_total = db.query(Absence).filter(Absence.student_id==sid, Absence.status=="غير مبرر").count()

        notices = db.query(AbsenceNotice).filter(AbsenceNotice.student_id==sid).order_by(AbsenceNotice.issued_date.desc()).all()
        notices_out = [{"type":n.notice_type,"date":str(n.issued_date)} for n in notices]

        discipline = db.query(DisciplineRecord).filter(DisciplineRecord.student_id==sid).order_by(DisciplineRecord.date.desc()).limit(10).all()
        disc_out = [{"date":str(d.date),"violation":d.violation_type,"sanction":d.sanction_type} for d in discipline]

        last_scan = db.query(LocationScan).filter(LocationScan.student_id==sid).order_by(LocationScan.scanned_at.desc()).first()
        location = _scan_out(last_scan, db) if last_scan else None

        return ok({
            "student": {"name":s.full_name,"division":div.name if div else "","registration_num":s.registration_num},
            "grades": grades_out, "absences": abs_out, "unexcused_total": unexcused_total,
            "notices": notices_out, "discipline": disc_out, "last_location": location,
        })
    finally:
        db.close()

@app.get("/api/parent/child/<int:sid>/messages")
@gate_required("G24")
def parent_get_messages(sid):
    db = Session()
    try:
        if not _parent_owns(db, g.user_id, sid):
            return err("غير مسموح", 403)
        msgs = db.query(Message).filter(Message.student_id==sid).order_by(Message.created_at.asc()).all()
        return ok([{"id":m.id,"body":m.body,"sender_role":m.sender_role,
                    "time":m.created_at.isoformat() if m.created_at else None} for m in msgs])
    finally:
        db.close()

@app.post("/api/parent/child/<int:sid>/messages")
@gate_required("G24")
def parent_send_message(sid):
    data = request.get_json() or {}
    body = (data.get("body") or "").strip()
    if not body: return err("الرسالة فارغة")
    db = Session()
    try:
        if not _parent_owns(db, g.user_id, sid):
            return err("غير مسموح", 403)
        m = Message(student_id=sid, sender_id=g.user_id, sender_role="parent", body=body)
        db.add(m); db.commit()
        return ok(msg="تم إرسال الرسالة", code=201)
    finally:
        db.close()

@app.get("/api/messages/inbox")
@gate_required("G13")
def staff_inbox():
    """صندوق وارد رسائل الأولياء — لطاقم الإدارة (المدير/الناظر/المستشار)"""
    db = Session()
    try:
        unread_ids = [m.student_id for m in db.query(Message).filter(Message.sender_role=="parent", Message.is_read==False).all()]
        student_ids = list({m.student_id for m in db.query(Message).all()})
        out = []
        for sid in student_ids:
            s = db.query(Student).filter(Student.id==sid).first()
            if not s: continue
            last = db.query(Message).filter(Message.student_id==sid).order_by(Message.created_at.desc()).first()
            out.append({"student_id":sid,"student_name":s.full_name,
                       "last_message":last.body[:80] if last else "",
                       "unread": sid in unread_ids,
                       "time": last.created_at.isoformat() if last and last.created_at else None})
        out.sort(key=lambda x: x["time"] or "", reverse=True)
        return ok(out)
    finally:
        db.close()

@app.get("/api/messages/<int:sid>/thread")
@gate_required("G13")
def staff_thread(sid):
    """محادثة كاملة مع ولي تلميذ معيّن — لطاقم الإدارة"""
    db = Session()
    try:
        if not db.query(Student).filter(Student.id==sid).first():
            return err("التلميذ غير موجود", 404)
        msgs = db.query(Message).filter(Message.student_id==sid).order_by(Message.created_at.asc()).all()
        return ok([{"id":m.id,"body":m.body,"sender_role":m.sender_role,
                    "time":m.created_at.isoformat() if m.created_at else None} for m in msgs])
    finally:
        db.close()

@app.post("/api/messages/<int:sid>/reply")
@gate_required("G13")
def staff_reply(sid):
    data = request.get_json() or {}
    body = (data.get("body") or "").strip()
    if not body: return err("الرسالة فارغة")
    db = Session()
    try:
        if not db.query(Student).filter(Student.id==sid).first():
            return err("التلميذ غير موجود",404)
        m = Message(student_id=sid, sender_id=g.user_id, sender_role="staff", body=body)
        db.add(m)
        db.query(Message).filter(Message.student_id==sid, Message.sender_role=="parent").update({"is_read":True})
        db.commit()
        return ok(msg="تم الرد", code=201)
    finally:
        db.close()

# ════════════════ وثائق الموظفين (الموارد البشرية) ════════════════
@app.get("/api/documents/staff/<int:uid>")
@gate_required("G10")
def staff_docs(uid):
    db = Session()
    try:
        docs = db.query(OfficialDocument).filter(OfficialDocument.staff_user_id==uid).order_by(OfficialDocument.issued_date.desc()).all()
        return ok([{"id":d.id,"type":d.doc_type,"number":d.doc_number,"date":str(d.issued_date)} for d in docs])
    finally:
        db.close()

@app.post("/api/documents/staff/<int:uid>/leave-request")
@gate_required("G10")
def staff_leave_request(uid):
    data = request.get_json() or {}
    db = Session()
    try:
        si = SI(db)
        u = db.query(User).filter(User.id==uid).first()
        if not u: return err("الموظف غير موجود",404)
        content = StaffDocService.build_leave_request(
            u.full_name, {"name_ar":si.name_ar,"wilaya":si.wilaya,"academic_year":si.academic_year},
            data.get("start_date",""), data.get("end_date",""), data.get("reason",""))
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type=="leave_request").count()+1
        doc_num = DocNumberService.gen("leave_request", si.school_code or "00000", seq)
        content["doc_number"]=doc_num
        doc = OfficialDocument(doc_type="leave_request", doc_number=doc_num, staff_user_id=uid,
                                issued_date=date.today(), content_json=json.dumps(content,ensure_ascii=False),
                                issued_by=g.user_id)
        db.add(doc); db.commit(); db.refresh(doc)
        write_audit(g.user_id,"STAFF_LEAVE_REQUEST","user",uid)
        return ok({"doc_number":doc_num,"content":content,"doc_id":doc.id})
    finally:
        db.close()

@app.post("/api/documents/staff/<int:uid>/inquiry")
@gate_required("G10")
def staff_inquiry(uid):
    data = request.get_json() or {}
    db = Session()
    try:
        si = SI(db)
        u = db.query(User).filter(User.id==uid).first()
        if not u: return err("الموظف غير موجود",404)
        content = StaffDocService.build_inquiry(
            u.full_name, {"name_ar":si.name_ar,"wilaya":si.wilaya,"academic_year":si.academic_year},
            data.get("reason",""))
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type=="inquiry").count()+1
        doc_num = DocNumberService.gen("inquiry", si.school_code or "00000", seq)
        content["doc_number"]=doc_num
        doc = OfficialDocument(doc_type="inquiry", doc_number=doc_num, staff_user_id=uid,
                                issued_date=date.today(), content_json=json.dumps(content,ensure_ascii=False),
                                issued_by=g.user_id)
        db.add(doc); db.commit(); db.refresh(doc)
        write_audit(g.user_id,"STAFF_INQUIRY","user",uid)
        return ok({"doc_number":doc_num,"content":content,"doc_id":doc.id})
    finally:
        db.close()

@app.post("/api/documents/staff/<int:uid>/salary-deduction")
@gate_required("G10")
def staff_salary_deduction(uid):
    data = request.get_json() or {}
    db = Session()
    try:
        si = SI(db)
        u = db.query(User).filter(User.id==uid).first()
        if not u: return err("الموظف غير موجود",404)
        content = StaffDocService.build_salary_deduction(
            u.full_name, {"name_ar":si.name_ar,"wilaya":si.wilaya,"academic_year":si.academic_year},
            data.get("days",1), data.get("reason",""))
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type=="salary_deduction").count()+1
        doc_num = DocNumberService.gen("salary_deduction", si.school_code or "00000", seq)
        content["doc_number"]=doc_num
        doc = OfficialDocument(doc_type="salary_deduction", doc_number=doc_num, staff_user_id=uid,
                                issued_date=date.today(), content_json=json.dumps(content,ensure_ascii=False),
                                issued_by=g.user_id)
        db.add(doc); db.commit(); db.refresh(doc)
        write_audit(g.user_id,"STAFF_SALARY_DEDUCTION","user",uid)
        return ok({"doc_number":doc_num,"content":content,"doc_id":doc.id})
    finally:
        db.close()

ROLE_LABELS_AR = {
    "director": "مدير(ة) المؤسسة", "nazir": "ناظر(ة)", "counselor": "مستشار(ة) التربية", "supervisor_general": "مشرف(ة) عام(ة)",
    "teacher": "أستاذ(ة)", "admin": "عون إدارة", "accountant": "مقتصد(ة) / مسير(ة) مالي",
    "supervisor": "مشرف(ة) تربية", "worker": "عامل مهني",
}

@app.post("/api/documents/staff/<int:uid>/work-certificate")
@gate_required("G10")
def staff_work_certificate(uid):
    db = Session()
    try:
        si = SI(db)
        u = db.query(User).filter(User.id == uid).first()
        if not u: return err("الموظف غير موجود", 404)
        role_label = ROLE_LABELS_AR.get(u.role, u.role)
        content = StaffDocService.build_work_certificate(
            u.full_name, role_label,
            {"name_ar": si.name_ar, "wilaya": si.wilaya, "academic_year": si.academic_year},
            None)
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type == "work_certificate").count() + 1
        doc_num = DocNumberService.gen("work_certificate", si.school_code or "00000", seq)
        content["doc_number"] = doc_num
        doc = OfficialDocument(doc_type="work_certificate", doc_number=doc_num, staff_user_id=uid,
                                issued_date=date.today(), content_json=json.dumps(content, ensure_ascii=False),
                                issued_by=g.user_id)
        db.add(doc); db.commit(); db.refresh(doc)
        write_audit(g.user_id, "STAFF_WORK_CERT", "user", uid)
        return ok({"doc_number": doc_num, "content": content, "doc_id": doc.id})
    finally:
        db.close()

@app.post("/api/documents/staff/<int:uid>/id-card")
@gate_required("G10")
def staff_id_card(uid):
    db = Session()
    try:
        si = SI(db)
        u = db.query(User).filter(User.id == uid).first()
        if not u: return err("الموظف غير موجود", 404)
        role_label = ROLE_LABELS_AR.get(u.role, u.role)
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type == "staff_id_card").count() + 1
        doc_num = DocNumberService.gen("staff_id_card", si.school_code or "00000", seq)
        content = {"doc_number": doc_num, "school_name": si.name_ar, "academic_year": si.academic_year,
                   "full_name": u.full_name, "role_label": role_label,
                   "photo_path": u.photo_path or ""}
        doc = OfficialDocument(doc_type="staff_id_card", doc_number=doc_num, staff_user_id=uid,
                                issued_date=date.today(), content_json=json.dumps(content, ensure_ascii=False),
                                issued_by=g.user_id)
        db.add(doc); db.commit(); db.refresh(doc)
        write_audit(g.user_id, "STAFF_ID_CARD", "user", uid)
        return ok({"doc_number": doc_num, "content": content, "doc_id": doc.id})
    finally:
        db.close()

def _render_staff_doc_html(doc_type, content, si):
    """يُنتج HTML قابلاً للطباعة من محتوى وثيقة موظف مخزَّنة — تُستعمل لطباعة
    أي وثيقة موظف (رخصة/استفسار/خصم/شهادة عمل/بطاقة) عبر مسار موحّد واحد."""
    level_director = level_label(si, "director")
    if doc_type == "staff_id_card":
        photo_html = (f'<img src="{content.get("photo_path")}" style="width:90px;height:100px;object-fit:cover;border:1px solid #999">'
                      if content.get("photo_path") else
                      '<div style="width:90px;height:100px;border:2px dashed #999;display:flex;align-items:center;justify-content:center;font-size:11px;color:#999">صورة</div>')
        body = f"""
        <div style="width:340px;border:2px solid #333;border-radius:10px;padding:14px;text-align:center;margin:0 auto">
          <div style="font-size:11px;font-weight:600">{content.get('school_name','')}</div>
          <div style="font-size:11px">{content.get('academic_year','')}</div>
          <h3>بطاقة تعريف موظف</h3>
          <div style="display:flex;justify-content:center;margin:10px 0">{photo_html}</div>
          <div><b>{content.get('full_name','')}</b></div>
          <div style="font-size:12px;color:#555">{content.get('role_label','')}</div>
          <div style="font-size:11px;margin-top:8px">رقم: {content.get('doc_number','')}</div>
        </div>"""
        return _doc_page("بطاقة تعريف موظف", body, si=si)
    subject = content.get("subject", doc_type)
    body_text = content.get("body", "")
    extra = ""
    if doc_type == "leave_request":
        extra = f"<p><b>من:</b> {content.get('start_date','')} &nbsp; <b>إلى:</b> {content.get('end_date','')}</p>"
    body = f"""
    <div class="doc-no">رقم: {content.get('doc_number','')}</div>
    <div class="title">{subject}</div>
    <p style="line-height:2.2;font-size:14px">إلى السيد(ة): {content.get('staff_name','')}</p>
    {extra}
    <p style="line-height:2.2;font-size:14px;white-space:pre-line">{body_text}</p>
    <div class="sign" style="justify-content:flex-end"><div>{level_director}<br>{si.director_name or ''}</div></div>
    """
    return _doc_page(subject, body, si=si)

@app.get("/api/documents/staff/print/<int:doc_id>")
@gate_required("G10")
def print_staff_doc(doc_id):
    """طباعة موحّدة لأي وثيقة موظف مسجَّلة (رخصة غياب/استفسار/خصم/شهادة عمل/بطاقة تعريف)
    — زر 🖨️ واحد أمام كل وثيقة في قائمة وثائق الموظف."""
    db = Session()
    try:
        si = SI(db)
        d = db.query(OfficialDocument).filter(OfficialDocument.id == doc_id, OfficialDocument.staff_user_id != None).first()
        if not d:
            return Response("الوثيقة غير موجودة", mimetype="text/html")
        content = json.loads(d.content_json or "{}")
        return Response(_render_staff_doc_html(d.doc_type, content, si), mimetype="text/html")
    finally:
        db.close()

# ════════════════ مراسلة ولي التلميذ (غير الاستدعاء) ════════════════
@app.post("/api/documents/parent-letter/<int:sid>")
@gate_required("G13")
def parent_letter(sid):
    """مراسلة حرة لولي التلميذ (خبر، تنبيه، طلب...) بخلاف استدعاء الحضور الرسمي."""
    data = request.get_json() or {}
    subject = (data.get("subject") or "مراسلة إلى ولي التلميذ").strip()
    body_text = (data.get("body") or "").strip()
    if not body_text:
        return err("اكتب نص المراسلة")
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id == sid).first()
        if not s: return err("غير موجود", 404)
        div = db.query(Division).filter(Division.id == s.division_id).first()
        seq = db.query(OfficialDocument).filter(OfficialDocument.doc_type == "parent_letter").count() + 1
        doc_num = DocNumberService.gen("parent_letter", si.school_code or "00000", seq)
        content = {
            "doc_number": doc_num, "subject": subject, "body": body_text,
            "student_name": s.full_name, "division": div.name if div else "",
        }
        doc = OfficialDocument(doc_type="parent_letter", doc_number=doc_num, student_id=sid,
                                issued_date=date.today(), content_json=json.dumps(content, ensure_ascii=False),
                                issued_by=g.user_id)
        db.add(doc); db.commit(); db.refresh(doc)
        write_audit(g.user_id, "PARENT_LETTER", "student", sid)
        return ok({"doc_number": doc_num, "doc_id": doc.id})
    finally:
        db.close()

@app.get("/api/documents/parent-letter/print/<int:doc_id>")
@gate_required("G13")
def print_parent_letter(doc_id):
    db = Session()
    try:
        si = SI(db)
        d = db.query(OfficialDocument).filter(OfficialDocument.id == doc_id, OfficialDocument.doc_type == "parent_letter").first()
        if not d: return Response("الوثيقة غير موجودة", mimetype="text/html")
        c = json.loads(d.content_json or "{}")
        body = f"""
        <div class="doc-no">رقم: {c.get('doc_number','')}</div>
        <div class="title">{c.get('subject','')}</div>
        <p style="font-size:13px">إلى السيد(ة) ولي التلميذ(ة): <b>{c.get('student_name','')}</b> — القسم: {c.get('division','')}</p>
        <p style="line-height:2.2;font-size:14px;white-space:pre-line;margin-top:20px">{c.get('body','')}</p>
        <div class="sign" style="justify-content:flex-end"><div>{level_label(si,'director')}<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page(c.get('subject','مراسلة'), body, si=si), mimetype="text/html")
    finally:
        db.close()

# ════════════════ قوائم ذات صلة صحية/اجتماعية (تُبنى آلياً من بيانات التلميذ) ════════════════
def _print_student_flag_list(title, students, si, extra_col_label=None, extra_col_fn=None):
    rows = "".join(
        f"<tr><td>{i+1}</td><td>{s.registration_num or ''}</td><td>{s.last_name_ar} {s.first_name_ar}</td>"
        f"<td>{(s.division.name if s.division else '')}</td>"
        f"<td>{extra_col_fn(s) if extra_col_fn else ''}</td></tr>"
        for i, s in enumerate(students)
    ) or f"<tr><td colspan='5'>لا يوجد تلاميذ في هذه القائمة</td></tr>"
    body = f"""
    <div class="title">{title}</div>
    <table><thead><tr><th>الرقم</th><th>رقم التسجيل</th><th>اللقب والاسم</th><th>القسم</th><th>{extra_col_label or ''}</th></tr></thead>
    <tbody>{rows}</tbody></table>
    <div style="margin-top:14px;font-size:12px">العدد الإجمالي: {len(students)}</div>
    <div class="sign"><div>مستشار التربية<br>{si.counselor_name or ''}</div><div>الناظر<br>{si.nazir_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
    """
    return _doc_page(title, body, si=si)

@app.get("/api/reports/pe-exempt")
@gate_required("G12")
def report_pe_exempt():
    db = Session()
    try:
        si = SI(db)
        students = db.query(Student).filter(Student.pe_exempt == True, Student.is_active == True).order_by(Student.last_name_ar).all()
        return Response(_print_student_flag_list("قائمة التلاميذ المعفيين من التربية البدنية", students, si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/reports/health-status")
@gate_required("G12")
def report_health_status():
    db = Session()
    try:
        si = SI(db)
        students = db.query(Student).filter(Student.health_status != "", Student.health_status.isnot(None), Student.is_active == True).order_by(Student.last_name_ar).all()
        return Response(_print_student_flag_list("قائمة التلاميذ ذوي الحالات الصحية الخاصة", students, si,
                         extra_col_label="الحالة الصحية", extra_col_fn=lambda s: s.health_status or ""), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/reports/orphans")
@gate_required("G12")
def report_orphans():
    db = Session()
    try:
        si = SI(db)
        students = db.query(Student).filter(Student.is_orphan == True, Student.is_active == True).order_by(Student.last_name_ar).all()
        return Response(_print_student_flag_list("قائمة التلاميذ الأيتام", students, si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/reports/parents-separated")
@gate_required("G12")
def report_parents_separated():
    db = Session()
    try:
        si = SI(db)
        students = db.query(Student).filter(Student.parents_separated == True, Student.is_active == True).order_by(Student.last_name_ar).all()
        return Response(_print_student_flag_list("قائمة تلاميذ حالات انفصال الوالدين", students, si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/reports/scholarship")
@gate_required("G12")
def report_scholarship():
    db = Session()
    try:
        si = SI(db)
        students = db.query(Student).filter(Student.is_scholarship == True, Student.is_active == True).order_by(Student.last_name_ar).all()
        return Response(_print_student_flag_list("قائمة التلاميذ الممنوحين (منحة دراسية)", students, si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/reports/attendance-present/<int:div_id>/<rdate>")
@gate_required("G02")
def report_attendance_present(div_id, rdate):
    """كشف التلاميذ الحاضرين لقسم في يوم معيّن (كل تلاميذ القسم عدا من له غياب مسجَّل ذلك اليوم)."""
    db = Session()
    try:
        si = SI(db)
        div = db.query(Division).filter(Division.id == div_id).first()
        if not div: return Response("القسم غير موجود", mimetype="text/html")
        d = _parse_date_field(rdate)
        absent_ids = {a.student_id for a in db.query(Absence).filter(Absence.division_id == div_id, Absence.date == d).all()}
        students = db.query(Student).filter(Student.division_id == div_id, Student.is_active == True).order_by(Student.last_name_ar).all()
        present = [s for s in students if s.id not in absent_ids]
        rows = "".join(
            f"<tr><td>{i+1}</td><td>{s.registration_num or ''}</td><td>{s.last_name_ar} {s.first_name_ar}</td><td>{s.gender}</td></tr>"
            for i, s in enumerate(present)
        ) or "<tr><td colspan='4'>لا يوجد تلاميذ حاضرون</td></tr>"
        body = f"""
        <div class="title">كشف التلاميذ الحاضرين — قسم {div.name}</div>
        <p><b>التاريخ:</b> {rdate}</p>
        <table><thead><tr><th>الرقم</th><th>رقم التسجيل</th><th>اللقب والاسم</th><th>الجنس</th></tr></thead>
        <tbody>{rows}</tbody></table>
        <div style="margin-top:14px;font-size:12px">الحاضرون: {len(present)} من أصل {len(students)}</div>
        <div class="sign"><div>مستشار التربية<br>{si.counselor_name or ''}</div><div>الناظر<br>{si.nazir_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page(f"الحاضرون — {div.name}", body, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/reports/monthly-attendance/<mn>")
@gate_required("G12")
def report_monthly_attendance(mn):
    """كشف الحضور لنهاية الشهر — يطابق نموذج الوزارة بعمود المعيدين منفصلاً عن باقي
    التلاميذ، مع تفصيل داخلي/نصف داخلي/خارجي لكل قسم. mn مثال: 2026-04."""
    db = Session()
    try:
        si = SI(db)
        divs = _sort_divs(db.query(Division).filter(Division.is_active == True).all())
        rows = ""
        gtot = {"rep_m":0,"rep_f":0,"m":0,"f":0,"int_m":0,"int_f":0,"half_m":0,"half_f":0,"ext_m":0,"ext_f":0}
        for div in divs:
            students = db.query(Student).filter(Student.division_id == div.id, Student.is_active == True).all()
            rep = [s for s in students if s.is_repeating]
            rep_m = sum(1 for s in rep if s.gender == "ذكر"); rep_f = len(rep) - rep_m
            m = sum(1 for s in students if s.gender == "ذكر"); f = len(students) - m
            def cnt(status, gender): return sum(1 for s in students if s.status == status and s.gender == gender)
            int_m, int_f = cnt("داخلي","ذكر"), cnt("داخلي","أنثى")
            half_m, half_f = cnt("نصف داخلي","ذكر"), cnt("نصف داخلي","أنثى")
            ext_m, ext_f = cnt("خارجي","ذكر"), cnt("خارجي","أنثى")
            total = m + f
            for k, v in [("rep_m",rep_m),("rep_f",rep_f),("m",m),("f",f),("int_m",int_m),("int_f",int_f),
                         ("half_m",half_m),("half_f",half_f),("ext_m",ext_m),("ext_f",ext_f)]:
                gtot[k] += v
            rows += (f"<tr><td>{div.name}</td><td>{m-rep_m}</td><td>{f-rep_f}</td><td>{total-rep_m-rep_f}</td>"
                     f"<td>{rep_m}</td><td>{rep_f}</td><td>{rep_m+rep_f}</td>"
                     f"<td>{m}</td><td>{f}</td><td><b>{total}</b></td><td>{int_m}</td><td>{int_f}</td>"
                     f"<td>{half_m}</td><td>{half_f}</td><td>{ext_m}</td><td>{ext_f}</td></tr>")
        grand_total = gtot["m"] + gtot["f"]
        grep_t = gtot["rep_m"] + gtot["rep_f"]
        rows += (f"<tr style='font-weight:700;background:#eee'><td>المجموع الكلي</td>"
                 f"<td>{gtot['m']-gtot['rep_m']}</td><td>{gtot['f']-gtot['rep_f']}</td><td>{grand_total-grep_t}</td>"
                 f"<td>{gtot['rep_m']}</td><td>{gtot['rep_f']}</td><td>{grep_t}</td>"
                 f"<td>{gtot['m']}</td><td>{gtot['f']}</td><td>{grand_total}</td>"
                 f"<td>{gtot['int_m']}</td><td>{gtot['int_f']}</td><td>{gtot['half_m']}</td><td>{gtot['half_f']}</td>"
                 f"<td>{gtot['ext_m']}</td><td>{gtot['ext_f']}</td></tr>")
        body = f"""
        <div class="title">كشف الحضور لنهاية شهر: {mn}</div>
        <table style="font-size:11px"><thead><tr><th rowspan="2">القسم</th>
        <th colspan="3">جدد</th><th colspan="3">معيدون</th><th colspan="3">المجموع</th><th colspan="2">داخلي</th>
        <th colspan="2">نصف داخلي</th><th colspan="2">خارجي</th></tr>
        <tr><th>ذكور</th><th>إناث</th><th>مج</th><th>ذكور</th><th>إناث</th><th>مج</th><th>ذكور</th><th>إناث</th><th>مج</th>
        <th>ذكور</th><th>إناث</th><th>ذكور</th><th>إناث</th><th>ذكور</th><th>إناث</th></tr></thead>
        <tbody>{rows}</tbody></table>
        <div class="sign" style="margin-top:20px"><div>المقتصد<br>{si.bursar_name or ''}</div><div>الناظر<br>{si.nazir_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("كشف الحضور لنهاية الشهر", body, si=si, landscape=True), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/reports/census")
@gate_required("G12")
def report_census():
    """التعداد العام: عدد التلاميذ حسب المستوى/القسم والجنس ونظام التمدرس."""
    db = Session()
    try:
        si = SI(db)
        divs = _sort_divs(db.query(Division).filter(Division.is_active == True).all())
        rows, tot_m, tot_f, tot_int, tot_half, tot_ext = "", 0, 0, 0, 0, 0
        for div in divs:
            students = db.query(Student).filter(Student.division_id == div.id, Student.is_active == True).all()
            m = sum(1 for s in students if s.gender == "ذكر")
            f = len(students) - m
            intern = sum(1 for s in students if s.status == "داخلي")
            half = sum(1 for s in students if s.status == "نصف داخلي")
            ext = sum(1 for s in students if s.status == "خارجي")
            tot_m += m; tot_f += f; tot_int += intern; tot_half += half; tot_ext += ext
            rows += f"<tr><td>{div.name}</td><td>{len(students)}</td><td>{m}</td><td>{f}</td><td>{intern}</td><td>{half}</td><td>{ext}</td></tr>"
        total = tot_m + tot_f
        rows += (f"<tr style='font-weight:700'><td>المجموع العام</td><td>{total}</td><td>{tot_m}</td>"
                 f"<td>{tot_f}</td><td>{tot_int}</td><td>{tot_half}</td><td>{tot_ext}</td></tr>")
        body = f"""
        <div class="title">التعداد العام للتلاميذ — {si.academic_year}</div>
        <table><thead><tr><th>القسم</th><th>المجموع</th><th>ذكور</th><th>إناث</th><th>داخلي</th><th>نصف داخلي</th><th>خارجي</th></tr></thead>
        <tbody>{rows}</tbody></table>
        <div class="sign"><div>المقتصد<br>{si.bursar_name or ''}</div><div>الناظر<br>{si.nazir_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("التعداد العام", body, si=si), mimetype="text/html")
    finally:
        db.close()

# ════════════════ التقرير العام للتسيير ════════════════
def _build_general_management_data(db):
    """يجمع مؤشرات التسيير العامة للمؤسسة من كل الجداول الحقيقية (بدون أي
    رقم تجريبي): التلاميذ، الموظفون، الغياب، الانضباط، الوثائق، بوابة
    الأولياء، والإشعارات التلقائية — يُستعمل من واجهة JSON ومن نسخة الطباعة معاً."""
    si = SI(db)
    today = date.today()
    students_active = db.query(Student).filter(Student.is_active == True).count()
    students_total = db.query(Student).count()
    students_expelled = db.query(Student).filter(Student.is_expelled == True).count()
    males = db.query(Student).filter(Student.is_active == True, Student.gender == "ذكر").count()
    females = db.query(Student).filter(Student.is_active == True, Student.gender == "أنثى").count()
    orphans = db.query(Student).filter(Student.is_active == True, Student.is_orphan == True).count()
    scholarship = db.query(Student).filter(Student.is_active == True, Student.is_scholarship == True).count()
    pe_exempt = db.query(Student).filter(Student.is_active == True, Student.pe_exempt == True).count()
    disability = db.query(Student).filter(Student.is_active == True, Student.has_disability == True).count()
    parents_sep = db.query(Student).filter(Student.is_active == True, Student.parents_separated == True).count()

    staff_total = db.query(User).filter(User.is_active == True).count()
    staff_by_role = {}
    for u in db.query(User).filter(User.is_active == True).all():
        staff_by_role[u.role] = staff_by_role.get(u.role, 0) + 1

    divisions_active = db.query(Division).filter(Division.is_active == True).count()

    year_start = date(today.year if today.month >= 9 else today.year - 1, 9, 1)
    absences_ytd = db.query(Absence).filter(Absence.date >= year_start).count()
    unexcused_ytd = db.query(Absence).filter(Absence.date >= year_start, Absence.status == "غير مبرر").count()
    justified_ytd = absences_ytd - unexcused_ytd
    notices_ytd = db.query(AbsenceNotice).filter(AbsenceNotice.issued_date >= year_start).count()
    notices_by_type = {}
    for n in db.query(AbsenceNotice).filter(AbsenceNotice.issued_date >= year_start).all():
        notices_by_type[n.notice_type] = notices_by_type.get(n.notice_type, 0) + 1

    discipline_ytd = db.query(DisciplineRecord).filter(DisciplineRecord.date >= year_start).count()
    docs_ytd = db.query(OfficialDocument).filter(OfficialDocument.issued_date >= year_start).count()
    docs_by_type = {}
    for d in db.query(OfficialDocument).filter(OfficialDocument.issued_date >= year_start).all():
        docs_by_type[d.doc_type] = docs_by_type.get(d.doc_type, 0) + 1

    parents_active = db.query(User).filter(User.role == "parent", User.is_active == True).count()
    parents_pending = db.query(User).filter(User.role == "parent", User.is_active == False).count()

    notif_sent = db.query(NotificationLog).filter(NotificationLog.status == "sent").count()
    notif_failed = db.query(NotificationLog).filter(NotificationLog.status == "failed").count()
    notif_skipped = db.query(NotificationLog).filter(NotificationLog.status == "skipped").count()

    attendance_scans_today = db.query(LocationScan).join(
        CheckPoint, LocationScan.checkpoint_id == CheckPoint.id
    ).filter(CheckPoint.code == "ATTEND", sa_func.date(LocationScan.scanned_at) == today).count()

    return {
        "generated_at": datetime.now().isoformat(),
        "academic_year": si.academic_year,
        "school": {"name_ar": si.name_ar, "wilaya": si.wilaya, "commune": si.commune,
                   "director_name": si.director_name, "level_type": si.level_type},
        "students": {"active": students_active, "total": students_total, "expelled": students_expelled,
                     "males": males, "females": females, "orphans": orphans, "scholarship": scholarship,
                     "pe_exempt": pe_exempt, "disability": disability, "parents_separated": parents_sep,
                     "divisions_active": divisions_active},
        "staff": {"total": staff_total, "by_role": staff_by_role},
        "attendance": {"scans_today": attendance_scans_today},
        "absences": {"total_ytd": absences_ytd, "unexcused_ytd": unexcused_ytd, "justified_ytd": justified_ytd,
                     "notices_ytd": notices_ytd, "notices_by_type": notices_by_type},
        "discipline": {"records_ytd": discipline_ytd},
        "documents": {"issued_ytd": docs_ytd, "by_type": docs_by_type},
        "parent_portal": {"active_accounts": parents_active, "pending_accounts": parents_pending},
        "notifications": {"sent": notif_sent, "failed": notif_failed, "skipped": notif_skipped},
    }

@app.get("/api/reports/general-management")
@gate_required("G12")
def report_general_management():
    """التقرير العام للتسيير: لوحة مؤشرات شاملة لحالة المؤسسة (تلاميذ، موظفون،
    غياب، انضباط، وثائق، بوابة أولياء، إشعارات) — بيانات حية 100% من قاعدة
    البيانات الحقيقية، بلا أي رقم افتراضي أو تجريبي."""
    db = Session()
    try:
        return ok(_build_general_management_data(db))
    finally:
        db.close()

@app.get("/api/reports/general-management/print")
@gate_required("G12")
def print_general_management():
    db = Session()
    try:
        d = _build_general_management_data(db)
        si = SI(db)
        st, sf, disc, docs, pp, nt, staffb = (d["students"], d["staff"], d["discipline"],
                                               d["documents"], d["parent_portal"], d["notifications"], d["staff"]["by_role"])
        staff_rows = "".join(f"<tr><td>{role}</td><td>{cnt}</td></tr>" for role, cnt in staffb.items()) or "<tr><td colspan='2'>—</td></tr>"
        notices_rows = "".join(f"<tr><td>{t}</td><td>{c}</td></tr>" for t, c in d["absences"]["notices_by_type"].items()) or "<tr><td colspan='2'>لا يوجد</td></tr>"
        docs_rows = "".join(f"<tr><td>{t}</td><td>{c}</td></tr>" for t, c in docs["by_type"].items()) or "<tr><td colspan='2'>لا يوجد</td></tr>"
        body = f"""
        <div class="title">التقرير العام للتسيير — {si.academic_year}</div>
        <p style="text-align:center;font-size:12px;color:#555">تاريخ الإصدار: {date.today().strftime('%Y-%m-%d')}</p>

        <h3 style="margin-top:20px">1) التلاميذ والأقسام</h3>
        <table><tbody>
          <tr><td>التلاميذ النشطون</td><td>{st['active']}</td><td>ذكور</td><td>{st['males']}</td><td>إناث</td><td>{st['females']}</td></tr>
          <tr><td>الأقسام النشطة</td><td>{st['divisions_active']}</td><td>مطرودون</td><td>{st['expelled']}</td><td>ذوو احتياجات خاصة</td><td>{st['disability']}</td></tr>
          <tr><td>أيتام</td><td>{st['orphans']}</td><td>ممنوحون</td><td>{st['scholarship']}</td><td>معفَون من ت.ب.ر</td><td>{st['pe_exempt']}</td></tr>
          <tr><td>أولياء منفصلون</td><td>{st['parents_separated']}</td><td colspan="4"></td></tr>
        </tbody></table>

        <h3 style="margin-top:20px">2) الموظفون ({sf['total']})</h3>
        <table><thead><tr><th>الفئة</th><th>العدد</th></tr></thead><tbody>{staff_rows}</tbody></table>

        <h3 style="margin-top:20px">3) الغياب والإشعارات القانونية (منذ بداية السنة الدراسية)</h3>
        <table><tbody>
          <tr><td>إجمالي الغيابات</td><td>{d['absences']['total_ytd']}</td><td>غير مبرر</td><td>{d['absences']['unexcused_ytd']}</td><td>مبرر</td><td>{d['absences']['justified_ytd']}</td></tr>
        </tbody></table>
        <table><thead><tr><th>نوع الإشعار</th><th>العدد</th></tr></thead><tbody>{notices_rows}</tbody></table>

        <h3 style="margin-top:20px">4) الانضباط والوثائق الرسمية</h3>
        <table><tbody><tr><td>حالات تأديبية (منذ بداية السنة)</td><td>{disc['records_ytd']}</td><td>وثائق صادرة (منذ بداية السنة)</td><td>{docs['issued_ytd']}</td></tr></tbody></table>
        <table><thead><tr><th>نوع الوثيقة</th><th>العدد</th></tr></thead><tbody>{docs_rows}</tbody></table>

        <h3 style="margin-top:20px">5) بوابة الأولياء والإشعارات التلقائية</h3>
        <table><tbody>
          <tr><td>حسابات أولياء مفعَّلة</td><td>{pp['active_accounts']}</td><td>بانتظار التفعيل</td><td>{pp['pending_accounts']}</td></tr>
          <tr><td>إشعارات مُرسَلة بنجاح</td><td>{nt['sent']}</td><td>فاشلة</td><td>{nt['failed']}</td><td>متخطّاة (لا بيانات اتصال)</td><td>{nt['skipped']}</td></tr>
        </tbody></table>

        <div class="sign"><div>مستشار التربية<br>{si.counselor_name or ''}</div><div>الناظر<br>{si.nazir_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("التقرير العام للتسيير", body, landscape=True, si=si), mimetype="text/html")
    finally:
        db.close()

@app.get("/api/documents/transcript/<int:sid>/<term>")
@gate_required("G06")
def print_transcript(sid, term):
    """كشف نقاط التلميذ لفصل معيّن — مبني من بيانات النقاط الحية (Grade/TermResult)،
    بأعمدة مطابقة لكشف نقاط الوزارة: المعامل، المجموع (=المعدل×المعامل)، المعدل السنوي
    (متوسط الفصول الثلاثة)، وملاحظة تربوية آلية حسب مستوى المعدل."""
    def remark(avg):
        if avg is None: return ""
        if avg >= 16: return "نتائج ممتازة، واصل(ي) بنفس الجهد"
        if avg >= 14: return "نتائج جيدة جداً"
        if avg >= 12: return "نتائج جيدة، بإمكانك تحسينها بالاجتهاد أكثر"
        if avg >= 10: return "نتائج متوسطة، عليك بمزيد من الاجتهاد"
        return "نتائج ضعيفة جداً، عليك بضاعفة الجهد"
    db = Session()
    try:
        si = SI(db)
        s = db.query(Student).filter(Student.id == sid).first()
        if not s: return Response("التلميذ غير موجود", mimetype="text/html")
        div = db.query(Division).filter(Division.id == s.division_id).first()
        grades = (db.query(Grade)
                  .filter(Grade.student_id == sid, Grade.term == term)
                  .join(Subject, Grade.subject_id == Subject.id)
                  .order_by(Subject.sort_order).all())
        tr = db.query(TermResult).filter(TermResult.student_id == sid, TermResult.term == term).first()
        rows = ""
        total_weighted, total_coef = 0.0, 0
        for g_ in grades:
            subj = db.query(Subject).filter(Subject.id == g_.subject_id).first()
            coef = subj.coefficient if subj else 1
            avg = g_.term_average
            weighted = round(avg * coef, 2) if avg is not None else None
            if avg is not None:
                total_weighted += weighted; total_coef += coef
            all_terms = db.query(Grade).filter(Grade.student_id == sid, Grade.subject_id == g_.subject_id).all()
            yearly_vals = [t.term_average for t in all_terms if t.term_average is not None]
            yearly_avg = round(sum(yearly_vals) / len(yearly_vals), 2) if yearly_vals else None
            rows += (f"<tr><td>{subj.name_ar if subj else ''}</td><td>{coef}</td>"
                     f"<td>{g_.fard1 if g_.fard1 is not None else '—'}</td><td>{g_.fard2 if g_.fard2 is not None else '—'}</td>"
                     f"<td>{g_.activity if g_.activity is not None else '—'}</td>"
                     f"<td>{g_.exam_raw if g_.exam_raw is not None else '—'}</td>"
                     f"<td>{avg if avg is not None else '—'}</td>"
                     f"<td>{weighted if weighted is not None else '—'}</td>"
                     f"<td>{yearly_avg if yearly_avg is not None else '—'}</td>"
                     f"<td>{g_.comment or remark(avg)}</td></tr>")
        rows = rows or "<tr><td colspan='10'>لا توجد نقاط مسجّلة لهذا الفصل بعد</td></tr>"
        overall = round(total_weighted / total_coef, 2) if total_coef else (tr.term_average if tr else None)
        summary = (f"<p style='margin-top:14px'><b>المجموع العام:</b> {round(total_weighted,2)} &nbsp;&nbsp; "
                   f"<b>معامل المواد:</b> {total_coef} &nbsp;&nbsp; "
                   f"<b>المعدل الفصلي العام:</b> {overall if overall is not None else '—'} /20"
                   + (f" &nbsp;&nbsp; <b>الرتبة:</b> {tr.rank}" if tr and tr.rank else "")
                   + (f" &nbsp;&nbsp; <b>قرار المجلس:</b> {tr.council_decision}" if tr and tr.council_decision else "")
                   + f"</p><p style='font-size:12px;color:#555'>{remark(overall)}</p>")
        body = f"""
        <div class="title">كشف تقويم نتائج — {term.replace('_',' ')}</div>
        <p><b>اللقب والاسم:</b> {s.last_name_ar} {s.first_name_ar} &nbsp;&nbsp; <b>القسم:</b> {div.name if div else ''}
        &nbsp;&nbsp; <b>تاريخ الميلاد:</b> {s.birth_date or ''} &nbsp;&nbsp; <b>السنة الدراسية:</b> {si.academic_year}</p>
        <table><thead><tr><th>المادة</th><th>المعامل</th><th>الفرض(1)</th><th>الفرض(2)</th><th>معدل التمرين</th>
        <th>الاختبار/40</th><th>المعدل الفصلي/20</th><th>المجموع</th><th>المعدل السنوي</th><th>الملاحظة التربوية</th></tr></thead>
        <tbody>{rows}</tbody></table>
        {summary}
        <div class="sign"><div>مستشار التربية<br>{si.counselor_name or ''}</div><div>المدير(ة)<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("كشف نقاط", body, si=si), mimetype="text/html")
    finally:
        db.close()

# ════════════════ قائمة أبناء قطاع التربية (تُبنى آلياً) ════════════════
@app.get("/api/reports/sector-children")
@gate_required("G12")
def sector_children_report():
    """قائمة كل التلاميذ الذين أحد والديهم يعمل في قطاع التربية —
    تُبنى تلقائياً من حقلي father_in_education / mother_in_education."""
    db = Session()
    try:
        students = db.query(Student).filter(
            (Student.father_in_education==True) | (Student.mother_in_education==True)
        ).all()
        out = []
        for s in students:
            div = db.query(Division).filter(Division.id==s.division_id).first()
            out.append({
                "id": s.id, "name": s.full_name, "division": div.name if div else "",
                "father_in_education": s.father_in_education, "mother_in_education": s.mother_in_education,
                "father_name": s.father_name, "mother_name": s.mother_name,
            })
        return ok(out)
    finally:
        db.close()

@app.get("/api/documents/sector-children")
@gate_required("G12")
def print_sector_children():
    db = Session()
    try:
        si = SI(db)
        students = db.query(Student).filter(
            (Student.father_in_education==True) | (Student.mother_in_education==True)
        ).order_by(Student.last_name_ar).all()
        rows = "".join(
            f"<tr><td>{i+1}</td><td>{s.last_name_ar} {s.first_name_ar}</td>"
            f"<td>{(db.query(Division).filter(Division.id==s.division_id).first() or type('',(),{'name':'—'})()).name}</td>"
            f"<td>{s.father_name or '—' if s.father_in_education else '—'}</td>"
            f"<td>{s.mother_name or '—' if s.mother_in_education else '—'}</td></tr>"
            for i, s in enumerate(students)
        ) or "<tr><td colspan='5'>لا يوجد تلاميذ مسجَّلون كأبناء لقطاع التربية بعد</td></tr>"
        body = f"""
        <div class="title">قائمة أبناء موظفي قطاع التربية</div>
        <table><thead><tr><th>الرقم</th><th>اسم التلميذ</th><th>القسم</th><th>الأب (إن كان بالقطاع)</th><th>الأم (إن كانت بالقطاع)</th></tr></thead>
        <tbody>{rows}</tbody></table>
        <div class="sign" style="justify-content:flex-end"><div>مدير(ة) المؤسسة<br>{si.director_name or ''}</div></div>
        """
        return Response(_doc_page("أبناء قطاع التربية", body, landscape=True, si=si), mimetype="text/html")
    finally:
        db.close()

# ════════════════════════════════════════════════════════════════════
#  الجولة 18 — هوية المؤسسة العامة + بوابات الأستاذ والمشرف + مركز متابعة المدير
# ════════════════════════════════════════════════════════════════════
LOGO_EXT = {"jpg", "jpeg", "png", "webp", "svg"}

@app.get("/api/public/school")
def public_school():
    """هوية المؤسسة لصفحة الهبوط (بلا تسجيل دخول): الاسم، الشعار، اللون، أرقام عامة."""
    db = Session()
    try:
        si = SI(db)
        return ok({"name_ar": si.name_ar or "", "name_fr": si.name_fr or "", "wilaya": si.wilaya or "",
                   "commune": si.commune or "", "academic_year": si.academic_year or "",
                   "level_type": si.level_type or "متوسطة", "motto": si.motto or "",
                   "brand_color": si.brand_color or "#1B7F4B", "logo": si.logo_path or "",
                   "phone": si.phone or "", "email": si.email or "", "address": si.address or "",
                   "is_configured": bool(si.is_configured),
                   "stats": {"students": db.query(Student).filter(Student.is_active == True).count(),
                             "divisions": db.query(Division).filter(Division.is_active == True).count(),
                             "staff": db.query(User).filter(User.is_active == True, User.role != "parent").count()}})
    finally:
        db.close()

@app.post("/api/school-info/logo")
@gate_required("G20")
def upload_school_logo():
    """رفع شعار المؤسسة (png/jpg/webp/svg، حتى 2 ميغا) — يظهر في صفحة الهبوط والواجهة."""
    f = request.files.get("file")
    if not f or not f.filename:
        return err("لم يتم اختيار ملف")
    ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
    if ext not in LOGO_EXT:
        return err("الصيغة غير مدعومة — استعمل png أو jpg أو webp أو svg")
    data = f.read()
    if len(data) > 2 * 1024 * 1024:
        return err("حجم الشعار يتجاوز 2 ميغا")
    if ext == "svg" and (b"<script" in data.lower() or b"onload" in data.lower()):
        return err("ملف SVG غير آمن")
    import uuid
    fname = f"logo_{uuid.uuid4().hex[:12]}.{ext}"
    (UPLOADS_DIR / fname).write_bytes(data)
    db = Session()
    try:
        si = SI(db)
        si.logo_path = f"/uploads/photos/{fname}"
        db.commit()
        write_audit(g.user_id, "SCHOOL_LOGO")
        return ok({"logo": si.logo_path}, "تم حفظ الشعار")
    finally:
        db.close()

@app.delete("/api/school-info/logo")
@gate_required("G20")
def delete_school_logo():
    db = Session()
    try:
        si = SI(db); si.logo_path = ""; db.commit()
        return ok(msg="أُزيل الشعار")
    finally:
        db.close()

# ── أدوات مشتركة للبوابات ──
def _day_idx(d):
    """0=السبت … 5=الخميس (6=الجمعة)."""
    return (d.weekday() + 2) % 7

def _has_gate(*codes):
    return any(c in g.gates for c in codes)

def _norm_name(s):
    return " ".join(sorted((s or "").replace("ـ", "").split()))

def _my_teacher(db):
    """الأستاذ المرتبط بالحساب الحالي: بالربط المباشر user_id، وإلا بمطابقة الاسم الكامل (ويُحفظ الربط)."""
    t = db.query(Teacher).filter(Teacher.user_id == g.user_id).first()
    if t:
        return t
    u = db.query(User).filter(User.id == g.user_id).first()
    if not u:
        return None
    key = _norm_name(u.full_name)
    for t in db.query(Teacher).filter(Teacher.user_id.is_(None)).all():
        if _norm_name(f"{t.last_name} {t.first_name}") == key:
            t.user_id = g.user_id
            db.commit()
            return t
    return None

def _user_label(db, uid):
    u = db.query(User).filter(User.id == uid).first() if uid else None
    return (u.full_name, u.role) if u else ("—", "")

def _period_order(si):
    return {p: i for i, p in enumerate(_period_labels(si))}

def _sessions_coverage(db, si, d):
    """حصص اليوم المجدولة مقابل المسجَّلة (SessionCheck). حصة = قسم + رمز حصة."""
    from app.utils.timetable_print import period_times
    entries = db.query(ScheduleEntry).filter(ScheduleEntry.day_of_week == _day_idx(d),
                                             ScheduleEntry.academic_year == si.academic_year).all()
    checks = {(c.division_id, c.period) for c in db.query(SessionCheck).filter(SessionCheck.date == d).all()}
    divs = {x.id: x for x in db.query(Division).all()}
    subj = {x.id: x.name_ar for x in db.query(Subject).all()}
    teach = {x.id: x for x in db.query(Teacher).all()}
    order = _period_order(si)
    seen, rows = set(), []
    for e in entries:
        k = (e.division_id, e.period)
        if k in seen:
            continue
        seen.add(k)
        t = teach.get(e.teacher_id)
        rows.append({"division_id": e.division_id, "division": divs[e.division_id].name if e.division_id in divs else "",
                     "period": e.period, "subject": subj.get(e.subject_id, ""),
                     "teacher_id": e.teacher_id, "teacher": f"{t.last_name} {t.first_name}" if t else "—",
                     "teacher_user_id": t.user_id if t else None, "submitted": k in checks})
    rows.sort(key=lambda r: (order.get(r["period"], 99), r["division"]))
    return rows

@app.get("/api/portal/teacher/overview")
@gate_required("G25")
def portal_teacher_overview():
    """بوابة الأستاذ: حصص اليوم من استعمال الزمن مع حالة التسجيل، والأقسام التي يدرّسها."""
    from app.utils.timetable_print import period_times
    db = Session()
    try:
        si = SI(db)
        d = _parse_date_field(request.args.get("date")) or date.today()
        t = _my_teacher(db)
        labels = _period_labels(si)
        times = period_times(si, labels)
        order = _period_order(si)
        divs = {x.id: x for x in db.query(Division).all()}
        subj = {x.id: x.name_ar for x in db.query(Subject).all()}
        rooms = {x.id: x.name for x in db.query(Room).all()}
        sessions, taught = [], {}
        if t:
            ents = db.query(ScheduleEntry).filter(_tq(t.id), ScheduleEntry.academic_year == si.academic_year).all()
            for e in ents:
                if e.division_id in divs:
                    taught[e.division_id] = divs[e.division_id]
            done = {(c.division_id, c.period): c for c in db.query(SessionCheck).filter(SessionCheck.date == d).all()}
            for e in ents:
                if e.day_of_week != _day_idx(d) or e.division_id not in divs:
                    continue
                c = done.get((e.division_id, e.period))
                a, b = times.get(e.period, ("", ""))
                sessions.append({"division_id": e.division_id, "division": divs[e.division_id].name, "period": e.period,
                                 "time": f"{a}–{b}" if a else "", "subject": subj.get(e.subject_id, ""),
                                 "room": rooms.get(e.room_id, ""), "submitted": bool(c),
                                 "absent_count": c.absent_count if c else 0})
            sessions.sort(key=lambda r: order.get(r["period"], 99))
        div_list = _sort_divs(list(taught.values())) if t else _sort_divs(list(divs.values()))
        mine_abs = db.query(Absence).filter(Absence.entered_by == g.user_id, Absence.date == d).count()
        return ok({"date": str(d), "linked": bool(t),
                   "teacher": f"{t.last_name} {t.first_name}" if t else None,
                   "sessions": sessions, "periods": labels,
                   "divisions": [{"id": x.id, "name": x.name} for x in div_list],
                   "today_entries": mine_abs})
    finally:
        db.close()

@app.get("/api/portal/roster")
@login_required
def portal_roster():
    """قائمة تلاميذ قسم مع حالة غياب كل تلميذ في تاريخ/حصة معيّنين."""
    if not _has_gate("G25", "G26", "G02", "G27"):
        return err("ليس لديك صلاحية", 403)
    db = Session()
    try:
        did = int(request.args.get("division_id") or 0)
        d = _parse_date_field(request.args.get("date")) or date.today()
        period = (request.args.get("period") or "").strip()
        studs = db.query(Student).filter(Student.division_id == did, Student.is_active == True)\
                  .order_by(Student.last_name_ar, Student.first_name_ar).all()
        q = db.query(Absence).filter(Absence.division_id == did, Absence.date == d)
        q = q.filter(Absence.period == period) if period else q
        ab = {}
        for a in q.all():
            ab.setdefault(a.student_id, a)
        chk = db.query(SessionCheck).filter(SessionCheck.division_id == did, SessionCheck.date == d,
                                            SessionCheck.period == period).first() if period else None
        return ok({"submitted": bool(chk),
                   "students": [{"id": s.id, "name": f"{s.last_name_ar} {s.first_name_ar}", "gender": s.gender,
                                 "absent": s.id in ab, "justified": bool(ab.get(s.id) and ab[s.id].status != "غير مبرر")}
                                for s in studs]})
    finally:
        db.close()

@app.post("/api/portal/teacher/absences")
@gate_required("G25")
def portal_teacher_absences():
    """يحفظ غياب حصة (قسم + تاريخ + حصة): يضيف الغائبين الجدد، ويزيل ما أدخله الأستاذ نفسه
    ثم ألغاه، ويضع تأشيرة «سُجِّلت الحصة» حتى بلا غائبين."""
    data = request.get_json() or {}
    d = _parse_date_field(data.get("date")) or date.today()
    period = (data.get("period") or "").strip()
    try:
        did = int(data.get("division_id"))
    except (TypeError, ValueError):
        return err("حدّد القسم")
    ids = {int(i) for i in (data.get("absent_ids") or [])}
    if not period:
        return err("حدّد الحصة")
    db = Session()
    try:
        t = _my_teacher(db)
        if g.role == "teacher" and t:
            if not db.query(ScheduleEntry).filter(_tq(t.id), ScheduleEntry.division_id == did).first():
                return err("هذا القسم ليس ضمن حصصك في استعمال الزمن", 403)
        valid = {s.id for s in db.query(Student).filter(Student.division_id == did, Student.is_active == True).all()}
        ids &= valid
        existing = {a.student_id: a for a in db.query(Absence).filter(
            Absence.division_id == did, Absence.date == d, Absence.period == period).all()}
        added, removed, new_ids = 0, 0, []
        for sid in ids:
            if sid not in existing:
                db.add(Absence(student_id=sid, division_id=did, date=d, period=period, hours=1.0,
                               status="غير مبرر", entered_by=g.user_id))
                added += 1; new_ids.append(sid)
        for sid, a in existing.items():
            if sid not in ids and a.entered_by == g.user_id and a.status == "غير مبرر":
                db.delete(a); removed += 1
        chk = db.query(SessionCheck).filter(SessionCheck.division_id == did, SessionCheck.date == d,
                                            SessionCheck.period == period).first()
        if not chk:
            chk = SessionCheck(division_id=did, date=d, period=period)
            db.add(chk)
        chk.teacher_id = t.id if t else None
        chk.user_id = g.user_id
        chk.absent_count = len(ids)
        db.commit()
        si = SI(db)
        for sid in new_ids:
            _check_milestone(sid, db, g.user_id)
            stu = db.query(Student).filter(Student.id == sid).first()
            if stu:
                try: notify_absence(stu, si, str(d), period, db=db)
                except Exception: pass
        write_audit(g.user_id, "PORTAL_ABSENCE", "division", did, new=f"{d} {period} +{added} -{removed}")
        return ok({"added": added, "removed": removed, "absent": len(ids)},
                  f"تم حفظ حصة {period} — الغائبون: {len(ids)}")
    finally:
        db.close()

# ── استدعاء الأولياء: طلب (أستاذ/مشرف) ← اعتماد المدير ← طباعة ← إغلاق ──
def _summons_row(db, s, cache):
    st = cache["stu"].get(s.student_id)
    dv = cache["div"].get(s.division_id or (st.division_id if st else None))
    name, role = _user_label(db, s.requested_by)
    return {"id": s.id, "student_id": s.student_id,
            "student": f"{st.last_name_ar} {st.first_name_ar}" if st else "—",
            "division": dv.name if dv else "", "guardian": (st.guardian_name or "") if st else "",
            "phone": (st.guardian_phone or "") if st else "", "category": s.category, "reason": s.reason,
            "for_date": str(s.for_date) if s.for_date else "", "status": s.status,
            "requested_by": name, "requested_role": s.requested_role or role,
            "created": str(s.created_at)[:16] if s.created_at else "",
            "director_note": s.director_note or "", "closed_note": s.closed_note or "",
            "doc_number": s.doc_number or ""}

def _summons_cache(db):
    return {"stu": {x.id: x for x in db.query(Student).all()}, "div": {x.id: x for x in db.query(Division).all()}}

@app.post("/api/portal/summons")
@login_required
def portal_summons_create():
    if not _has_gate("G25", "G26", "G13", "G27"):
        return err("ليس لديك صلاحية", 403)
    data = request.get_json() or {}
    db = Session()
    try:
        st = db.query(Student).filter(Student.id == data.get("student_id")).first()
        if not st:
            return err("التلميذ غير موجود", 404)
        reason = (data.get("reason") or "").strip()
        if not reason:
            return err("اكتب سبب الاستدعاء")
        auto = g.role in ("director", "nazir", "counselor", "supervisor_general")
        s = ParentSummons(student_id=st.id, division_id=st.division_id, requested_by=g.user_id,
                          requested_role=g.role, category=(data.get("category") or "غياب"), reason=reason,
                          for_date=_parse_date_field(data.get("for_date")),
                          status="approved" if auto else "pending")
        if auto:
            s.decided_by = g.user_id; s.decided_at = datetime.now()
        db.add(s); db.commit()
        s.doc_number = f"SUM-{date.today().year}-{s.id:04d}"; db.commit()
        write_audit(g.user_id, "SUMMONS_CREATE", "student", st.id)
        return ok({"id": s.id, "status": s.status},
                  "تم اعتماد الاستدعاء" if auto else "أُرسل طلب الاستدعاء إلى المدير للاعتماد", 201)
    finally:
        db.close()

@app.get("/api/portal/summons")
@login_required
def portal_summons_list():
    if not _has_gate("G25", "G26", "G13", "G27"):
        return err("ليس لديك صلاحية", 403)
    db = Session()
    try:
        q = db.query(ParentSummons)
        if not _has_gate("G27"):
            q = q.filter(ParentSummons.requested_by == g.user_id)
        if st := request.args.get("status"):
            q = q.filter(ParentSummons.status == st)
        rows = q.order_by(ParentSummons.id.desc()).limit(300).all()
        c = _summons_cache(db)
        return ok([_summons_row(db, s, c) for s in rows])
    finally:
        db.close()

@app.put("/api/portal/summons/<int:sid>/decision")
@gate_required("G27")
def portal_summons_decide(sid):
    data = request.get_json() or {}
    action = data.get("action")
    if action not in ("approve", "reject", "done"):
        return err("إجراء غير صالح")
    db = Session()
    try:
        s = db.query(ParentSummons).filter(ParentSummons.id == sid).first()
        if not s:
            return err("غير موجود", 404)
        note = (data.get("note") or "").strip()
        if action == "done":
            s.status = "done"; s.closed_note = note
        else:
            s.status = "approved" if action == "approve" else "rejected"
            s.decided_by = g.user_id; s.decided_at = datetime.now(); s.director_note = note
        db.commit()
        write_audit(g.user_id, "SUMMONS_" + action.upper(), "summons", sid)
        return ok({"status": s.status}, "تم التحديث")
    finally:
        db.close()

@app.get("/api/portal/summons/<int:sid>/print")
@login_required
def portal_summons_print(sid):
    if not _has_gate("G27", "G26", "G13", "G25"):
        return err("ليس لديك صلاحية", 403)
    db = Session()
    try:
        s = db.query(ParentSummons).filter(ParentSummons.id == sid).first()
        if not s:
            return Response("غير موجود", mimetype="text/html")
        if not _has_gate("G27") and s.requested_by != g.user_id:
            return err("ليس لديك صلاحية", 403)
        si = SI(db)
        st = db.query(Student).filter(Student.id == s.student_id).first()
        dv = db.query(Division).filter(Division.id == st.division_id).first() if st else None
        when = f"يوم: <b>{s.for_date}</b>" if s.for_date else "في أقرب وقت ممكن"
        body = f"""
        <div class="doc-no">رقم: {s.doc_number or sid}</div>
        <div class="title">استدعاء ولي تلميذ</div>
        <p style="line-height:2.4;font-size:15px;margin-top:26px">
        إلى السيد(ة) ولي أمر التلميذ(ة): <b>{st.last_name_ar} {st.first_name_ar}</b>
        &nbsp;&nbsp; القسم: <b>{dv.name if dv else ''}</b><br>
        {('الولي: <b>' + st.guardian_name + '</b><br>') if st and st.guardian_name else ''}
        نرجو منكم الحضور إلى المؤسسة ({si.name_ar or ''}) {when}، من أجل: <b>{s.category}</b>.<br>
        <b>السبب:</b> {s.reason}<br><br>
        وتقبلوا فائق التقدير والاحترام.<br><br>
        حرر بـ {si.commune or si.wilaya or ''} في: {date.today().strftime('%Y-%m-%d')}
        </p>
        <div class="sign" style="justify-content:flex-end"><div>{level_label(si, 'director')}<br>{si.director_name or ''}</div></div>"""
        return Response(_doc_page("استدعاء ولي", body, si=si), mimetype="text/html")
    finally:
        db.close()

# ── بوابة المشرف التربوي ──
@app.get("/api/portal/supervisor/overview")
@gate_required("G26")
def portal_supervisor_overview():
    db = Session()
    try:
        si = SI(db)
        d = _parse_date_field(request.args.get("date")) or date.today()
        did = request.args.get("division_id")
        q = db.query(Absence).filter(Absence.date == d)
        if did:
            q = q.filter(Absence.division_id == int(did))
        abs_rows = q.all()
        c = _summons_cache(db)
        by_div = {}
        entries = []
        for a in abs_rows:
            dv = c["div"].get(a.division_id)
            st = c["stu"].get(a.student_id)
            by = by_div.setdefault(a.division_id, {"division": dv.name if dv else "—", "students": set(), "entries": 0})
            by["students"].add(a.student_id); by["entries"] += 1
            nm, rl = _user_label(db, a.entered_by)
            entries.append({"id": a.id, "student_id": a.student_id, "student": f"{st.last_name_ar} {st.first_name_ar}" if st else "—",
                            "division": dv.name if dv else "", "period": a.period or "اليوم كاملاً",
                            "status": a.status, "by": nm, "role": rl})
        divs = {x.id: x for x in _sort_divs(list(c["div"].values()))}
        summary = [{"division": v["division"], "students": len(v["students"]), "entries": v["entries"]}
                   for k, v in sorted(by_div.items(), key=lambda kv: [x.id for x in divs.values()].index(kv[0]) if kv[0] in divs else 999)]
        cov = _sessions_coverage(db, si, d)
        pend = db.query(ParentSummons).filter(ParentSummons.status == "pending").count()
        return ok({"date": str(d), "entries": entries, "by_division": summary,
                   "divisions": [{"id": x.id, "name": x.name} for x in divs.values() if x.is_active],
                   "absent_students": len({a.student_id for a in abs_rows}),
                   "unjustified": sum(1 for a in abs_rows if a.status == "غير مبرر"),
                   "coverage": {"total": len(cov), "submitted": sum(1 for r in cov if r["submitted"]),
                                "missing": [r for r in cov if not r["submitted"]][:60]},
                   "pending_summons": pend})
    finally:
        db.close()

# ── مركز متابعة المدير: كل شيء في مكان واحد ──
@app.get("/api/hub/overview")
@gate_required("G27")
def hub_overview():
    from datetime import timedelta
    db = Session()
    try:
        si = SI(db)
        d1 = _parse_date_field(request.args.get("from")) or date.today()
        d2 = _parse_date_field(request.args.get("to")) or d1
        c = _summons_cache(db)
        rows = db.query(Absence).filter(Absence.date >= d1, Absence.date <= d2).all()
        total_students = db.query(Student).filter(Student.is_active == True).count()
        # حسب القسم
        by_div = {}
        for a in rows:
            by_div.setdefault(a.division_id, {"students": set(), "entries": 0})
            by_div[a.division_id]["students"].add(a.student_id); by_div[a.division_id]["entries"] += 1
        cnt = _div_counts(db)
        div_rows = []
        for dv in _sort_divs(list(c["div"].values())):
            if not dv.is_active: continue
            b = by_div.get(dv.id, {"students": set(), "entries": 0})
            n = cnt.get(dv.id, _EMPTY_CNT)["total"]
            div_rows.append({"division": dv.name, "students": n, "absent_students": len(b["students"]),
                             "entries": b["entries"], "rate": round(100 * len(b["students"]) / n, 1) if n else 0})
        # حسب من سجّل
        by_user = {}
        for a in rows:
            u = by_user.setdefault(a.entered_by, {"entries": 0, "divs": set()})
            u["entries"] += 1; u["divs"].add(a.division_id)
        who = []
        for uid, v in by_user.items():
            nm, rl = _user_label(db, uid)
            who.append({"name": nm, "role": rl, "entries": v["entries"], "divisions": len(v["divs"])})
        who.sort(key=lambda x: -x["entries"])
        # تغطية حصص اليوم لكل أستاذ
        today = date.today()
        cov = _sessions_coverage(db, si, today)
        tcov = {}
        for r in cov:
            t = tcov.setdefault(r["teacher"], {"teacher": r["teacher"], "assigned": 0, "submitted": 0})
            t["assigned"] += 1; t["submitted"] += 1 if r["submitted"] else 0
        # اتجاه 7 أيام
        trend = []
        for i in range(6, -1, -1):
            day = today - timedelta(days=i)
            ds = db.query(Absence.student_id).filter(Absence.date == day).distinct().count()
            trend.append({"date": str(day), "students": ds})
        # أكثر الغائبين
        per = {}
        for a in rows:
            per[a.student_id] = per.get(a.student_id, 0) + 1
        top = []
        for sid, n in sorted(per.items(), key=lambda kv: -kv[1])[:10]:
            st = c["stu"].get(sid); dv = c["div"].get(st.division_id) if st else None
            top.append({"student_id": sid, "student": f"{st.last_name_ar} {st.first_name_ar}" if st else "—",
                        "division": dv.name if dv else "", "entries": n})
        sm = db.query(ParentSummons).order_by(ParentSummons.id.desc()).all()
        counts = {k: sum(1 for s in sm if s.status == k) for k in ("pending", "approved", "done", "rejected")}
        pend = [_summons_row(db, s, c) for s in sm if s.status == "pending"][:30]
        recent = [_summons_row(db, s, c) for s in sm if s.status != "pending"][:15]
        absent_students = len({a.student_id for a in rows})
        return ok({"from": str(d1), "to": str(d2), "total_students": total_students,
                   "kpi": {"absent_students": absent_students, "entries": len(rows),
                           "unjustified": sum(1 for a in rows if a.status == "غير مبرر"),
                           "rate": round(100 * absent_students / total_students, 1) if total_students else 0,
                           "sessions_total": len(cov), "sessions_submitted": sum(1 for r in cov if r["submitted"]),
                           "summons": counts},
                   "by_division": div_rows, "by_user": who, "teachers_today": sorted(tcov.values(), key=lambda x: x["teacher"]),
                   "missing_sessions": [r for r in cov if not r["submitted"]][:80],
                   "trend": trend, "top_absent": top, "pending_summons": pend, "recent_summons": recent})
    finally:
        db.close()


@app.get("/api/hub/teacher-links")
@gate_required("G27")
def hub_teacher_links():
    """ربط حسابات الأساتذة (المستخدمون) بسجلات الأساتذة في استعمال الزمن، مع اقتراح بالتشابه."""
    from app.utils import timetable_import as TI
    db = Session()
    try:
        teachers = db.query(Teacher).filter(Teacher.is_active == True).all()
        tname = {t.id: f"{t.last_name} {t.first_name}".strip() for t in teachers}
        linked = {t.user_id: t for t in teachers if t.user_id}
        free = [(t.id, tname[t.id]) for t in teachers if not t.user_id]
        out = []
        for u in db.query(User).filter(User.role == "teacher", User.is_active == True).order_by(User.full_name).all():
            lt = linked.get(u.id)
            sug = None
            if not lt:
                sug = TI.suggest_teacher(u.full_name, free, cutoff=0.6)
            n = db.query(ScheduleEntry).filter(_tq(lt.id)).count() if lt else 0
            out.append({"user_id": u.id, "name": u.full_name, "teacher_id": lt.id if lt else None,
                        "teacher": tname.get(lt.id, "") if lt else "", "sessions": n,
                        "suggested_id": sug, "suggested": tname.get(sug, "") if sug else ""})
        return ok({"users": out, "free_teachers": [{"id": i, "name": n} for i, n in sorted(free, key=lambda x: x[1])]})
    finally:
        db.close()

@app.put("/api/hub/teacher-links")
@gate_required("G27")
def hub_set_teacher_link():
    data = request.get_json() or {}
    db = Session()
    try:
        uid = int(data.get("user_id"))
        for t in db.query(Teacher).filter(Teacher.user_id == uid).all():
            t.user_id = None
        tid = data.get("teacher_id")
        if tid:
            t = db.query(Teacher).filter(Teacher.id == int(tid)).first()
            if not t:
                return err("الأستاذ غير موجود", 404)
            t.user_id = uid
        db.commit()
        write_audit(g.user_id, "TEACHER_LINK", "user", uid)
        return ok(msg="تم الربط")
    except (TypeError, ValueError):
        db.rollback(); return err("بيانات غير صالحة")
    finally:
        db.close()


if __name__ == "__main__":
    init_db()
    from app.core.license import verify_license
    lic = verify_license(cfg.LICENSE_FILE)
    print(f"{'✓' if lic['valid'] else '⚠'} الترخيص: {lic['message']}")
    print(f"✓ DONIA SMART SCHOOL v3.0")
    print(f"✓ http://0.0.0.0:{cfg.PORT}")
    REMOTE.autostart(cfg.PORT)
    UPDATER.loop()
    try:
        from waitress import serve          # خادم إنتاجي أثبت من خادم Flask التجريبي (مهم عند الوصول عبر الإنترنت)
        print("✓ الخادم: waitress")
        serve(app, host="0.0.0.0", port=cfg.PORT, threads=16)
    except ImportError:
        app.run(host="0.0.0.0", port=cfg.PORT, debug=cfg.DEBUG, use_reloader=False)
