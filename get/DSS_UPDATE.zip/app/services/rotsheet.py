"""الورقة الدوارة — توليد النموذج المطبوع (A4 أفقي) مطابقاً للنموذج المعتمد:
ترويسة (المؤسسة · القسم · الموسم) ثم شبكة التلاميذ × (أحد→خميس، صباحاً ومساءً، حصة 1..N)
مع مربع «الفترة من/إلى»، ثم جدول «توقيع الأساتذة حسب توزيع الحصص».
DONIA LABS TECH © 2026"""
import hashlib
import json
from datetime import date, timedelta
from html import escape as _e

DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس"]
DAY_IDX0 = 1            # ScheduleEntry.day_of_week للأحد (0=السبت)
ROWS_FULL = 26          # أقصى عدد تلاميذ في صفحة بلا جدول التوقيع
ROWS_WITH_SIG = 9       # أقصى عدد تلاميذ في صفحة تحمل جدول التوقيع


def week_sunday(d):
    """يعيد أحد الأسبوع الذي يقع فيه التاريخ (الأحد = بداية الأسبوع الدراسي في النموذج)."""
    return d - timedelta(days=(d.weekday() + 1) % 7)


def week_dates(sunday):
    return [sunday + timedelta(days=i) for i in range(5)]


def sig_key(day_i, period):
    return f"{DAY_IDX0 + day_i}|{period}"


def verify_code(sheet_id, division_id, week_start, sigs):
    core = {k: [v.get("user_id"), v.get("at")] for k, v in sorted((sigs or {}).items())}
    raw = f"{sheet_id}|{division_id}|{week_start}|{json.dumps(core, sort_keys=True)}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12].upper()


CSS = """
@page{size:A4 landscape;margin:7mm}
*{box-sizing:border-box}
body{font-family:'Traditional Arabic','Arial',sans-serif;direction:rtl;margin:0;color:#000;font-size:12px}
.btnbar{text-align:center;margin:6px}
.pg{page-break-after:always;padding:0 2mm}
.pg:last-child{page-break-after:auto}
.top{display:flex;justify-content:space-between;align-items:flex-end;font-weight:bold;font-size:13.5px;margin:2mm 0 2mm}
.top div{flex:1}.top .c{text-align:center}.top .l{text-align:left}
table{border-collapse:collapse;width:100%;table-layout:fixed}
td,th{border:.35mm solid #000;padding:0;text-align:center;font-weight:normal;overflow:hidden}
.g td,.g th{height:5.25mm;font-size:11px}
.g .hd{font-weight:bold;font-size:12px;height:6.5mm}
.g .per{height:6mm;font-size:11px}
.g .v{height:17mm}
.g .v span{display:inline-block;writing-mode:vertical-rl;transform:rotate(180deg);font-size:9.5px;white-space:nowrap}
.g .nm{text-align:right;padding:0 1.2mm;font-size:11.5px;white-space:nowrap}
.g .no{font-size:11px}
.g .box{text-align:right;padding:1mm 2mm;font-weight:bold;font-size:12px;line-height:1.55;border-top:none}
.sh{background:#d9d9d9}
.g .mk{font-size:10px;font-weight:bold}
.s td,.s th{height:14.5mm;font-size:12px}
.s .h1{height:8mm;font-weight:bold;font-size:14px}
.s .h2{height:8mm;font-size:12.5px}
.s .dy{font-weight:bold;font-size:13px}
.s .side{width:9mm}
.s .side span{display:inline-block;writing-mode:vertical-rl;transform:rotate(180deg);font-weight:bold;font-size:12px;white-space:nowrap}
.cell{position:relative;height:100%;width:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1.15}
.cell img{max-width:92%;max-height:11mm}
.cell .t{font-size:8px;color:#555}
.cell .n{font-size:8.5px;color:#222}
.foot{margin-top:2mm;font-size:9.5px;color:#444;display:flex;justify-content:space-between}
@media print{.btnbar{display:none}}
"""


def _grid(si, division, students, start_no, wd, pm, pe, marks, mk):
    """جدول التلاميذ لصفحة واحدة. marks: {(student_id, day_i, period): True}."""
    periods = [f"ص{i}" for i in range(1, pm + 1)] + [f"م{i}" for i in range(1, pe + 1)]
    ncols = len(periods)
    h = ['<table class="g"><colgroup><col style="width:7mm"><col style="width:46mm">']
    h.append("<col>" * (5 * ncols) + "</colgroup>")
    # الصف 1: مربع الفترة + أيام الأسبوع
    h.append('<tr><td colspan="2" rowspan="2" class="box">الفترة من : '
             f'<bdi dir="ltr">{_e(str(wd[0]))}</bdi><br>إلـــــى: <bdi dir="ltr">{_e(str(wd[-1]))}</bdi></td>')
    for d in DAYS:
        h.append(f'<th colspan="{ncols}" class="hd">{d}</th>')
    h.append('</tr><tr>')
    for _ in DAYS:
        h.append(f'<th colspan="{pm}" class="per">صباحا</th><th colspan="{pe}" class="per sh">مساء</th>')
    h.append('</tr><tr><th class="v"><span>الرقم</span></th><th class="hd">التلامـــــــيـــــــذ</th>')
    for _ in DAYS:
        for i, p in enumerate(periods):
            cls = ' sh' if p.startswith("م") else ''
            h.append(f'<th class="v{cls}"><span>الحصة {p[1:]}</span></th>')
    h.append('</tr>')
    for k, s in enumerate(students):
        h.append(f'<tr><td class="no">{start_no + k}</td><td class="nm">{_e(s["name"])}</td>')
        for di in range(5):
            for p in periods:
                cls = ' sh' if p.startswith("م") else ''
                m = '<span class="mk">غ</span>' if marks and (s["id"], di, p) in marks else ''
                h.append(f'<td class="{cls.strip()}">{m}</td>')
        h.append('</tr>')
    h.append('</table>')
    return "".join(h)


def _sigtable(pm, pe, cells, sigs, show_names):
    """جدول توقيع الأساتذة. cells: {(day_i, period): {"teacher": str, "subject": str}}."""
    periods = [f"ص{i}" for i in range(1, pm + 1)] + [f"م{i}" for i in range(1, pe + 1)]
    h = ['<table class="s"><colgroup><col style="width:9mm"><col style="width:22mm"><col></colgroup>']
    h.append(f'<tr><td rowspan="{len(DAYS) + 2}" class="side"><span>توقيع الأساتذة حسب توزيع الحصص</span></td>'
             f'<td rowspan="2" style="border:none"></td>'
             f'<th colspan="{pm}" class="h1">الفترة الصباحية</th><th colspan="{pe}" class="h1">الفترة المسائية</th></tr><tr>')
    for p in periods:
        h.append(f'<th class="h2">الحصة {int(p[1:]):02d}</th>')
    h.append('</tr>')
    for di, d in enumerate(DAYS):
        h.append(f'<tr><td class="dy">{d}</td>')
        for p in periods:
            c = cells.get((di, p)) or {}
            sg = (sigs or {}).get(sig_key(di, p))
            inner = ''
            if sg:
                img = f'<img src="{_e(sg["sig"], quote=True)}">' if sg.get("sig") else ''
                inner = f'{img}<span class="n">{_e(sg.get("name", ""))}</span><span class="t"><bdi dir="ltr">{_e((sg.get("at") or "")[:16].replace("T", " "))}</bdi></span>'
            elif show_names and c.get("teacher"):
                inner = f'<span class="t">{_e(c["teacher"])}</span><span class="t">{_e(c.get("subject", ""))}</span>'
            h.append(f'<td><div class="cell">{inner}</div></td>')
        h.append('</tr>')
    h.append('</table>')
    return "".join(h)


def render(si, division_name, students, week_start, cells, sigs=None, marks=None, show_names=True,
           doc_number="", verify="", title="الورقة الدوارة"):
    pm, pe = int(si.periods_morning or 4), int(si.periods_evening or 4)
    wd = week_dates(week_start)
    top = (f'<div class="top"><div>{_e(si.name_ar or "")}</div>'
           f'<div class="c">القسم: &nbsp;{_e(division_name)}</div>'
           f'<div class="l">الموسم الدراسي : {_e(si.academic_year or "")}</div></div>')
    pages, i, n = [], 0, len(students)
    chunks = []
    while i < n:
        take = min(ROWS_FULL, n - i)
        chunks.append((i, students[i:i + take]))
        i += take
    if not chunks:
        chunks = [(0, [])]
    sig_on_last = len(chunks[-1][1]) <= ROWS_WITH_SIG
    sig_html = _sigtable(pm, pe, cells, sigs, show_names)
    foot = ''
    if doc_number:
        foot = (f'<div class="foot"><span>الوثيقة: {_e(doc_number)}</span>'
                f'<span>رمز التحقق: {_e(verify)}</span></div>')
    for idx, (start, chunk) in enumerate(chunks):
        last = idx == len(chunks) - 1
        body = top + _grid(si, division_name, chunk, start + 1, wd, pm, pe, bool(marks), marks or {})
        if last and sig_on_last:
            body += '<div style="height:3mm"></div>' + sig_html + foot
        pages.append(f'<div class="pg">{body}</div>')
    if not sig_on_last:
        pages.append(f'<div class="pg">{top}<div style="height:3mm"></div>{sig_html}{foot}</div>')
    return (f'<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8"><title>{_e(title)}</title>'
            f'<style>{CSS}</style></head><body><div class="btnbar"><button onclick="window.print()">🖨️ طباعة</button></div>'
            + "".join(pages) + '</body></html>')
