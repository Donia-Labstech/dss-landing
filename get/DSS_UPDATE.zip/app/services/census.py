# -*- coding: utf-8 -*-
"""الإحصاء الشامل للمؤسسة (الدخول المدرسي): يُحسب آلياً من بيانات النظام ويُكمَّل يدوياً
بما لا يعرفه النظام (المرافق، الخدمات، النقل...). يُنتج: لوحة بيانات، نموذجاً مطبوعاً، وملف Excel.

بنية الاستمارة الورقية الوزارية (إحصاء بداية السنة): عدد التلاميذ والأفواج التربوية والأساتذة
والفريق الإداري وحجرات التدريس وجرد المرافق — وقد وُسِّعت هنا بالتوزيع حسب الجنس والإعادة
ونمط التمدرس والفئات الخاصة والسن.
"""
import html as _h
import io
import json
from collections import Counter, defaultdict

LEVEL_NAMES = {1: "السنة الأولى متوسط", 2: "السنة الثانية متوسط", 3: "السنة الثالثة متوسط", 4: "السنة الرابعة متوسط"}

# حقول يدوية: (المفتاح، العنوان، النوع num/bool) مجمّعة
EXTRA_GROUPS = [
    ("البنايات والحجرات", [
        ("classrooms", "حجرات التدريس القائمة (عادية)", "num"),
        ("classrooms_unused", "حجرات غير مستغلة / خارج الخدمة", "num"),
        ("prefab", "حجرات جاهزة (Préfabriqué)", "num"),
        ("labs", "مخابر (علوم / فيزياء)", "num"),
        ("it_rooms", "قاعات الإعلام الآلي", "num"),
        ("it_devices", "عدد الحواسيب الصالحة للتلاميذ", "num"),
        ("workshops", "ورشات (تكنولوجيا / رسم...)", "num"),
        ("library_rooms", "مكتبة / قاعة مطالعة", "num"),
        ("library_books", "عدد الكتب بالمكتبة", "num"),
        ("meeting_rooms", "قاعات الاجتماعات والأساتذة", "num"),
    ]),
    ("المرافق الرياضية والصحية", [
        ("sports_hall", "قاعة رياضة", "num"),
        ("sports_field", "ملاعب رياضية", "num"),
        ("toilets_boys", "دورات مياه — ذكور", "num"),
        ("toilets_girls", "دورات مياه — إناث", "num"),
        ("infirmary", "مصحة / غرفة إسعاف", "bool"),
    ]),
    ("الإطعام والإيواء والنقل", [
        ("canteen", "مطعم مدرسي", "bool"),
        ("canteen_capacity", "طاقة استيعاب المطعم (وجبة/يوم)", "num"),
        ("canteen_meals", "عدد الوجبات المقدَّمة فعلياً يومياً", "num"),
        ("dormitory_beds", "أسرّة الداخلية", "num"),
        ("transport_students", "التلاميذ المستفيدون من النقل المدرسي", "num"),
    ]),
    ("الخدمات الأساسية والأمن", [
        ("water", "ماء صالح للشرب (متوفر)", "bool"),
        ("electricity", "كهرباء", "bool"),
        ("heating", "تدفئة مركزية / مدافئ تعمل", "bool"),
        ("internet", "اتصال بالإنترنت", "bool"),
        ("fence", "سور محيط سليم", "bool"),
        ("guard", "حارس / أمن", "bool"),
        ("cameras", "كاميرات مراقبة", "bool"),
    ]),
    ("الأفواج والتأطير (تصحيح يدوي إن لزم)", [
        ("double_shift_divisions", "أفواج تدرس بنظام الفوجين (تناوب)", "num"),
        ("special_needs_classes", "أقسام مدمجة / ذوو احتياجات خاصة", "num"),
        ("vacant_posts_teachers", "مناصب أساتذة شاغرة", "num"),
        ("vacant_posts_admin", "مناصب إدارية شاغرة", "num"),
    ]),
]
EXTRA_KEYS = {k: t for _, items in EXTRA_GROUPS for k, _, t in items}


def load_extras(si):
    try:
        d = json.loads(getattr(si, "census_json", "") or "{}")
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def clean_extras(data):
    """يقبل المفاتيح المعروفة فقط: num → عدد صحيح ≥ 0 ، bool → 0/1."""
    out = {}
    for k, t in EXTRA_KEYS.items():
        if k not in data or data[k] in (None, ""):
            continue
        v = data[k]
        if t == "bool":
            out[k] = 1 if str(v).lower() in ("1", "true", "نعم", "yes") else 0
        else:
            n = int(float(v))
            if n < 0 or n > 10_000_000:
                raise ValueError(k)
            out[k] = n
    return out


def _start_year(year_txt):
    try:
        return int(str(year_txt).replace("-", "/").split("/")[0])
    except Exception:
        from datetime import date
        return date.today().year


def compute(db, si, M, role_labels):
    """M: وحدة النماذج (Student, Division, Teacher, User, Room)."""
    Student, Division, Teacher, User, Room = M["Student"], M["Division"], M["Teacher"], M["User"], M["Room"]
    divs = {d.id: d for d in db.query(Division).filter(Division.is_active == True).all()}
    studs = [s for s in db.query(Student).filter(Student.is_active == True).all() if not s.is_expelled]
    # الأفواج التربوية = الأقسام التي فيها تلاميذ فعلاً (الأقسام الفارغة الناتجة عن استيراد المواقيت لا تُحتسب)
    _used = {s.division_id for s in studs}
    divs = {k: v for k, v in divs.items() if k in _used}
    sy = _start_year(si.academic_year)

    keys = ("students", "male", "female", "repeaters", "repeaters_f", "external", "half_board", "boarder",
            "orphans", "disabled", "scholarship", "newcomers", "pe_exempt", "edu_children")
    by_level = defaultdict(Counter)
    by_div = defaultdict(Counter)
    ages = defaultdict(Counter)
    for s in studs:
        d = divs.get(s.division_id)
        lvl = d.level if d else 0
        fem = (s.gender or "") in ("أنثى", "انثى", "female", "F")
        for bucket in (by_level[lvl], by_div[s.division_id]):
            bucket["students"] += 1
            bucket["female" if fem else "male"] += 1
            if s.is_repeating:
                bucket["repeaters"] += 1
                if fem: bucket["repeaters_f"] += 1
            st = s.status or "خارجي"
            bucket["half_board" if st == "نصف داخلي" else "boarder" if st == "داخلي" else "external"] += 1
            if s.is_orphan: bucket["orphans"] += 1
            if s.has_disability: bucket["disabled"] += 1
            if s.is_scholarship: bucket["scholarship"] += 1
            if s.entry_date: bucket["newcomers"] += 1
            if s.pe_exempt: bucket["pe_exempt"] += 1
            if s.father_in_education or s.mother_in_education: bucket["edu_children"] += 1
        if s.birth_date:
            ages[sy - s.birth_date.year]["f" if fem else "m"] += 1
        else:
            ages[-1]["f" if fem else "m"] += 1

    levels = []
    for lvl in sorted(set(list(by_level.keys()) + [d.level for d in divs.values()])):
        row = {k: by_level[lvl].get(k, 0) for k in keys}
        row.update({"level": lvl, "label": LEVEL_NAMES.get(lvl, f"المستوى {lvl}" if lvl else "بلا قسم"),
                    "divisions": sum(1 for d in divs.values() if d.level == lvl)})
        row["avg"] = round(row["students"] / row["divisions"], 1) if row["divisions"] else 0
        levels.append(row)
    total = {k: sum(r[k] for r in levels) for k in keys}
    total["divisions"] = sum(r["divisions"] for r in levels)
    total["avg"] = round(total["students"] / total["divisions"], 1) if total["divisions"] else 0

    div_rows = []
    for did, d in sorted(divs.items(), key=lambda kv: (kv[1].level, kv[1].section)):
        c = by_div.get(did, Counter())
        div_rows.append({"name": d.name, "level": d.level, "students": c.get("students", 0),
                         "male": c.get("male", 0), "female": c.get("female", 0),
                         "repeaters": c.get("repeaters", 0), "room": d.room or ""})

    age_rows = [{"age": ("غير مسجّل" if a == -1 else a), "male": c.get("m", 0), "female": c.get("f", 0),
                 "total": c.get("m", 0) + c.get("f", 0)} for a, c in sorted(ages.items())]

    teachers = db.query(Teacher).filter(Teacher.is_active == True).all()
    spec = Counter((t.specialty or "غير محدد").strip() or "غير محدد" for t in teachers)
    rank = Counter((t.grade_rank or "غير محدد").strip() or "غير محدد" for t in teachers)
    teacher_block = {
        "total": len(teachers),
        "weekly_hours": sum(t.weekly_hours or 0 for t in teachers),
        "by_specialty": [{"name": k, "count": v} for k, v in sorted(spec.items(), key=lambda kv: -kv[1])],
        "by_rank": [{"name": k, "count": v} for k, v in sorted(rank.items(), key=lambda kv: -kv[1])],
    }

    staff = Counter()
    for u in db.query(User).filter(User.is_active == True).all():
        if u.role in role_labels and u.role not in ("teacher", "student", "parent"):
            staff[u.role] += 1
    staff_rows = [{"role": role_labels[r], "count": c} for r, c in staff.items()]
    staff_total = sum(staff.values())

    rooms = db.query(Room).filter(Room.is_active == True).all()
    room_block = {"total": len(rooms),
                  "ordinary": sum(1 for r in rooms if (r.room_type or "عادي") == "عادي"),
                  "special": sum(1 for r in rooms if (r.room_type or "عادي") != "عادي")}

    extras = load_extras(si)
    derived = {}
    classrooms = extras.get("classrooms") or room_block["ordinary"]
    if classrooms and total["divisions"]:
        derived["divisions_per_classroom"] = round(total["divisions"] / classrooms, 2)
        derived["students_per_classroom"] = round(total["students"] / classrooms, 1)
    if teachers and total["students"]:
        derived["students_per_teacher"] = round(total["students"] / len(teachers), 1)
    if staff_total and total["students"]:
        derived["students_per_admin"] = round(total["students"] / staff_total, 1)

    return {
        "school": {"name": si.name_ar or "", "wilaya": si.wilaya or "", "commune": si.commune or "",
                   "code": si.school_code or "", "year": si.academic_year or "", "level_type": si.level_type or "متوسطة"},
        "levels": levels, "total": total, "divisions": div_rows, "ages": age_rows,
        "teachers": teacher_block, "staff": staff_rows, "staff_total": staff_total,
        "rooms": room_block, "extras": extras, "derived": derived,
        "groups": [{"title": t, "items": [{"key": k, "label": l, "type": ty} for k, l, ty in items]}
                   for t, items in EXTRA_GROUPS],
    }


# ───────────────────────── الطباعة (نموذج رسمي) ─────────────────────────
_CSS = """<style>@page{size:A4;margin:12mm}body{font-family:Tahoma,Arial,sans-serif;direction:rtl;color:#000;font-size:11pt;margin:0}
.hd{text-align:center;font-weight:700;line-height:1.7}.hd .r2{display:flex;justify-content:space-between;font-weight:400;font-size:10pt;margin-top:2mm}
h1{text-align:center;font-size:16pt;margin:6mm 0 1mm;text-decoration:underline}.sub{text-align:center;margin-bottom:5mm;font-size:10.5pt}
h2{font-size:12pt;background:#e8e8e8;border:.3mm solid #000;padding:1.2mm 3mm;margin:6mm 0 0}
table{width:100%;border-collapse:collapse;font-size:10pt}th,td{border:.3mm solid #000;padding:1.2mm 2mm;text-align:center}th{background:#f4f4f4}
td.l{text-align:right}tr.t td{font-weight:700;background:#f4f4f4}.sg{display:flex;justify-content:space-between;margin-top:14mm;font-weight:700}
.pb{page-break-before:always}</style>"""


def _e(x):
    return _h.escape(str(x if x is not None else ""))


def build_html(c):
    sc, t = c["school"], c["total"]
    wil = ("مديرية التربية لولاية " + sc["wilaya"]) if sc["wilaya"] else "مديرية التربية"
    out = [f'<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="UTF-8"><title>الإحصاء الشامل</title>{_CSS}</head><body>']
    out.append(f'<div class="hd">الجمهورية الجزائرية الديمقراطية الشعبية<div class="r2"><span>وزارة التربية الوطنية</span><span>{_e(wil)}</span></div>'
               f'<div>{_e(sc["level_type"])} {_e(sc["name"])}{(" — " + _e(sc["code"])) if sc["code"] else ""}</div></div>')
    out.append(f'<h1>الإحصاء الشامل</h1><div class="sub">السنة الدراسية {_e(sc["year"])}{(" — " + _e(sc["commune"])) if sc["commune"] else ""}</div>')

    out.append("<h2>1) التلاميذ والأفواج التربوية</h2><table><tr><th>المستوى</th><th>الأفواج</th><th>المجموع</th><th>ذكور</th><th>إناث</th>"
               "<th>معيدون</th><th>خارجي</th><th>نصف داخلي</th><th>داخلي</th><th>متوسط التلاميذ/فوج</th></tr>")
    for r in c["levels"]:
        out.append(f'<tr><td class="l">{_e(r["label"])}</td><td>{r["divisions"]}</td><td>{r["students"]}</td><td>{r["male"]}</td><td>{r["female"]}</td>'
                   f'<td>{r["repeaters"]}</td><td>{r["external"]}</td><td>{r["half_board"]}</td><td>{r["boarder"]}</td><td>{r["avg"]}</td></tr>')
    out.append(f'<tr class="t"><td class="l">المجموع</td><td>{t["divisions"]}</td><td>{t["students"]}</td><td>{t["male"]}</td><td>{t["female"]}</td>'
               f'<td>{t["repeaters"]}</td><td>{t["external"]}</td><td>{t["half_board"]}</td><td>{t["boarder"]}</td><td>{t["avg"]}</td></tr></table>')

    out.append("<h2>2) فئات خاصة</h2><table><tr><th>المستوى</th><th>أيتام</th><th>ذوو إعاقة</th><th>منحة دراسية</th><th>وافدون (دخول جديد)</th>"
               "<th>معفون من التربية البدنية</th><th>أبناء عمال التربية</th><th>معيدات (إناث)</th></tr>")
    for r in c["levels"] + [dict(t, label="المجموع")]:
        cls = ' class="t"' if r.get("label") == "المجموع" else ""
        out.append(f'<tr{cls}><td class="l">{_e(r["label"])}</td><td>{r["orphans"]}</td><td>{r["disabled"]}</td><td>{r["scholarship"]}</td>'
                   f'<td>{r["newcomers"]}</td><td>{r["pe_exempt"]}</td><td>{r["edu_children"]}</td><td>{r["repeaters_f"]}</td></tr>')
    out.append("</table>")

    out.append("<h2>3) التلاميذ حسب السن (عند 31 ديسمبر)</h2><table><tr><th>السن</th><th>ذكور</th><th>إناث</th><th>المجموع</th></tr>")
    for a in c["ages"]:
        out.append(f'<tr><td>{_e(a["age"])}</td><td>{a["male"]}</td><td>{a["female"]}</td><td>{a["total"]}</td></tr>')
    out.append("</table>")

    tc = c["teachers"]
    out.append(f'<h2 class="pb">4) هيئة التدريس — {tc["total"]} أستاذ(ة) · {tc["weekly_hours"]} ساعة أسبوعية</h2><table><tr><th>التخصص</th><th>العدد</th></tr>')
    for r in tc["by_specialty"]:
        out.append(f'<tr><td class="l">{_e(r["name"])}</td><td>{r["count"]}</td></tr>')
    out.append('</table><table style="margin-top:3mm"><tr><th>الرتبة</th><th>العدد</th></tr>')
    for r in tc["by_rank"]:
        out.append(f'<tr><td class="l">{_e(r["name"])}</td><td>{r["count"]}</td></tr>')
    out.append("</table>")

    out.append(f'<h2>5) الفريق الإداري — {c["staff_total"]}</h2><table><tr><th>الوظيفة</th><th>العدد</th></tr>')
    for r in c["staff"]:
        out.append(f'<tr><td class="l">{_e(r["role"])}</td><td>{r["count"]}</td></tr>')
    out.append("</table>")

    out.append("<h2>6) المحلات والمرافق</h2><table><tr><th>البيان</th><th>القيمة</th></tr>")
    out.append(f'<tr><td class="l">المحلات المسجّلة في استعمال الزمن (عادية / متخصصة)</td><td>{c["rooms"]["ordinary"]} / {c["rooms"]["special"]}</td></tr>')
    for g in c["groups"]:
        for it in g["items"]:
            v = c["extras"].get(it["key"])
            if v is None:
                continue
            val = ("نعم" if v else "لا") if it["type"] == "bool" else v
            out.append(f'<tr><td class="l">{_e(g["title"])} — {_e(it["label"])}</td><td>{_e(val)}</td></tr>')
    out.append("</table>")

    dv = c["derived"]
    if dv:
        names = {"students_per_teacher": "تلميذ لكل أستاذ", "students_per_admin": "تلميذ لكل إداري",
                 "students_per_classroom": "تلميذ لكل حجرة", "divisions_per_classroom": "فوج لكل حجرة"}
        out.append("<h2>7) مؤشرات التأطير</h2><table><tr><th>المؤشر</th><th>القيمة</th></tr>")
        for k, label in names.items():
            if k in dv:
                out.append(f'<tr><td class="l">{label}</td><td>{dv[k]}</td></tr>')
        out.append("</table>")

    out.append('<div class="sg"><div>مدير(ة) المؤسسة</div><div>رئيس(ة) مفتشية الإدارة / مصلحة الإحصاء</div></div></body></html>')
    return "".join(out)


# ───────────────────────── Excel ─────────────────────────
def build_xlsx(c):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
    wb = Workbook()
    thin = Side(style="thin", color="999999")
    bd = Border(left=thin, right=thin, top=thin, bottom=thin)
    hf = PatternFill("solid", fgColor="E8E8E8")

    def sheet(title, headers, rows, first=False):
        ws = wb.active if first else wb.create_sheet()
        ws.title = title[:31]
        ws.sheet_view.rightToLeft = True
        ws.append(headers)
        for r in rows:
            ws.append(r)
        for i, row in enumerate(ws.iter_rows(), 1):
            for cell in row:
                cell.border = bd
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
                if i == 1:
                    cell.font = Font(bold=True); cell.fill = hf
        for col in ws.columns:
            ws.column_dimensions[col[0].column_letter].width = max(12, min(40, max(len(str(x.value or "")) for x in col) + 3))
        return ws

    t = c["total"]
    H = ["المستوى", "الأفواج", "المجموع", "ذكور", "إناث", "معيدون", "خارجي", "نصف داخلي", "داخلي",
         "أيتام", "ذوو إعاقة", "منحة", "وافدون", "معفون ر.ب", "أبناء عمال التربية"]
    rows = [[r["label"], r["divisions"], r["students"], r["male"], r["female"], r["repeaters"], r["external"],
             r["half_board"], r["boarder"], r["orphans"], r["disabled"], r["scholarship"], r["newcomers"],
             r["pe_exempt"], r["edu_children"]] for r in c["levels"]]
    rows.append(["المجموع", t["divisions"], t["students"], t["male"], t["female"], t["repeaters"], t["external"],
                 t["half_board"], t["boarder"], t["orphans"], t["disabled"], t["scholarship"], t["newcomers"],
                 t["pe_exempt"], t["edu_children"]])
    sheet("التلاميذ", H, rows, first=True)
    sheet("الأقسام", ["القسم", "المستوى", "التلاميذ", "ذكور", "إناث", "معيدون", "القاعة"],
          [[d["name"], d["level"], d["students"], d["male"], d["female"], d["repeaters"], d["room"]] for d in c["divisions"]])
    sheet("السن", ["السن", "ذكور", "إناث", "المجموع"], [[a["age"], a["male"], a["female"], a["total"]] for a in c["ages"]])
    sheet("الأساتذة", ["التخصص", "العدد"], [[r["name"], r["count"]] for r in c["teachers"]["by_specialty"]])
    sheet("الإداريون", ["الوظيفة", "العدد"], [[r["role"], r["count"]] for r in c["staff"]])
    ex = []
    for g in c["groups"]:
        for it in g["items"]:
            v = c["extras"].get(it["key"])
            if v is not None:
                ex.append([g["title"], it["label"], ("نعم" if v else "لا") if it["type"] == "bool" else v])
    sheet("المرافق", ["المجموعة", "البيان", "القيمة"], ex)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
