# -*- coding: utf-8 -*-
"""الوكيل الإداري الذكي: يفهم طلب المسؤول بالعربية ويحوّله إلى «أدوات» محدودة وموثَّقة.
المبدأ الحاكم: الوكيل لا يملك صلاحيات خاصة — كل أداة تُنفَّذ عبر نقاط الـAPI نفسها وبرمز الدخول نفسه للمستخدم،
فتُطبَّق الصلاحيات (G..) ونطاق الأقسام في الخادم كما لو ضغط المستخدم الزر بنفسه.
أدوات الكتابة لا تُنفَّذ إلا بعد تأكيد صريح. DONIA LABS TECH © 2026"""
import json
import re

DELEGATE_ROLES = ("counselor", "nazir", "supervisor_general")   # من يمكن للمدير تفويضهم
SCOPES = {
    "read": "الاستعلام والاطلاع (بحث التلاميذ، إحصاءات، متابعة الغياب، قوائم الاستدعاء)",
    "absences": "تسجيل الغياب وإصدار إشعاراته",
    "summons": "إنشاء استدعاءات أولياء التلاميذ",
}

# الأداة: (النطاق، الطريقة، المسار، كتابة؟، الوصف، المعاملات)
TOOLS = {
    "student_search": dict(scope="read", method="GET", path="/api/students", write=False,
        desc="بحث عن تلميذ بالاسم أو اللقب أو رقم التعريف؛ يعيد المعرّف والقسم.",
        params={"search": "نص البحث (إلزامي)", "division_id": "معرّف القسم (اختياري)"}, query=["search", "division_id"], limit=15),
    "dashboard_stats": dict(scope="read", method="GET", path="/api/stats/dashboard", write=False,
        desc="إحصاءات عامة عن المؤسسة (عدد التلاميذ، الغياب...).", params={}),
    "absence_dashboard": dict(scope="read", method="GET", path="/api/absences/dashboard", write=False,
        desc="لوحة متابعة الغياب: التلاميذ الذين بلغوا عتبات الإشعار أو الإعذار.", params={}, limit=15),
    "student_absences": dict(scope="read", method="GET", path="/api/absences/{student_id}", write=False,
        desc="سجل غيابات تلميذ معيّن.", params={"student_id": "معرّف التلميذ (رقم)"}, ints=["student_id"], limit=20),
    "summons_list": dict(scope="read", method="GET", path="/api/portal/summons", write=False,
        desc="قائمة استدعاءات الأولياء وحالتها.", params={}, limit=15),
    "assignments_list": dict(scope="read", method="GET", path="/api/assignments", write=False,
        desc="إسناد الأقسام للأساتذة.", params={}, limit=15),
    "absence_register": dict(scope="absences", method="POST", path="/api/absences", write=True,
        desc="تسجيل غياب تلميذ. (يتطلب تأكيداً)",
        params={"student_id": "معرّف التلميذ (رقم)", "date": "YYYY-MM-DD", "period": "الحصة مثل ص1 (اختياري)",
                "status": "غير مبرر أو مبرر", "justification": "التبرير (اختياري)"}, ints=["student_id"], body=["student_id", "date", "period", "status", "justification"]),
    "absence_notice": dict(scope="absences", method="POST", path="/api/absences/notice/{student_id}", write=True,
        desc="إصدار إشعار غياب. (يتطلب تأكيداً)",
        params={"student_id": "معرّف التلميذ (رقم)", "notice_type": "إشعار_أول أو إشعار_ثاني أو إعذار"}, ints=["student_id"], body=["notice_type"]),
    "summons_create": dict(scope="summons", method="POST", path="/api/portal/summons", write=True,
        desc="إنشاء استدعاء ولي تلميذ. (يتطلب تأكيداً)",
        params={"student_id": "معرّف التلميذ (رقم)", "category": "غياب/سلوك/نتائج دراسية/تأخر/أخرى", "reason": "تفاصيل",
                "for_date": "YYYY-MM-DD", "for_time": "HH:MM", "items": "قائمة بنود الاستدعاء الرسمية (اختياري)"},
        ints=["student_id"], body=["student_id", "category", "reason", "for_date", "for_time", "items"]),
}

SYSTEM = ("أنت الوكيل الإداري الذكي لنظام DONIA SMART SCHOOL، تعمل لمصلحة مسؤول بالمؤسسة الجزائرية وبصلاحياته هو فقط. "
          "لا تخترع بيانات ولا صيغاً رسمية. لتنفيذ طلب استعمل أداة واحدة في كل خطوة. أجب بكائن JSON واحد فقط بلا أي نص آخر: "
          '{"tool":"اسم_الأداة","args":{...}} لاستعمال أداة، أو {"answer":"نص الجواب بالعربية"} عند الانتهاء أو عند الحاجة إلى توضيح. '
          "إن لزم معرّف تلميذ فابحث عنه أولاً بـ student_search. لا تنفّذ عملية كتابة إلا إن طلبها المستخدم صراحةً.")


def available_tools(allowed_scopes):
    return {k: v for k, v in TOOLS.items() if v["scope"] in allowed_scopes}


def tools_prompt(tools):
    lines = []
    for k, v in tools.items():
        ps = "؛ ".join(f"{p}: {d}" for p, d in v["params"].items()) or "بلا معاملات"
        lines.append(f"- {k}: {v['desc']} المعاملات: {ps}")
    return "الأدوات المتاحة لك:\n" + "\n".join(lines)


def parse_reply(text):
    """يستخرج كائن JSON من ردّ النموذج (يتسامح مع أسوار ```)."""
    if not text:
        return None
    t = text.strip()
    m = re.search(r"\{.*\}", t, re.S)
    if not m:
        return {"answer": t}
    try:
        d = json.loads(m.group(0))
        return d if isinstance(d, dict) else {"answer": t}
    except Exception:
        return {"answer": t}


def validate_call(name, args, tools):
    """يتحقق من اسم الأداة وأنها مسموحة وأن معاملاتها سليمة. يعيد (أداة، معاملات نظيفة، خطأ)."""
    spec = tools.get(name)
    if not spec:
        return None, None, "أداة غير مسموحة لك"
    args = args if isinstance(args, dict) else {}
    clean = {}
    for k in spec["params"]:
        if k in args and args[k] not in (None, ""):
            clean[k] = args[k]
    for k in spec.get("ints", []):
        try:
            clean[k] = int(clean[k])
        except Exception:
            return None, None, f"المعامل {k} مطلوب ويجب أن يكون رقماً"
    if name == "student_search" and not str(clean.get("search", "")).strip():
        return None, None, "نص البحث مطلوب"
    if name == "absence_register" and not clean.get("date"):
        return None, None, "تاريخ الغياب مطلوب"
    return spec, clean, None


def execute(app, auth_header, spec, args):
    """ينفّذ الأداة عبر نقطة الـAPI نفسها وبرمز المستخدم نفسه. يعيد (نجاح؟، بيانات/رسالة)."""
    path = spec["path"]
    for k in spec.get("ints", []):
        path = path.replace("{" + k + "}", str(int(args[k])))
    c = app.test_client()
    hdr = {"Authorization": auth_header}
    if spec["method"] == "GET":
        r = c.get(path, query_string={k: args[k] for k in spec.get("query", []) if k in args}, headers=hdr)
    else:
        r = c.post(path, json={k: args[k] for k in spec.get("body", []) if k in args}, headers=hdr)
    try:
        d = r.get_json(silent=True) or {}
    except Exception:
        d = {}
    if r.status_code >= 400:
        return False, d.get("error") or d.get("message") or f"رُفض الطلب ({r.status_code})"
    data = d.get("data", d)
    lim = spec.get("limit")
    if lim and isinstance(data, list):
        data = data[:lim]
    return True, {"data": data, "message": d.get("message", "")}


def compact(obj, n=2800):
    s = json.dumps(obj, ensure_ascii=False, default=str)
    return s if len(s) <= n else s[:n] + "…(مقتطع)"
