# -*- coding: utf-8 -*-
"""الدعم عن بعد (RustDesk): يُنزَّل عند الطلب فقط، ويبدؤه المدير بنفسه وينهيه، ويُغلَق آلياً بعد ساعتين.
يظهر رقم الجلسة وكلمة المرور المؤقتة في نافذة RustDesk نفسها فيقرؤهما المدير لفريق الدعم."""
import os, re, time, threading, subprocess
from pathlib import Path
from app.core.config import BASE_DIR

DATA = Path(BASE_DIR) / "data" / "support"
IS_WIN = os.name == "nt"
EXE = DATA / "rustdesk.exe"
MAX_MINUTES = 120
_st = {"proc": None, "started": 0.0, "dl": "", "timer": None}
_RX = re.compile(r"^rustdesk-[\d.]+-x86_64\.exe$")


def has_binary():
    return EXE.exists() and EXE.stat().st_size > 5_000_000


def running():
    p = _st["proc"]
    return bool(p and p.poll() is None)


def status():
    return {"supported": IS_WIN, "installed": has_binary(), "running": running(), "dl": _st["dl"],
            "minutes": int((time.time() - _st["started"]) / 60) if running() else 0, "max_minutes": MAX_MINUTES}


def download():
    """تنزيل RustDesk الرسمي من GitHub (يحتاج إنترنت مرة واحدة، ويُتحقق من ترويسة الملف)."""
    import httpx
    DATA.mkdir(parents=True, exist_ok=True)
    tmp = EXE.with_suffix(".part")
    _st["dl"] = "downloading"
    try:
        with httpx.Client(follow_redirects=True, timeout=60) as c:
            rel = c.get("https://api.github.com/repos/rustdesk/rustdesk/releases/latest",
                        headers={"Accept": "application/vnd.github+json"})
            rel.raise_for_status()
            url = next((a["browser_download_url"] for a in rel.json().get("assets", []) if _RX.match(a.get("name", ""))), "")
            if not url:
                raise RuntimeError("لم يُعثر على ملف ويندوز في آخر إصدار")
            with c.stream("GET", url) as r:
                r.raise_for_status()
                with open(tmp, "wb") as f:
                    for ch in r.iter_bytes(1 << 16):
                        f.write(ch)
        if open(tmp, "rb").read(2) != b"MZ" or tmp.stat().st_size < 5_000_000:
            raise RuntimeError("الملف المنزَّل غير صالح")
        os.replace(tmp, EXE)
        _st["dl"] = "done"
        return True, ""
    except Exception as e:
        _st["dl"] = "error"
        try: tmp.unlink()
        except Exception: pass
        return False, str(e)[:160]


def _auto_stop():
    time.sleep(MAX_MINUTES * 60)
    if running():
        stop()


def start():
    if not IS_WIN:
        return False, "الدعم عن بعد متاح على ويندوز فقط"
    if not has_binary():
        return False, "نزّل أداة الدعم أولاً"
    if running():
        return True, ""
    try:
        _st["proc"] = subprocess.Popen([str(EXE)], cwd=str(DATA))
        _st["started"] = time.time()
        t = threading.Thread(target=_auto_stop, daemon=True); t.start(); _st["timer"] = t
        return True, ""
    except Exception as e:
        return False, str(e)[:160]


def stop():
    """يُنهي الجلسة ويغلق كل عمليات RustDesk؛ يعيد المدة بالدقائق."""
    mins = int((time.time() - _st["started"]) / 60) if _st["started"] else 0
    p = _st["proc"]
    try:
        if p and p.poll() is None: p.terminate()
    except Exception:
        pass
    if IS_WIN:
        try: subprocess.run(["taskkill", "/IM", "rustdesk.exe", "/F"], capture_output=True, timeout=10)
        except Exception: pass
    _st["proc"] = None; _st["started"] = 0.0
    return mins
