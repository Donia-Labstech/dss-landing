# -*- coding: utf-8 -*-
"""قالب سكربت Google Apps Script لإرسال إشعارات DSS بالبريد مجاناً عبر حساب Gmail الخاص بالمؤسسة.
يُلصق في «الإضافات ← Apps Script» داخل شيت جوجل، ويُنشر كتطبيق ويب."""

TEMPLATE = r"""// DONIA SMART SCHOOL — بوابة البريد (Google Apps Script)
// 1) غيّر المفتاح أدناه إلى كلمة سرّية طويلة من اختيارك (نفسها تُكتب في DSS)
// 2) انشر: نشر ← نشر جديد ← النوع «تطبيق ويب» ← التنفيذ باسمي ← الوصول «أي شخص»
const KEY = 'ضع-هنا-مفتاحاً-سرياً-طويلاً';
const SHEET = 'Log';

function _out(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
function _log(to, subject, status) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sh = ss.getSheetByName(SHEET) || ss.insertSheet(SHEET);
    if (sh.getLastRow() === 0) sh.appendRow(['الوقت', 'المستلم', 'الموضوع', 'الحالة']);
    sh.appendRow([new Date(), to, subject, status]);   // لا يُحفظ نص الرسالة حمايةً للخصوصية
  } catch (e) {}
}
function doGet(e) {
  if (!e || !e.parameter || e.parameter.key !== KEY) return _out({ ok: false, error: 'bad key' });
  return _out({ ok: true, left: MailApp.getRemainingDailyQuota() });
}
function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents);
    if (d.key !== KEY) return _out({ ok: false, error: 'bad key' });
    const to = String(d.to || '').trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) return _out({ ok: false, error: 'bad address' });
    const left = MailApp.getRemainingDailyQuota();
    if (left < 1) { _log(to, d.subject, 'quota'); return _out({ ok: false, error: 'quota' }); }
    const subject = String(d.subject || '').slice(0, 200);
    MailApp.sendEmail({ to: to, subject: subject, body: String(d.body || '').slice(0, 5000), name: String(d.sender || 'DSS').slice(0, 100) });
    _log(to, subject, 'sent');
    return _out({ ok: true, left: left - 1 });
  } catch (err) {
    return _out({ ok: false, error: String(err).slice(0, 200) });
  }
}
"""
