"""مولّد باركود Code128 (SVG) بلا اعتماديات خارجية — يُستعمل للرمز الوظيفي في شهادة العمل.
DONIA LABS TECH © 2026"""
_P = ("212222 222122 222221 121223 121322 131222 122213 122312 132212 221213 221312 231212 112232 122132 122231 113222 "
      "123122 123221 223211 221132 221231 213212 223112 312131 311222 321122 321221 312212 322112 322211 212123 212321 "
      "232121 111323 131123 131321 112313 132113 132311 211313 231113 231311 112133 112331 132131 113123 113321 133121 "
      "313121 211331 231131 213113 213311 213131 311123 311321 331121 312113 312311 332111 314111 221411 431111 111224 "
      "111422 121124 121421 141122 141221 112214 112412 122114 122411 142112 142211 241211 221114 413111 241112 134111 "
      "111242 121142 121241 114212 124112 124211 411212 421112 421211 212141 214121 412121 111143 111341 131141 114113 "
      "114311 411113 411311 113141 114131 311141 411131 211412 211214 211232 2331112").split()


def encode(text):
    text = str(text)
    if text.isdigit() and len(text) % 2 == 0 and len(text) >= 4:
        codes, start = [int(text[i:i + 2]) for i in range(0, len(text), 2)], 105
    else:
        codes, start = [ord(c) - 32 for c in text if 32 <= ord(c) < 128], 104
    chk = (start + sum(c * (i + 1) for i, c in enumerate(codes))) % 103
    return [start] + codes + [chk, 106]


def svg(text, height=46, module=1.4):
    if not str(text or "").strip():
        return ""
    x, bars = 10 * module, []
    for c in encode(text):
        pat = _P[c]
        for i, w in enumerate(pat):
            w = int(w) * module
            if i % 2 == 0:
                bars.append(f'<rect x="{x:.2f}" y="0" width="{w:.2f}" height="{height}"/>')
            x += w
    width = x + 10 * module
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width:.1f} {height}" width="{width:.0f}" height="{height}" '
            f'shape-rendering="crispEdges" fill="#000">{"".join(bars)}</svg>')
