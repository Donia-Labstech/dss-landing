# -*- coding: utf-8 -*-
"""المساعد الذكي عبر بوابة DONIA (رصيد مدفوع): لا يحتاج المدير مفتاحاً. تُعرَّف المؤسسة بترخيصها الموقَّع،
والمفتاح الحقيقي يبقى على خادم DONIA. لا يُرسَل إلا نص الطلب؛ ولا يُحفظ أي نص عند الخادم."""
import json, time
import httpx
from pathlib import Path
from app.core.config import cfg
from app.core.database import Session, SchoolInfo

BUY_PHONE = "213674661737"
_cache = {"url": "", "ts": 0.0}
ERR = {
    "no_credits": "رصيد المساعد الذكي نفد — اشحن رصيدك من زر «🛒 اشحن رصيدك» أعلى هذه الصفحة.",
    "daily_cap": "بلغت المؤسسة الحد اليومي لطلبات المساعد الذكي — جرّب غداً.",
    "invalid_license": "تعذّر التحقق من ترخيص المؤسسة لدى بوابة المساعد الذكي.",
    "license_expired": "انتهت صلاحية ترخيص المؤسسة — جدّده لاستعمال المساعد الذكي.",
    "bad_request": "الطلب طويل جداً — اختصره وأعد المحاولة.",
    "upstream": "خدمة الذكاء الاصطناعي غير متاحة حالياً — أعد المحاولة بعد قليل.",
    "upstream_empty": "لم يصل ردّ من الخدمة — أعد المحاولة.",
}


def license_body():
    """{canonical, signature} كما وُقِّعا — يتحقق منهما الخادم بالمفتاح العام نفسه."""
    try:
        d = json.loads(Path(cfg.LICENSE_FILE).read_text(encoding="utf-8"))
        p, sig = d.get("payload") or {}, d.get("signature") or ""
        if not p or not sig:
            return None
        return {"canonical": json.dumps(p, sort_keys=True, ensure_ascii=False), "signature": sig}
    except Exception:
        return None


def gateway_url():
    """عنوان البوابة: من إعدادات المؤسسة، ثم .env، ثم ملف ai.json المنشور عند DONIA (يُخزَّن 6 ساعات)."""
    db = Session()
    try:
        si = db.query(SchoolInfo).first()
        u = (getattr(si, "ai_gateway_url", "") or "").strip() if si else ""
    finally:
        db.close()
    if u:
        return u.rstrip("/")
    if getattr(cfg, "AI_GATEWAY_URL", ""):
        return cfg.AI_GATEWAY_URL.rstrip("/")
    if time.time() - _cache["ts"] > 6 * 3600:
        _cache["ts"] = time.time()
        try:
            from app.services.updater import MANIFEST_URL
            r = httpx.get(MANIFEST_URL.rsplit("/", 1)[0] + "/ai.json", timeout=5)
            _cache["url"] = (r.json().get("gateway") or "").strip().rstrip("/") if r.status_code == 200 else ""
        except Exception:
            _cache["url"] = ""
    return _cache["url"]


def own_key():
    return bool(cfg.GROQ_KEY or cfg.ANTHROPIC_KEY or cfg.GEMINI_KEY)


async def chat(system, msgs):
    """يعيد (نص، None) أو (None، رسالة خطأ بالعربية)."""
    url, lb = gateway_url(), license_body()
    if not url:
        return None, "المساعد الذكي غير مُفعَّل بعد — تواصل مع DONIA LABS TECH لتفعيله."
    if not lb:
        return None, "يلزم ترخيص مفعَّل لاستعمال المساعد الذكي."
    try:
        async with httpx.AsyncClient(timeout=45) as c:
            r = await c.post(url + "/v1/chat", json={**lb, "system": system, "messages": msgs, "max_tokens": 1200})
        d = r.json()
    except Exception:
        return None, "تعذّر الاتصال ببوابة المساعد الذكي — تحقق من الإنترنت."
    if r.status_code == 200 and d.get("text"):
        return d["text"], None
    return None, ERR.get(d.get("error"), "تعذّر الحصول على ردّ من المساعد الذكي.")


def status():
    url, lb = gateway_url(), license_body()
    out = {"own_key": own_key(), "gateway_url": url, "has_license": bool(lb), "balance": None,
           "buy_url": "https://wa.me/%s" % BUY_PHONE}
    if own_key() or not (url and lb):
        return out
    try:
        r = httpx.post(url + "/v1/balance", json=lb, timeout=10)
        if r.status_code == 200:
            b = r.json(); out["balance"] = b
            out["buy_url"] = "https://wa.me/%s?text=%s" % (BUY_PHONE, __import__("urllib.parse").parse.quote(
                "السلام عليكم، أريد شحن رصيد المساعد الذكي (DSS). رمز مؤسستي: %s" % b.get("code", "")))
        else:
            out["error"] = ERR.get((r.json() or {}).get("error"), "")
    except Exception:
        out["error"] = "تعذّر الاتصال بالبوابة"
    return out
