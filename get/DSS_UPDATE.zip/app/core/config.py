"""
DONIA SMART SCHOOL v3 — Configuration
Pure Python — Zero Rust — Python 3.14 ✓
DONIA LABS TECH © 2026
"""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent.parent

class Settings:
    # App
    APP_NAME        = "DONIA SMART SCHOOL"
    VERSION         = "3.0.0"
    DEBUG           = os.getenv("DEBUG", "false").lower() == "true"
    PORT            = int(os.getenv("PORT", "8000"))

    # Security
    SECRET_KEY      = os.getenv("SECRET_KEY", "donia-secret-2026-change-me-please")
    HMAC_SECRET     = os.getenv("HMAC_SECRET", "donia-hmac-2026-change-me-please")
    TOKEN_HOURS     = int(os.getenv("TOKEN_EXPIRE_HOURS", "8"))
    MAX_ATTEMPTS    = int(os.getenv("MAX_LOGIN_ATTEMPTS", "5"))
    LOCKOUT_MINS    = int(os.getenv("LOCKOUT_MINUTES", "30"))

    # Database
    DB_PATH         = str(BASE_DIR / "data" / "dss_school.db")
    DATABASE_URL    = f"sqlite:///{DB_PATH}"

    # School
    SCHOOL_NAME     = os.getenv("SCHOOL_NAME", "")
    SCHOOL_CODE     = os.getenv("SCHOOL_CODE", "")
    WILAYA          = os.getenv("WILAYA", "")
    ACADEMIC_YEAR   = os.getenv("ACADEMIC_YEAR", "2025/2026")

    # AI
    GROQ_KEY        = os.getenv("GROQ_API_KEY", "")
    ANTHROPIC_KEY   = os.getenv("ANTHROPIC_API_KEY", "")
    GEMINI_KEY      = os.getenv("GEMINI_API_KEY", "")
    AI_GATEWAY_URL  = os.getenv("AI_GATEWAY_URL", "")
    AI_PROVIDER     = os.getenv("AI_PROVIDER", "groq")
    AI_MODEL        = os.getenv("AI_MODEL", "llama3-70b-8192")

    # License
    LICENSE_FILE    = str(BASE_DIR / "licenses" / "dss.lic")
    LICENSE_SERVER  = os.getenv("LICENSE_SERVER", "")   # عنوان خادم تفعيل التراخيص (اختياري — يوجد بديل بملف dss.lic)

    # ── Notifications (إشعارات الغياب التلقائية) ──────────────
    # البريد الإلكتروني (SMTP) — اختياري، يبقى النظام يعمل بدونه
    SMTP_HOST       = os.getenv("SMTP_HOST", "")
    SMTP_PORT       = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USER       = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD   = os.getenv("SMTP_PASSWORD", "")
    SMTP_FROM       = os.getenv("SMTP_FROM", "") or os.getenv("SMTP_USER", "")
    SMTP_USE_TLS    = os.getenv("SMTP_USE_TLS", "true").lower() == "true"

    # واتساب — يدعم مزوّدين: meta (WhatsApp Cloud API الرسمي) أو twilio
    WHATSAPP_PROVIDER   = os.getenv("WHATSAPP_PROVIDER", "meta")   # meta | twilio
    WHATSAPP_TOKEN      = os.getenv("WHATSAPP_TOKEN", "")          # Meta: access token دائم
    WHATSAPP_PHONE_ID   = os.getenv("WHATSAPP_PHONE_ID", "")       # Meta: Phone Number ID
    TWILIO_SID          = os.getenv("TWILIO_SID", "")
    TWILIO_AUTH_TOKEN   = os.getenv("TWILIO_AUTH_TOKEN", "")
    TWILIO_WHATSAPP_FROM= os.getenv("TWILIO_WHATSAPP_FROM", "")    # مثال: whatsapp:+14155238886

cfg = Settings()

# ══════════════════════════════════════
# 22 GATES
# ══════════════════════════════════════
GATES = {
    "G01": "إدارة التلاميذ",
    "G02": "كشوف الغياب اليومية",
    "G03": "الإشعارات القانونية",
    "G04": "إدخال النقاط",
    "G05": "مجالس الأقسام",
    "G06": "الوثائق الرسمية",
    "G07": "التقرير اليومي",
    "G08": "إدارة الأساتذة",
    "G09": "الجداول الزمنية",
    "G10": "الموارد البشرية",
    "G11": "الإطعام والكانتين",
    "G12": "التقارير الإحصائية",
    "G13": "استدعاء الأولياء",
    "G14": "الإجراءات التأديبية",
    "G15": "المكتبة المدرسية",
    "G16": "سجل التدقيق",
    "G17": "إدارة الأقسام",
    "G18": "لوحة القيادة",
    "G19": "المساعد الذكي AI",
    "G20": "إعدادات المؤسسة",
    "G21": "إدارة المستخدمين",
    "G22": "نسخة احتياطية وأمان",
    "G23": "تتبع مواقع التلاميذ",
    "G24": "بوابة الأولياء",
    "G25": "بوابة الأستاذ (غياب + طلب استدعاء)",
    "G26": "بوابة المشرف التربوي",
    "G27": "مركز متابعة المدير",
    "G28": "النوادي المدرسية (إدارة واشتراك وحضور)",
}

# 10 ROLES → default gates
ROLE_GATES = {
    "director":   list(GATES.keys()),
    "nazir":      ["G01","G06","G07","G08","G09","G10","G12","G13","G14","G17","G18","G23","G26","G27","G28","G11","G15"],
    "counselor":  ["G01","G02","G03","G06","G07","G11","G12","G13","G14","G18","G19","G23","G26","G27","G28","G15"],
    # المشرف العام: نفس صلاحيات مستشار التربية
    "supervisor_general": ["G01","G02","G03","G06","G07","G11","G12","G13","G14","G18","G19","G23","G26","G27","G28","G15"],
    "teacher":    ["G02","G04","G05","G09","G18","G25"],
    "admin":      ["G01","G06","G10","G12","G13","G17","G18","G15"],
    "accountant": ["G11","G12","G18"],
    "supervisor": ["G02","G07","G11","G13","G18","G23","G26","G28","G15"],
    "student":    ["G18"],
    "parent":     ["G24"],
    "worker":     ["G18"],
}

# Grade comments /20
COMMENTS = [
    (18, 20, "نتائج ممتازة، واصل مسيرتك المشرفة"),
    (16, 18, "نتائج جيدة جداً، استمر في بذل الجهد"),
    (14, 16, "نتائج جيدة، يمكنك تحقيق أكثر بجهد إضافي"),
    (12, 14, "نتائج متوسطة، يجب العمل بجدية أكبر"),
    (10, 12, "نتائج دون المستوى، عليك بمضاعفة الجهد"),
    (8,  10, "نتائج ضعيفة، راجع أستاذك والمستشار"),
    (0,   8, "نتائج جد ضعيفة، عليك بالاجتهاد أكثر"),
]

# أيام الأسبوع الدراسي الجزائري (السبت أول يوم، الجمعة عطلة)
DAYS_OF_WEEK = ["السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس"]

# ── قواعد المواظبة ─────────────────────────────────────────────────────
# المرجع: «النظام الداخلي الموحد لمؤسسات التربية والتعليم» (55 مادة / 9 فصول) المعتمد
# بالمراسلة الوزارية رقم 460 المؤرخة في 2026/09/07، ويسري ابتداءً من الدخول المدرسي
# 2026-2027. وقد حلّ محل القرار الوزاري 833 (1991/11/13) الذي لم يعد معمولاً به.
# الأرقام أدناه قابلة للتعديل من «إعدادات المؤسسة ← قواعد المواظبة» لتطابق نص المديرية.
ABSENCE_RULES = {
    "first_notice":  1,    # أيام الغياب المتتالية غير المبرر بعد أجل التبرير → إنذار كتابي أول
    "second_notice": 3,    # → إنذار/إشعار ثانٍ
    "warning":       8,    # → إعذار كتابي
    "eviction_days": 15,   # مهلة الرد بعد الإعذار قبل اقتراح الشطب
    "justify_hours": 48,   # أجل تبرير الغياب (حضور الولي أو شهادة طبية)
}
DECREE_833 = ABSENCE_RULES   # اسم قديم محفوظ للتوافق مع بقية الوحدات (القاموس نفسه)

LEGAL_BASIS = ("بناء على النظام الداخلي الموحد لمؤسسات التربية والتعليم المعتمد بالمراسلة الوزارية "
               "رقم 460 المؤرخة في 2026/09/07، الساري ابتداءً من الدخول المدرسي 2026-2027")
LEGAL_SHORT = "النظام الداخلي الموحد (م.و 460 / 2026)"
