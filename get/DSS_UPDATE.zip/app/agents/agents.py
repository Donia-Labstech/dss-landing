"""
DONIA SMART SCHOOL v3 — AI Agents
Pure httpx — Python 3.14 ✓
DONIA LABS TECH © 2026
"""
import json
from datetime import date, datetime
import httpx
from app.core.config import cfg
from app.core.database import Session, Student, Absence, AbsenceNotice, TermResult, AuditLog
from app.services.services import AbsenceService


class AIClient:
    SYS = ("أنت مساعد ذكي لإدارة المؤسسات التربوية الجزائرية ضمن نظام DONIA SMART SCHOOL. "
           "تُجيب دائماً باللغة العربية الفصحى المناسبة للمراسلات الرسمية الجزائرية.")

    async def ask(self, prompt: str, context: str = "") -> str:
        msgs = []
        if context:
            msgs += [{"role":"user","content":f"السياق:\n{context}"},
                     {"role":"assistant","content":"فهمت."}]
        msgs.append({"role":"user","content":prompt})
        try:
            if cfg.AI_PROVIDER == "groq" and cfg.GROQ_KEY:
                return await self._groq(msgs)
            elif cfg.AI_PROVIDER == "anthropic" and cfg.ANTHROPIC_KEY:
                return await self._anthropic(msgs)
            elif cfg.AI_PROVIDER == "gemini" and cfg.GEMINI_KEY:
                return await self._gemini(msgs)
            for fn in [self._groq, self._anthropic, self._gemini]:
                try:
                    r = await fn(msgs)
                    if r:
                        return r
                except Exception:
                    continue
            from app.services import aigateway
            text, e = await aigateway.chat(self.SYS, msgs)
            return text if text else e
        except Exception as e:
            return f"خطأ AI: {str(e)}"

    async def _groq(self, msgs):
        if not cfg.GROQ_KEY: raise ValueError("no key")
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post("https://api.groq.com/openai/v1/chat/completions",
                headers={"Authorization": f"Bearer {cfg.GROQ_KEY}"},
                json={"model": cfg.AI_MODEL,
                      "messages": [{"role":"system","content":self.SYS}]+msgs,
                      "max_tokens": 1200, "temperature": 0.3})
            return r.json()["choices"][0]["message"]["content"]

    async def _anthropic(self, msgs):
        if not cfg.ANTHROPIC_KEY: raise ValueError("no key")
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post("https://api.anthropic.com/v1/messages",
                headers={"x-api-key": cfg.ANTHROPIC_KEY, "anthropic-version":"2023-06-01"},
                json={"model":"claude-haiku-4-5-20251001","system":self.SYS,
                      "messages":msgs,"max_tokens":1200})
            return r.json()["content"][0]["text"]

    async def _gemini(self, msgs):
        if not cfg.GEMINI_KEY: raise ValueError("no key")
        contents = [{"role":"user","parts":[{"text":self.SYS}]},
                    {"role":"model","parts":[{"text":"فهمت."}]}]
        for m in msgs:
            contents.append({"role":"user" if m["role"]=="user" else "model",
                              "parts":[{"text":m["content"]}]})
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post("https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent",
                params={"key": cfg.GEMINI_KEY}, json={"contents":contents})
            return r.json()["candidates"][0]["content"]["parts"][0]["text"]


_ai = AIClient()


class MonitorAgent:
    async def scan(self) -> dict:
        db = Session()
        try:
            alerts = []
            students = db.query(Student).filter(
                Student.is_active==True, Student.is_expelled==False
            ).all()
            for s in students:
                unexcused = db.query(Absence).filter(
                    Absence.student_id==s.id, Absence.status=="غير مبرر"
                ).all()
                if not unexcused: continue
                dates = [a.date for a in unexcused]
                consec = AbsenceService.consecutive(dates)
                issued = [n.notice_type for n in
                          db.query(AbsenceNotice).filter(AbsenceNotice.student_id==s.id).all()]
                needed = AbsenceService.check_milestone(consec, issued)
                if needed:
                    alerts.append({"student_id":s.id,"name":s.full_name,
                                   "consecutive_days":consec,"notice_needed":needed})
            t1 = {r.student_id:r.term_average for r in
                  db.query(TermResult).filter(TermResult.term=="الفصل_الأول").all()}
            t2 = {r.student_id:r.term_average for r in
                  db.query(TermResult).filter(TermResult.term=="الفصل_الثاني").all()}
            drops = []
            for sid, avg2 in t2.items():
                avg1 = t1.get(sid)
                if avg1 and avg2 and avg2 < avg1 - 2.0:
                    s = db.query(Student).filter(Student.id==sid).first()
                    if s:
                        drops.append({"student_id":sid,"name":s.full_name,
                                      "t1":avg1,"t2":avg2,"drop":round(avg1-avg2,2)})
            return {"scanned_at": datetime.now().isoformat(),
                    "absence_alerts": alerts, "grade_drops": drops}
        finally:
            db.close()

    async def report(self, results: dict) -> str:
        return await _ai.ask(
            "بناءً على نتائج الفحص اليومي، قدّم:\n1. ملخص الوضع\n"
            "2. الحالات الأكثر إلحاحاً\n3. توصيات فورية للإدارة",
            json.dumps(results, ensure_ascii=False, indent=2)
        )


class OutreachAssistant:
    async def answer(self, q: str, ctx=None) -> str:
        return await _ai.ask(q, json.dumps(ctx, ensure_ascii=False) if ctx else "")

    async def sms(self, name, issue, details, school) -> str:
        return await _ai.ask(
            f"اكتب رسالة SMS (≤160 حرف) لولي أمر {name} بشأن: {issue}. "
            f"التفاصيل: {details}. المؤسسة: {school}. أسلوب رسمي محترم."
        )

    async def council_minutes(self, div, term, year, students) -> str:
        s = "\n".join([f"- {x.get('name')}: {x.get('average')}/20" for x in students[:15]])
        return await _ai.ask(
            f"اكتب محضر مجلس قسم {div} — {term} — {year}.\nالنتائج:\n{s}\n"
            "يتضمن: صيغة رسمية جزائرية، توصيات تربوية، ختم."
        )


monitor  = MonitorAgent()
outreach = OutreachAssistant()
